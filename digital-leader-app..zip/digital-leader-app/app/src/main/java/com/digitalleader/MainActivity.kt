package com.digitalleader

import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.drawerlayout.widget.DrawerLayout
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.NavigationUI
import com.google.android.material.navigation.NavigationView
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {
    
    private lateinit var drawerLayout: DrawerLayout
    private lateinit var navigationView: NavigationView
    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var navController: NavController
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // تحميل السمة المحفوظة
        sharedPreferences = getSharedPreferences("app_prefs", MODE_PRIVATE)
        applyTheme()
        
        setContentView(R.layout.activity_main)
        
        // التحقق من الدخول الأول
        val userName = sharedPreferences.getString("user_name", null)
        if (userName == null) {
            startActivity(Intent(this, OnboardingActivity::class.java))
            finish()
            return
        }
        
        // التحقق من تحديد المنطقة
        if (!sharedPreferences.getBoolean("region_selected", false)) {
            startActivity(Intent(this, RegionSelectionActivity::class.java))
            finish()
            return
        }
        
        sharedPreferences.edit().putBoolean("onboarding_completed", true).apply()
        
        initializeUI()
        setupNavigation()
        updateGreeting()
        setupToolsGrid()
    }
    
    private fun applyTheme() {
        val themeMode = sharedPreferences.getString("theme_mode", "system") ?: "system"
        
        when (themeMode) {
            "light" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            "dark" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            "system" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
            "auto_time" -> {
                val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
                if (hour in 6..17) {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                } else {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                }
            }
        }
    }
    
    private fun initializeUI() {
        drawerLayout = findViewById(R.id.drawer_layout)
        navigationView = findViewById(R.id.navigation_view)
        
        val menuButton: ImageButton = findViewById(R.id.menu_button)
        menuButton.setOnClickListener {
            drawerLayout.openDrawer(navigationView)
        }
        
        setupNavigationMenu()
    }
    
    private fun setupNavigation() {
        val navHostFragment = supportFragmentManager.findFragmentById(R.id.nav_host_fragment) as? NavHostFragment
        navController = navHostFragment?.navController ?: return
        NavigationUI.setupWithNavController(navigationView, navController)
    }
    
    private fun setupNavigationMenu() {
        navigationView.setNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.nav_cultural_week -> {
                    startActivity(Intent(this, CulturalWeekActivity::class.java))
                }
                R.id.nav_developer -> {
                    startActivity(Intent(this, DeveloperActivity::class.java))
                }
                R.id.nav_prayer_times -> {
                    startActivity(Intent(this, PrayerTimesActivity::class.java))
                }
                R.id.nav_theme -> {
                    showThemeDialog()
                }
            }
            drawerLayout.closeDrawer(navigationView)
            true
        }
    }
    
    private fun updateGreeting() {
        val greetingText: TextView = findViewById(R.id.greeting_text)
        val dateTimeText: TextView = findViewById(R.id.date_time_text)
        val dhikrText: TextView = findViewById(R.id.dhikr_text)
        
        val userName = sharedPreferences.getString("user_name", "المستخدم") ?: "المستخدم"
        val calendar = Calendar.getInstance()
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        
        val greeting = when (hour) {
            in 4..11 -> getString(R.string.greeting_morning)
            in 12..17 -> getString(R.string.greeting_afternoon)
            else -> getString(R.string.greeting_evening)
        }
        
        greetingText.text = "$greeting $userName"
        
        // تحديث التاريخ والوقت
        val dateFormat = SimpleDateFormat("EEEE, dd MMMM yyyy HH:mm", Locale("ar"))
        dateTimeText.text = dateFormat.format(Date())
        
        // تحديث الذكر اليومي
        val dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK)
        val dhikr = when (dayOfWeek) {
            Calendar.SATURDAY -> getString(R.string.dhikr_saturday)
            Calendar.SUNDAY -> getString(R.string.dhikr_sunday)
            Calendar.MONDAY -> getString(R.string.dhikr_monday)
            Calendar.TUESDAY -> getString(R.string.dhikr_tuesday)
            Calendar.WEDNESDAY -> getString(R.string.dhikr_wednesday)
            Calendar.THURSDAY -> getString(R.string.dhikr_thursday)
            Calendar.FRIDAY -> {
                dhikrText.visibility = View.GONE
                // إظهار زر الجمعة بدلاً من النص
                return
            }
            else -> ""
        }
        
        dhikrText.text = dhikr
        dhikrText.visibility = View.VISIBLE
    }
    
    private fun setupToolsGrid() {
        // سيتم تنفيذ هذا في Fragment منفصل
    }
    
    private fun showThemeDialog() {
        // سيتم تنفيذ هذا لاحقاً
    }
}
