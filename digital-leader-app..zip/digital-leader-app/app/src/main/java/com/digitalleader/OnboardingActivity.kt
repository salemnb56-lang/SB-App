package com.digitalleader

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class OnboardingActivity : AppCompatActivity() {
    
    private val sharedPreferences by lazy { getSharedPreferences("app_prefs", MODE_PRIVATE) }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_onboarding)
        
        showNameDialog()
    }
    
    private fun showNameDialog() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle(R.string.enter_name)
        builder.setCancelable(false)
        
        val input = EditText(this)
        input.hint = R.string.enter_name
        builder.setView(input)
        
        builder.setPositiveButton(R.string.ok) { _, _ ->
            val name = input.text.toString().trim()
            if (name.isNotEmpty()) {
                sharedPreferences.edit().apply {
                    putString("user_name", name)
                    apply()
                }
                
                showRegionDialog()
            } else {
                Toast.makeText(this, "يرجى إدخال اسمك", Toast.LENGTH_SHORT).show()
                showNameDialog()
            }
        }
        
        builder.show()
    }
    
    private fun showRegionDialog() {
        startActivity(Intent(this, RegionSelectionActivity::class.java))
        finish()
    }
}
