package com.digitalleader

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Spinner
import androidx.appcompat.app.AppCompatActivity

class FormulasActivity : AppCompatActivity() {
    
    private lateinit var categorySpinner: Spinner
    private lateinit var formulasListView: ListView
    
    private val formulas = mapOf(
        "الفيزياء" to listOf(
            "القوة: F = ma",
            "الطاقة الحركية: KE = ½mv²",
            "الطاقة الكامنة: PE = mgh",
            "السرعة: v = d/t",
            "التسارع: a = Δv/Δt"
        ),
        "الرياضيات" to listOf(
            "المساحة (المستطيل): A = l × w",
            "المساحة (الدائرة): A = πr²",
            "المحيط (الدائرة): C = 2πr",
            "حجم الكرة: V = (4/3)πr³",
            "معادلة الخط: y = mx + b"
        ),
        "الكيمياء" to listOf(
            "الكتلة المولية: M = m/n",
            "التركيز: C = n/V",
            "قانون الغاز: PV = nRT",
            "درجة الحموضة: pH = -log[H+]",
            "السعة الحرارية: Q = mcΔT"
        )
    )
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_formulas)
        
        categorySpinner = findViewById(R.id.category_spinner)
        formulasListView = findViewById(R.id.formulas_list)
        
        val categories = formulas.keys.toList()
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, categories)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        categorySpinner.adapter = adapter
        
        categorySpinner.setOnItemSelectedListener(object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                val selectedCategory = categories[position]
                val categoryFormulas = formulas[selectedCategory] ?: emptyList()
                val listAdapter = ArrayAdapter(this@FormulasActivity, android.R.layout.simple_list_item_1, categoryFormulas)
                formulasListView.adapter = listAdapter
            }
            
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        })
    }
}
