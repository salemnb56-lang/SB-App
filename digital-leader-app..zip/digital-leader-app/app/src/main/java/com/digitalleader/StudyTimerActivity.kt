package com.digitalleader

import android.os.Bundle
import android.os.CountDownTimer
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class StudyTimerActivity : AppCompatActivity() {
    
    private lateinit var subjectSpinner: Spinner
    private lateinit var studyDurationInput: EditText
    private lateinit var breakDurationInput: EditText
    private lateinit var startButton: Button
    private lateinit var pauseButton: Button
    private lateinit var resumeButton: Button
    private lateinit var timerDisplay: TextView
    private lateinit var progressBar: ProgressBar
    
    private var countDownTimer: CountDownTimer? = null
    private var totalTime = 0L
    private var remainingTime = 0L
    private var isRunning = false
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_study_timer)
        
        initializeUI()
        setupListeners()
    }
    
    private fun initializeUI() {
        subjectSpinner = findViewById(R.id.subject_spinner)
        studyDurationInput = findViewById(R.id.study_duration_input)
        breakDurationInput = findViewById(R.id.break_duration_input)
        startButton = findViewById(R.id.start_button)
        pauseButton = findViewById(R.id.pause_button)
        resumeButton = findViewById(R.id.resume_button)
        timerDisplay = findViewById(R.id.timer_display)
        progressBar = findViewById(R.id.progress_bar)
        
        val subjects = arrayOf("رياضيات", "فيزياء", "كيمياء", "عربي", "إنجليزي")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, subjects)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        subjectSpinner.adapter = adapter
    }
    
    private fun setupListeners() {
        startButton.setOnClickListener { startTimer() }
        pauseButton.setOnClickListener { pauseTimer() }
        resumeButton.setOnClickListener { resumeTimer() }
    }
    
    private fun startTimer() {
        val studyMinutes = studyDurationInput.text.toString().toIntOrNull() ?: 45
        totalTime = (studyMinutes * 60 * 1000).toLong()
        remainingTime = totalTime
        
        startCountdown()
    }
    
    private fun startCountdown() {
        isRunning = true
        countDownTimer = object : CountDownTimer(remainingTime, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                remainingTime = millisUntilFinished
                updateDisplay()
            }
            
            override fun onFinish() {
                Toast.makeText(this@StudyTimerActivity, "انتهت فترة الدراسة!", Toast.LENGTH_SHORT).show()
                isRunning = false
            }
        }.start()
    }
    
    private fun pauseTimer() {
        countDownTimer?.cancel()
        isRunning = false
    }
    
    private fun resumeTimer() {
        if (!isRunning) {
            startCountdown()
        }
    }
    
    private fun updateDisplay() {
        val minutes = remainingTime / 60000
        val seconds = (remainingTime % 60000) / 1000
        timerDisplay.text = String.format("%02d:%02d", minutes, seconds)
        
        val progress = ((totalTime - remainingTime) * 100 / totalTime).toInt()
        progressBar.progress = progress
    }
}
