package com.digitalleader

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class TaskOrganizerActivity : AppCompatActivity() {
    
    private lateinit var taskInput: EditText
    private lateinit var prioritySpinner: Spinner
    private lateinit var addButton: Button
    private lateinit var organizeButton: Button
    private lateinit var tasksContainer: LinearLayout
    private lateinit var resultContainer: LinearLayout
    
    private val tasks = mutableListOf<Task>()
    
    data class Task(
        val title: String,
        val priority: Int // 0: عالية، 1: متوسطة، 2: منخفضة
    )
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_task_organizer)
        
        initializeUI()
        setupListeners()
    }
    
    private fun initializeUI() {
        taskInput = findViewById(R.id.task_input)
        prioritySpinner = findViewById(R.id.priority_spinner)
        addButton = findViewById(R.id.add_button)
        organizeButton = findViewById(R.id.organize_button)
        tasksContainer = findViewById(R.id.tasks_container)
        resultContainer = findViewById(R.id.result_container)
        
        val adapter = ArrayAdapter.createFromResource(
            this,
            R.array.priorities,
            android.R.layout.simple_spinner_item
        )
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        prioritySpinner.adapter = adapter
    }
    
    private fun setupListeners() {
        addButton.setOnClickListener { addTask() }
        organizeButton.setOnClickListener { organizeTasks() }
    }
    
    private fun addTask() {
        val taskTitle = taskInput.text.toString().trim()
        if (taskTitle.isEmpty()) {
            Toast.makeText(this, "يرجى إدخال مهمة", Toast.LENGTH_SHORT).show()
            return
        }
        
        val priority = prioritySpinner.selectedItemPosition
        val task = Task(taskTitle, priority)
        tasks.add(task)
        
        // إضافة المهمة إلى الواجهة
        val taskView = TextView(this)
        taskView.text = "$taskTitle (${getPriorityName(priority)})"
        taskView.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        tasksContainer.addView(taskView)
        
        taskInput.text.clear()
    }
    
    private fun organizeTasks() {
        if (tasks.isEmpty()) {
            Toast.makeText(this, "لا توجد مهام لتنظيمها", Toast.LENGTH_SHORT).show()
            return
        }
        
        // ترتيب المهام حسب الأولوية
        val sortedTasks = tasks.sortedBy { it.priority }
        
        resultContainer.removeAllViews()
        
        for (task in sortedTasks) {
            val taskView = TextView(this)
            taskView.text = "• ${task.title} - ${getPriorityName(task.priority)}"
            taskView.textSize = 16f
            taskView.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            resultContainer.addView(taskView)
        }
    }
    
    private fun getPriorityName(priority: Int): String {
        return when (priority) {
            0 -> getString(R.string.high_priority)
            1 -> getString(R.string.medium_priority)
            2 -> getString(R.string.low_priority)
            else -> ""
        }
    }
}
