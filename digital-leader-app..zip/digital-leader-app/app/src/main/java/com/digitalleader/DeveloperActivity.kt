package com.digitalleader

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.net.URLEncoder

class DeveloperActivity : AppCompatActivity() {
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_developer)
        
        val sharedPreferences = getSharedPreferences("app_prefs", MODE_PRIVATE)
        val userName = sharedPreferences.getString("user_name", "المستخدم") ?: "المستخدم"
        
        val developerLogo: ImageView = findViewById(R.id.developer_logo)
        val developerName: TextView = findViewById(R.id.developer_name)
        val developerNameEn: TextView = findViewById(R.id.developer_name_en)
        val developerCredits: TextView = findViewById(R.id.developer_credits)
        val specialCredit: TextView = findViewById(R.id.special_credit)
        val sendButton: Button = findViewById(R.id.send_message_button)
        val quote: TextView = findViewById(R.id.leadership_quote)
        
        developerName.text = getString(R.string.developer_name)
        developerNameEn.text = getString(R.string.developer_name_en)
        developerCredits.text = getString(R.string.developer_credits)
        specialCredit.text = getString(R.string.developer_special_credit)
        quote.text = getString(R.string.leadership_quote)
        
        sendButton.setOnClickListener {
            showMessageDialog(userName)
        }
    }
    
    private fun showMessageDialog(userName: String) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle(R.string.send_message)
        
        val container = android.widget.LinearLayout(this)
        container.orientation = android.widget.LinearLayout.VERTICAL
        
        val nameInput = EditText(this)
        nameInput.setText(userName)
        nameInput.hint = R.string.enter_name
        container.addView(nameInput)
        
        val messageInput = EditText(this)
        messageInput.hint = R.string.enter_message
        messageInput.lines = 4
        container.addView(messageInput)
        
        builder.setView(container)
        
        builder.setPositiveButton(R.string.send_now) { _, _ ->
            val name = nameInput.text.toString()
            val message = messageInput.text.toString()
            
            if (message.isNotEmpty()) {
                sendWhatsAppMessage(name, message)
            }
        }
        
        builder.setNegativeButton(R.string.cancel) { dialog, _ ->
            dialog.dismiss()
        }
        
        builder.show()
    }
    
    private fun sendWhatsAppMessage(name: String, message: String) {
        val phoneNumber = "967781453408"
        val text = "مرحباً، أنا $name، رسالتي: $message"
        val encodedText = URLEncoder.encode(text, "UTF-8")
        
        val intent = Intent(Intent.ACTION_VIEW)
        intent.data = Uri.parse("https://wa.me/$phoneNumber?text=$encodedText")
        
        try {
            startActivity(intent)
        } catch (e: Exception) {
            android.widget.Toast.makeText(this, "WhatsApp غير مثبت", android.widget.Toast.LENGTH_SHORT).show()
        }
    }
}
