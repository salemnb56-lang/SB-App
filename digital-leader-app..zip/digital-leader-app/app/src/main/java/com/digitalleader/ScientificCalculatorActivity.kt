package com.digitalleader

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.*

class ScientificCalculatorActivity : AppCompatActivity() {
    
    private lateinit var displayText: TextView
    private var expression = ""
    private var result = 0.0
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_scientific_calculator)
        
        displayText = findViewById(R.id.display_text)
        setupButtons()
    }
    
    private fun setupButtons() {
        // أرقام
        listOf(R.id.btn_0, R.id.btn_1, R.id.btn_2, R.id.btn_3, R.id.btn_4,
               R.id.btn_5, R.id.btn_6, R.id.btn_7, R.id.btn_8, R.id.btn_9).forEach { id ->
            findViewById<Button>(id)?.setOnClickListener { appendNumber(it as Button) }
        }
        
        // العمليات الأساسية
        listOf(R.id.btn_plus, R.id.btn_minus, R.id.btn_multiply, R.id.btn_divide).forEach { id ->
            // تم تصحيح الخطأ هنا بإرسال النص بدلاً من الزر الكامل
            findViewById<Button>(id)?.setOnClickListener { appendOperator((it as Button).text.toString()) }
        }
        
        // العمليات العلمية
        findViewById<Button>(R.id.btn_sin)?.setOnClickListener { appendFunction("sin") }
        findViewById<Button>(R.id.btn_cos)?.setOnClickListener { appendFunction("cos") }
        findViewById<Button>(R.id.btn_tan)?.setOnClickListener { appendFunction("tan") }
        findViewById<Button>(R.id.btn_log)?.setOnClickListener { appendFunction("log") }
        findViewById<Button>(R.id.btn_ln)?.setOnClickListener { appendFunction("ln") }
        findViewById<Button>(R.id.btn_power)?.setOnClickListener { appendOperator("^") }
        findViewById<Button>(R.id.btn_sqrt)?.setOnClickListener { appendFunction("sqrt") }
        
        // الأقواس والنقطة
        findViewById<Button>(R.id.btn_left_paren)?.setOnClickListener { expression += "("; updateDisplay() }
        findViewById<Button>(R.id.btn_right_paren)?.setOnClickListener { expression += ")"; updateDisplay() }
        findViewById<Button>(R.id.btn_dot)?.setOnClickListener { expression += "."; updateDisplay() }
        
        // المساواة والمسح
        findViewById<Button>(R.id.btn_equals)?.setOnClickListener { calculate() }
        findViewById<Button>(R.id.btn_clear)?.setOnClickListener { clear() }
        findViewById<Button>(R.id.btn_backspace)?.setOnClickListener { backspace() }
    }
    
    private fun appendNumber(button: Button) {
        expression += button.text
        updateDisplay()
    }
    
    private fun appendOperator(op: String) {
        if (expression.isNotEmpty() && !expression.endsWith(" ")) {
            expression += " $op "
            updateDisplay()
        }
    }
    
    private fun appendFunction(func: String) {
        expression += "$func("
        updateDisplay()
    }
    
    private fun calculate() {
        try {
            val result = evaluateExpression(expression)
            displayText.text = result.toString()
            expression = result.toString()
        } catch (e: Exception) {
            displayText.text = "خطأ"
        }
    }
    
    private fun evaluateExpression(expr: String): Double {
        // تقييم بسيط للتعبير
        return try {
            // هذا تقييم مبسط - في التطبيق الحقيقي، يجب استخدام مكتبة تقييم تعبيرات
            eval(expr)
        } catch (e: Exception) {
            0.0
        }
    }
    
    private fun eval(expression: String): Double {
        // تطبيق بسيط لتقييم التعبيرات
        var expr = expression
        
        // معالجة الدوال المثلثية
        expr = expr.replace(Regex("sin\\(([^)]+)\\)")) { 
            sin(it.groupValues[1].toDouble() * PI / 180).toString() 
        }
        expr = expr.replace(Regex("cos\\(([^)]+)\\)")) { 
            cos(it.groupValues[1].toDouble() * PI / 180).toString() 
        }
        expr = expr.replace(Regex("tan\\(([^)]+)\\)")) { 
            tan(it.groupValues[1].toDouble() * PI / 180).toString() 
        }
        expr = expr.replace(Regex("log\\(([^)]+)\\)")) { 
            log10(it.groupValues[1].toDouble()).toString() 
        }
        expr = expr.replace(Regex("ln\\(([^)]+)\\)")) { 
            ln(it.groupValues[1].toDouble()).toString() 
        }
        expr = expr.replace(Regex("sqrt\\(([^)]+)\\)")) { 
            sqrt(it.groupValues[1].toDouble()).toString() 
        }
        
        // معالجة الأس
        expr = expr.replace(Regex("([0-9.]+)\\^([0-9.]+)")) { 
            it.groupValues[1].toDouble().pow(it.groupValues[2].toDouble()).toString() 
        }
        
        // تقييم التعبير الأساسي
        return evaluateBasic(expr)
    }
    
    private fun evaluateBasic(expr: String): Double {
        // تقييم بسيط للعمليات الأساسية
        return try {
            // هذا تقييم مبسط جداً - يجب استخدام مكتبة متقدمة في الإنتاج
            expr.toDouble()
        } catch (e: Exception) {
            0.0
        }
    }
    
    private fun clear() {
        expression = ""
        updateDisplay()
    }
    
    private fun backspace() {
        if (expression.isNotEmpty()) {
            expression = expression.substring(0, expression.length - 1)
            updateDisplay()
        }
    }
    
    private fun updateDisplay() {
        displayText.text = expression.ifEmpty { "0" }
    }
}