package com.digitalleader

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class CulturalWeekActivity : AppCompatActivity() {
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cultural_week)
        
        val logo: ImageView = findViewById(R.id.cultural_week_logo)
        val description: TextView = findViewById(R.id.cultural_week_description)
        
        description.text = getString(R.string.cultural_week_description)
    }
}
