package com.digitalleader

import android.os.Bundle
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

class TimePlanActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_time_plan)
        
        // سيتم ملء الصور هنا
        val examImage: ImageView = findViewById(R.id.exam_image)
        val holidayImage: ImageView = findViewById(R.id.holiday_image)
        val normalImage: ImageView = findViewById(R.id.normal_image)
    }
}
