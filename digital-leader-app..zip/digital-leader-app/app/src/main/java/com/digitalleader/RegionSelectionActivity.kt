package com.digitalleader

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import androidx.appcompat.app.AppCompatActivity

class RegionSelectionActivity : AppCompatActivity() {
    
    private lateinit var regionRadioGroup: RadioGroup
    private lateinit var nextButton: Button
    
    private val regions = mapOf(
        "صنعاء" to PrayerTimes(5, 35, 12, 15, 15, 30, 18, 0, 19, 30),
        "عدن" to PrayerTimes(5, 40, 12, 20, 15, 35, 18, 5, 19, 35),
        "تعز" to PrayerTimes(5, 38, 12, 18, 15, 33, 18, 3, 19, 33),
        "إب" to PrayerTimes(5, 36, 12, 16, 15, 31, 18, 1, 19, 31),
        "سيئون" to PrayerTimes(5, 45, 12, 25, 15, 40, 18, 10, 19, 40),
        "المكلا" to PrayerTimes(5, 50, 12, 30, 15, 45, 18, 15, 19, 45),
        "حضرموت" to PrayerTimes(5, 47, 12, 27, 15, 42, 18, 12, 19, 42),
        "الحديدة" to PrayerTimes(5, 33, 12, 13, 15, 28, 17, 58, 19, 28)
    )
    
    data class PrayerTimes(
        val fajrHour: Int, val fajrMinute: Int,
        val dhuhrHour: Int, val dhuhrMinute: Int,
        val asrHour: Int, val asrMinute: Int,
        val maghribHour: Int, val maghribMinute: Int,
        val ishaHour: Int, val ishaMinute: Int
    )
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_region_selection)
        
        regionRadioGroup = findViewById(R.id.region_radio_group)
        nextButton = findViewById(R.id.next_button)
        
        // إضافة المناطق
        for ((regionName, _) in regions) {
            val radioButton = RadioButton(this)
            radioButton.text = regionName
            radioButton.tag = regionName
            radioButton.textSize = 16f
            regionRadioGroup.addView(radioButton)
        }
        
        // تحديد سيئون بشكل افتراضي
        val defaultButton = regionRadioGroup.findViewWithTag<RadioButton>("سيئون")
        defaultButton?.isChecked = true
        
        nextButton.setOnClickListener {
            val selectedRegionId = regionRadioGroup.checkedRadioButtonId
            if (selectedRegionId != -1) {
                val selectedButton = findViewById<RadioButton>(selectedRegionId)
                val selectedRegion = selectedButton.tag as String
                val prayerTimes = regions[selectedRegion]
                
                val sharedPreferences = getSharedPreferences("app_prefs", MODE_PRIVATE)
                sharedPreferences.edit().apply {
                    putString("selected_region", selectedRegion)
                    putInt("fajr_hour", prayerTimes?.fajrHour ?: 5)
                    putInt("fajr_minute", prayerTimes?.fajrMinute ?: 35)
                    putInt("dhuhr_hour", prayerTimes?.dhuhrHour ?: 12)
                    putInt("dhuhr_minute", prayerTimes?.dhuhrMinute ?: 15)
                    putInt("asr_hour", prayerTimes?.asrHour ?: 15)
                    putInt("asr_minute", prayerTimes?.asrMinute ?: 30)
                    putInt("maghrib_hour", prayerTimes?.maghribHour ?: 18)
                    putInt("maghrib_minute", prayerTimes?.maghribMinute ?: 0)
                    putInt("isha_hour", prayerTimes?.ishaHour ?: 19)
                    putInt("isha_minute", prayerTimes?.ishaMinute ?: 30)
                    putBoolean("region_selected", true)
                    apply()
                }
                
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            }
        }
    }
}
