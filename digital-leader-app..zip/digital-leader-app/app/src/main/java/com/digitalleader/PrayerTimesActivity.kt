package com.digitalleader

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class PrayerTimesActivity : AppCompatActivity() {
    
    private lateinit var regionText: TextView
    private lateinit var prayerTimesContainer: LinearLayout
    private lateinit var editButton: Button
    
    private val prayers = listOf(
        Triple("الفجر", "fajr", "🌅"),
        Triple("الظهر", "dhuhr", "☀️"),
        Triple("العصر", "asr", "🌤️"),
        Triple("المغرب", "maghrib", "🌅"),
        Triple("العشاء", "isha", "🌙")
    )
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_prayer_times)
        
        regionText = findViewById(R.id.region_text)
        prayerTimesContainer = findViewById(R.id.prayer_times_container)
        editButton = findViewById(R.id.edit_button)
        
        val sharedPreferences = getSharedPreferences("app_prefs", MODE_PRIVATE)
        val selectedRegion = sharedPreferences.getString("selected_region", "سيئون") ?: "سيئون"
        
        regionText.text = "المنطقة: $selectedRegion"
        
        displayPrayerTimes(sharedPreferences)
        
        editButton.setOnClickListener {
            showEditDialog(sharedPreferences)
        }
    }
    
    private fun displayPrayerTimes(sharedPreferences: android.content.SharedPreferences) {
        prayerTimesContainer.removeAllViews()
        
        for ((prayerName, prayerKey, emoji) in prayers) {
            val hour = sharedPreferences.getInt("${prayerKey}_hour", 0)
            val minute = sharedPreferences.getInt("${prayerKey}_minute", 0)
            val timeString = String.format("%02d:%02d", hour, minute)
            
            val cardView = createPrayerCard(prayerName, timeString, emoji)
            prayerTimesContainer.addView(cardView)
        }
    }
    
    private fun createPrayerCard(prayerName: String, time: String, emoji: String): LinearLayout {
        val card = LinearLayout(this)
        card.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        card.orientation = LinearLayout.HORIZONTAL
        card.setPadding(16, 12, 16, 12)
        card.setBackgroundResource(R.drawable.prayer_card_background)
        
        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        params.bottomMargin = 12
        card.layoutParams = params
        
        // الاسم والإيموجي
        val nameLayout = LinearLayout(this)
        nameLayout.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        nameLayout.orientation = LinearLayout.HORIZONTAL
        
        val emojiText = TextView(this)
        emojiText.text = emoji
        emojiText.textSize = 24f
        emojiText.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        nameLayout.addView(emojiText)
        
        val nameText = TextView(this)
        nameText.text = prayerName
        nameText.textSize = 16f
        nameText.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        (nameText.layoutParams as LinearLayout.LayoutParams).marginStart = 12
        nameLayout.addView(nameText)
        
        card.addView(nameLayout)
        
        // الوقت
        val timeText = TextView(this)
        timeText.text = time
        timeText.textSize = 18f
        timeText.setTypeface(null, android.graphics.Typeface.BOLD) // تم التصحيح هنا
        timeText.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        card.addView(timeText)
        
        return card
    }
    
    private fun showEditDialog(sharedPreferences: android.content.SharedPreferences) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("تعديل مواقيت الصلاة")
        
        val container = LinearLayout(this)
        container.orientation = LinearLayout.VERTICAL
        container.setPadding(16, 16, 16, 16)
        
        val inputs = mutableMapOf<String, Pair<EditText, EditText>>()
        
        for ((prayerName, prayerKey, _) in prayers) {
            val label = TextView(this)
            label.text = prayerName
            label.textSize = 14f
            label.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            (label.layoutParams as LinearLayout.LayoutParams).topMargin = 8
            container.addView(label)
            
            val timeLayout = LinearLayout(this)
            timeLayout.orientation = LinearLayout.HORIZONTAL
            timeLayout.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            
            val hourInput = EditText(this)
            hourInput.hint = "ساعة"
            hourInput.inputType = android.text.InputType.TYPE_CLASS_NUMBER
            hourInput.setText(sharedPreferences.getInt("${prayerKey}_hour", 0).toString())
            hourInput.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            timeLayout.addView(hourInput)
            
            val minuteInput = EditText(this)
            minuteInput.hint = "دقيقة"
            minuteInput.inputType = android.text.InputType.TYPE_CLASS_NUMBER
            minuteInput.setText(sharedPreferences.getInt("${prayerKey}_minute", 0).toString())
            minuteInput.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            (minuteInput.layoutParams as LinearLayout.LayoutParams).marginStart = 8
            timeLayout.addView(minuteInput)
            
            container.addView(timeLayout)
            
            inputs[prayerKey] = Pair(hourInput, minuteInput)
        }
        
        builder.setView(container)
        
        builder.setPositiveButton("حفظ") { _, _ ->
            for ((prayerKey, pair) in inputs) {
                val hour = pair.first.text.toString().toIntOrNull() ?: 0
                val minute = pair.second.text.toString().toIntOrNull() ?: 0
                
                sharedPreferences.edit().apply {
                    putInt("${prayerKey}_hour", hour)
                    putInt("${prayerKey}_minute", minute)
                    apply()
                }
            }
            
            displayPrayerTimes(sharedPreferences)
            Toast.makeText(this, "تم حفظ المواقيت", Toast.LENGTH_SHORT).show()
        }
        
        builder.setNegativeButton("إلغاء") { dialog, _ ->
            dialog.dismiss()
        }
        
        builder.show()
    }
}