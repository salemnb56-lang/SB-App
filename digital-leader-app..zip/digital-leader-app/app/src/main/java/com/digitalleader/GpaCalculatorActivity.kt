package com.digitalleader

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class GpaCalculatorActivity : AppCompatActivity() {
    
    private lateinit var examTypeSpinner: Spinner
    private lateinit var subjectsContainer: LinearLayout
    private lateinit var addSubjectButton: Button
    private lateinit var calculateButton: Button
    private lateinit var targetPercentageInput: EditText
    private lateinit var resultText: TextView
    
    private val subjects = mutableListOf<SubjectInput>()
    
    data class SubjectInput(
        val nameInput: EditText,
        val scoreInput: EditText,
        val removeButton: Button
    )
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gpa_calculator)
        
        initializeUI()
        setupListeners()
    }
    
    private fun initializeUI() {
        examTypeSpinner = findViewById(R.id.exam_type_spinner)
        subjectsContainer = findViewById(R.id.subjects_container)
        addSubjectButton = findViewById(R.id.add_subject_button)
        calculateButton = findViewById(R.id.calculate_button)
        targetPercentageInput = findViewById(R.id.target_percentage_input)
        resultText = findViewById(R.id.result_text)
        
        // إعداد Spinner
        val adapter = ArrayAdapter.createFromResource(
            this,
            R.array.exam_types,
            android.R.layout.simple_spinner_item
        )
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        examTypeSpinner.adapter = adapter
    }
    
    private fun setupListeners() {
        addSubjectButton.setOnClickListener { addSubjectField() }
        calculateButton.setOnClickListener { calculateGPA() }
    }
    
    private fun addSubjectField() {
        val container = LinearLayout(this)
        container.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        container.orientation = LinearLayout.HORIZONTAL
        
        val nameInput = EditText(this)
        nameInput.hint = getString(R.string.subject)
        nameInput.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        
        val scoreInput = EditText(this)
        scoreInput.hint = getString(R.string.score)
        scoreInput.inputType = android.text.InputType.TYPE_CLASS_NUMBER
        scoreInput.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        
        val removeButton = Button(this)
        removeButton.text = getString(R.string.delete)
        removeButton.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        
        container.addView(nameInput)
        container.addView(scoreInput)
        container.addView(removeButton)
        
        val subject = SubjectInput(nameInput, scoreInput, removeButton)
        subjects.add(subject)
        
        removeButton.setOnClickListener {
            subjectsContainer.removeView(container)
            subjects.remove(subject)
        }
        
        subjectsContainer.addView(container)
    }
    
    private fun calculateGPA() {
        if (subjects.isEmpty()) {
            Toast.makeText(this, "يرجى إضافة مادة واحدة على الأقل", Toast.LENGTH_SHORT).show()
            return
        }
        
        val examType = examTypeSpinner.selectedItemPosition
        val maxScore = when (examType) {
            0 -> 40 // اختبارات شهرية
            1 -> 30 // نصفية أو نهائية
            2 -> 100 // وزارية
            else -> 100
        }
        
        var totalScore = 0.0
        var count = 0
        
        for (subject in subjects) {
            val score = subject.scoreInput.text.toString().toDoubleOrNull() ?: 0.0
            totalScore += score
            count++
        }
        
        val percentage = (totalScore / (maxScore * count)) * 100
        
        val targetPercentage = targetPercentageInput.text.toString().toDoubleOrNull()
        
        val resultMessage = if (targetPercentage != null && targetPercentage > 0) {
            val needed = (targetPercentage * maxScore * count) / 100 - totalScore
            if (needed > 0) {
                "المعدل الحالي: %.2f%%\nتحتاج إلى %.2f نقطة إضافية للوصول إلى هدفك".format(percentage, needed)
            } else {
                "المعدل الحالي: %.2f%%\nأنت قد وصلت بالفعل إلى هدفك!".format(percentage)
            }
        } else {
            "المعدل الحالي: %.2f%%".format(percentage)
        }
        
        resultText.text = resultMessage
    }
}
