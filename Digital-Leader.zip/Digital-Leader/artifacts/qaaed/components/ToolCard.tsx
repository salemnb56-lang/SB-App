import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useRouter } from "expo-router";
import React from "react";
import { Platform, Pressable, StyleSheet, View } from "react-native";

import { ThemedText } from "@/components/ThemedText";
import { useColors } from "@/hooks/useColors";

interface ToolCardProps {
  title: string;
  subtitle: string;
  icon: keyof typeof Feather.glyphMap;
  route: "/calculator" | "/tasks" | "/scientific" | "/plan" | "/formulas" | "/timer";
  accent?: string;
}

export function ToolCard({ title, subtitle, icon, route, accent }: ToolCardProps) {
  const colors = useColors();
  const router = useRouter();
  const accentColor = accent ?? colors.secondary;

  return (
    <Pressable
      onPress={() => {
        if (Platform.OS !== "web") {
          Haptics.selectionAsync().catch(() => {});
        }
        router.push(route);
      }}
      style={({ pressed }) => [
        styles.card,
        {
          backgroundColor: colors.card,
          borderColor: pressed ? accentColor : colors.border,
          opacity: pressed ? 0.9 : 1,
          transform: [{ scale: pressed ? 0.97 : 1 }],
          shadowColor: accentColor,
          shadowOpacity: 0.06,
          shadowRadius: 10,
          shadowOffset: { width: 0, height: 4 },
          elevation: 1,
        },
      ]}
    >
      <View style={styles.topRow}>
        <View style={[styles.iconWrap, { backgroundColor: accentColor + "1A" }]}>
          <Feather name={icon} size={22} color={accentColor} />
        </View>
        <View style={[styles.dot, { backgroundColor: accentColor }]} />
      </View>
      <View style={{ marginTop: 12 }}>
        <ThemedText variant="heading" align="right" weight="bold" numberOfLines={1}>
          {title}
        </ThemedText>
        <ThemedText
          variant="caption"
          align="right"
          color={colors.mutedForeground}
          numberOfLines={2}
          style={{ marginTop: 4, lineHeight: 18 }}
        >
          {subtitle}
        </ThemedText>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    borderRadius: 18,
    borderWidth: 1,
    padding: 14,
    minHeight: 130,
    justifyContent: "space-between",
  },
  topRow: {
    flexDirection: "row-reverse",
    justifyContent: "space-between",
    alignItems: "center",
  },
  iconWrap: {
    width: 44,
    height: 44,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
  },
  dot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    opacity: 0.6,
  },
});
