import { Feather } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { Image } from "expo-image";
import { useRouter } from "expo-router";
import React, { useEffect, useRef } from "react";
import {
  Animated,
  Dimensions,
  Easing,
  Modal,
  Pressable,
  StyleSheet,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { ThemedText } from "@/components/ThemedText";
import { useDrawer } from "@/contexts/DrawerContext";
import { ThemeMode, useTheme } from "@/contexts/ThemeContext";
import { useUser } from "@/contexts/UserContext";
import { useColors } from "@/hooks/useColors";

const { width: SCREEN_W } = Dimensions.get("window");
const DRAWER_W = Math.min(330, SCREEN_W * 0.86);

const THEME_OPTIONS: { value: ThemeMode; label: string; icon: keyof typeof Feather.glyphMap }[] = [
  { value: "light", label: "فاتح", icon: "sun" },
  { value: "dark", label: "داكن", icon: "moon" },
  { value: "system", label: "النظام", icon: "smartphone" },
  { value: "auto", label: "تلقائي حسب الوقت", icon: "clock" },
];

const DRAWER_ITEMS: {
  label: string;
  icon: keyof typeof Feather.glyphMap;
  route: "/cultural" | "/calculator" | "/tasks" | "/scientific" | "/plan" | "/formulas" | "/timer";
  color?: string;
}[] = [
  { label: "حاسبة المعدل", icon: "percent", route: "/calculator" },
  { label: "منظم المهام", icon: "check-square", route: "/tasks" },
  { label: "الآلة الحاسبة العلمية", icon: "cpu", route: "/scientific" },
  { label: "خطة تنظيم الوقت", icon: "calendar", route: "/plan" },
  { label: "المرجع السريع للقوانين", icon: "book-open", route: "/formulas" },
  { label: "المؤقت الدراسي", icon: "clock", route: "/timer" },
  { label: "عن الأسبوع الثقافي", icon: "info", route: "/cultural" },
];

export function AppDrawer() {
  const { open, setOpen } = useDrawer();
  const colors = useColors();
  const { mode, setMode } = useTheme();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { name } = useUser();

  const translateX = useRef(new Animated.Value(DRAWER_W)).current;
  const fade = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(translateX, {
        toValue: open ? 0 : DRAWER_W,
        duration: 280,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: true,
      }),
      Animated.timing(fade, {
        toValue: open ? 1 : 0,
        duration: 240,
        useNativeDriver: true,
      }),
    ]).start();
  }, [open, translateX, fade]);

  const navigate = (route: (typeof DRAWER_ITEMS)[number]["route"]) => {
    setOpen(false);
    setTimeout(() => router.push(route), 240);
  };

  const goDeveloper = () => {
    setOpen(false);
    setTimeout(() => router.push("/developer"), 240);
  };

  return (
    <Modal visible={open} transparent animationType="none" onRequestClose={() => setOpen(false)}>
      <View style={StyleSheet.absoluteFill}>
        <Animated.View
          style={[
            StyleSheet.absoluteFill,
            { backgroundColor: colors.overlay, opacity: fade },
          ]}
        >
          <Pressable style={StyleSheet.absoluteFill} onPress={() => setOpen(false)} />
        </Animated.View>

        <Animated.View
          style={[
            styles.drawer,
            {
              width: DRAWER_W,
              backgroundColor: colors.background,
              borderLeftColor: colors.border,
              transform: [{ translateX }],
              paddingBottom: insets.bottom + 16,
            },
          ]}
        >
          {/* Gradient brand header */}
          <LinearGradient
            colors={[colors.gradientFrom, colors.gradientTo]}
            start={{ x: 1, y: 0 }}
            end={{ x: 0, y: 1 }}
            style={[
              styles.brand,
              { paddingTop: insets.top + 24, paddingBottom: 22, paddingHorizontal: 18 },
            ]}
          >
            <View style={styles.brandRow}>
              <View style={[styles.logoWrap, { backgroundColor: "rgba(255,255,255,0.18)" }]}>
                <Image
                  source={require("@/assets/images/app_logo.png")}
                  style={styles.logo}
                  contentFit="contain"
                />
              </View>
              <View style={{ flex: 1, marginRight: 12 }}>
                <ThemedText color="#FFFFFF" align="right" weight="bold" style={{ fontSize: 18 }}>
                  القائد الرقمي
                </ThemedText>
                {name ? (
                  <ThemedText color="rgba(255,255,255,0.75)" align="right" variant="caption">
                    مرحباً، {name}
                  </ThemedText>
                ) : (
                  <ThemedText color="rgba(255,255,255,0.75)" align="right" variant="caption">
                    مساعدك الدراسي
                  </ThemedText>
                )}
              </View>
            </View>
          </LinearGradient>

          {/* Theme toggle */}
          <View style={styles.section}>
            <View style={styles.sectionHead}>
              <View style={[styles.sectionDot, { backgroundColor: colors.accent }]} />
              <ThemedText variant="subtitle" align="right" weight="semibold" style={{ marginRight: 8 }}>
                المظهر
              </ThemedText>
            </View>
            <View style={styles.themeGrid}>
              {THEME_OPTIONS.map((opt) => {
                const active = mode === opt.value;
                return (
                  <Pressable
                    key={opt.value}
                    onPress={() => setMode(opt.value)}
                    style={({ pressed }) => [
                      styles.themeBtn,
                      {
                        backgroundColor: active ? colors.secondary : colors.muted,
                        opacity: pressed ? 0.8 : 1,
                      },
                    ]}
                  >
                    <Feather
                      name={opt.icon}
                      size={16}
                      color={active ? "#FFFFFF" : colors.foreground}
                    />
                    <ThemedText
                      variant="caption"
                      align="center"
                      color={active ? "#FFFFFF" : colors.foreground}
                      style={{ marginTop: 6 }}
                      weight="semibold"
                    >
                      {opt.label}
                    </ThemedText>
                  </Pressable>
                );
              })}
            </View>
          </View>

          {/* Items */}
          <View style={styles.itemsSection}>
            <View style={styles.sectionHead}>
              <View style={[styles.sectionDot, { backgroundColor: colors.secondary }]} />
              <ThemedText variant="subtitle" align="right" weight="semibold" style={{ marginRight: 8 }}>
                التنقل
              </ThemedText>
            </View>
            <View style={{ marginTop: 6 }}>
              {DRAWER_ITEMS.map((item) => (
                <Pressable
                  key={item.route}
                  onPress={() => navigate(item.route)}
                  style={({ pressed }) => [
                    styles.item,
                    { backgroundColor: pressed ? colors.muted : "transparent" },
                  ]}
                >
                  <View style={[styles.itemIcon, { backgroundColor: colors.muted }]}>
                    <Feather name={item.icon} size={16} color={colors.secondary} />
                  </View>
                  <ThemedText variant="default" align="right" weight="medium" style={{ flex: 1, marginRight: 12 }}>
                    {item.label}
                  </ThemedText>
                  <Feather name="chevron-left" size={16} color={colors.mutedForeground} />
                </Pressable>
              ))}
            </View>
          </View>

          {/* Developer footer */}
          <Pressable
            onPress={goDeveloper}
            style={({ pressed }) => [
              styles.devFooter,
              {
                backgroundColor: pressed ? colors.muted : colors.card,
                borderTopColor: colors.border,
              },
            ]}
          >
            <View style={[styles.devAvatar, { backgroundColor: colors.secondary, borderColor: colors.accent }]}>
              <Feather name="user" size={18} color="#FFFFFF" />
            </View>
            <View style={{ flex: 1, marginRight: 12 }}>
              <ThemedText variant="subtitle" align="right" weight="semibold">
                عن المطور
              </ThemedText>
              <ThemedText variant="caption" align="right" color={colors.mutedForeground}>
                تواصل وتعرف على فريق العمل
              </ThemedText>
            </View>
            <Feather name="chevron-left" size={18} color={colors.mutedForeground} />
          </Pressable>
        </Animated.View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  drawer: {
    position: "absolute",
    top: 0,
    bottom: 0,
    right: 0,
    borderLeftWidth: StyleSheet.hairlineWidth,
  },
  brand: {},
  brandRow: { flexDirection: "row-reverse", alignItems: "center" },
  logoWrap: {
    width: 56,
    height: 56,
    borderRadius: 18,
    alignItems: "center",
    justifyContent: "center",
  },
  logo: { width: 40, height: 40 },
  section: { paddingHorizontal: 18, paddingTop: 18, paddingBottom: 8 },
  itemsSection: { paddingHorizontal: 18, paddingTop: 14, flex: 1 },
  sectionHead: { flexDirection: "row-reverse", alignItems: "center", marginBottom: 10 },
  sectionDot: { width: 6, height: 6, borderRadius: 3 },
  themeGrid: { flexDirection: "row-reverse", flexWrap: "wrap", gap: 8 },
  themeBtn: {
    flexBasis: "48%",
    paddingVertical: 12,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  item: {
    flexDirection: "row-reverse",
    alignItems: "center",
    paddingHorizontal: 10,
    paddingVertical: 11,
    borderRadius: 12,
    marginBottom: 4,
  },
  itemIcon: {
    width: 36,
    height: 36,
    borderRadius: 11,
    alignItems: "center",
    justifyContent: "center",
  },
  devFooter: {
    flexDirection: "row-reverse",
    alignItems: "center",
    paddingTop: 14,
    paddingHorizontal: 18,
    paddingBottom: 14,
    borderTopWidth: StyleSheet.hairlineWidth,
  },
  devAvatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 2,
  },
});
