import React from "react";
import { StyleSheet, Text, TextProps, TextStyle } from "react-native";

import { useColors } from "@/hooks/useColors";

type Variant = "default" | "title" | "heading" | "subtitle" | "muted" | "caption" | "display";

interface ThemedTextProps extends TextProps {
  variant?: Variant;
  color?: string;
  align?: "left" | "right" | "center";
  weight?: "regular" | "medium" | "semibold" | "bold";
}

const FONT_MAP: Record<NonNullable<ThemedTextProps["weight"]>, string> = {
  regular: "Cairo_400Regular",
  medium: "Cairo_500Medium",
  semibold: "Cairo_600SemiBold",
  bold: "Cairo_700Bold",
};

function getFontFamily(weight: TextStyle["fontWeight"] | undefined): string {
  if (weight === "700" || weight === "bold") return FONT_MAP.bold;
  if (weight === "600") return FONT_MAP.semibold;
  if (weight === "500") return FONT_MAP.medium;
  return FONT_MAP.regular;
}

export function ThemedText({
  variant = "default",
  color,
  align = "right",
  weight,
  style,
  ...rest
}: ThemedTextProps) {
  const colors = useColors();

  const variantStyle = variantStyles[variant];

  const fontWeight: TextStyle["fontWeight"] = weight
    ? weightMap[weight]
    : (variantStyle.fontWeight as TextStyle["fontWeight"]);

  const fontFamily = weight ? FONT_MAP[weight] : getFontFamily(variantStyle.fontWeight as TextStyle["fontWeight"]);

  return (
    <Text
      style={[
        {
          color: color ?? colors.foreground,
          textAlign: align,
          writingDirection: "rtl",
          fontFamily,
        },
        variantStyle,
        { fontWeight },
        style,
      ]}
      {...rest}
    />
  );
}

const weightMap: Record<string, TextStyle["fontWeight"]> = {
  regular: "400",
  medium: "500",
  semibold: "600",
  bold: "700",
};

const variantStyles = StyleSheet.create({
  default: { fontSize: 15, fontWeight: "400" },
  title: { fontSize: 22, fontWeight: "700", letterSpacing: 0.2 },
  heading: { fontSize: 17, fontWeight: "700" },
  subtitle: { fontSize: 14, fontWeight: "500" },
  muted: { fontSize: 13, fontWeight: "400", opacity: 0.7 },
  caption: { fontSize: 12, fontWeight: "400" },
  display: { fontSize: 30, fontWeight: "700", letterSpacing: 0.3 },
});
