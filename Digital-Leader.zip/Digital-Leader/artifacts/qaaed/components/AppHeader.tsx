import { Feather } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import React from "react";
import { Pressable, StyleSheet, View } from "react-native";

import { ThemedText } from "@/components/ThemedText";
import { useDrawer } from "@/contexts/DrawerContext";
import { useTasks } from "@/contexts/TasksContext";
import { useTip } from "@/contexts/TipContext";
import { useColors } from "@/hooks/useColors";

interface AppHeaderProps {
  title?: string;
  showBack?: boolean;
  showMenu?: boolean;
  showNotification?: boolean;
}

export function AppHeader({
  title,
  showBack = false,
  showMenu = true,
  showNotification = true,
}: AppHeaderProps) {
  const colors = useColors();
  const router = useRouter();
  const { setOpen } = useDrawer();
  const { pendingTasks } = useTasks();
  const { isReady } = useTip();

  const hasPending = pendingTasks.length > 0;
  const dotColor = hasPending ? colors.destructive : isReady ? colors.success : null;

  return (
    <View
      style={[
        styles.container,
        { borderBottomColor: colors.border, backgroundColor: colors.background },
      ]}
    >
      <View style={styles.side}>
        {showNotification && (
          <Pressable
            onPress={() => router.push("/notification")}
            style={({ pressed }) => [
              styles.iconBtn,
              { backgroundColor: colors.muted, opacity: pressed ? 0.7 : 1 },
            ]}
            hitSlop={8}
          >
            <Feather name="bell" size={20} color={colors.foreground} />
            {dotColor && (
              <View
                style={[
                  styles.dot,
                  { backgroundColor: dotColor, borderColor: colors.background },
                ]}
              />
            )}
          </Pressable>
        )}
      </View>

      <View style={styles.center}>
        {title ? (
          <ThemedText variant="heading" align="center">
            {title}
          </ThemedText>
        ) : null}
      </View>

      <View style={styles.side}>
        {showBack ? (
          <Pressable
            onPress={() => router.back()}
            style={({ pressed }) => [
              styles.iconBtn,
              { backgroundColor: colors.muted, opacity: pressed ? 0.7 : 1 },
            ]}
            hitSlop={8}
          >
            <Feather name="chevron-right" size={22} color={colors.foreground} />
          </Pressable>
        ) : showMenu ? (
          <Pressable
            onPress={() => setOpen(true)}
            style={({ pressed }) => [
              styles.iconBtn,
              { backgroundColor: colors.muted, opacity: pressed ? 0.7 : 1 },
            ]}
            hitSlop={8}
          >
            <Feather name="menu" size={22} color={colors.foreground} />
          </Pressable>
        ) : null}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  side: { width: 44, height: 44, alignItems: "center", justifyContent: "center" },
  center: { flex: 1, alignItems: "center", justifyContent: "center" },
  iconBtn: {
    width: 42,
    height: 42,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
  },
  dot: {
    position: "absolute",
    top: 8,
    left: 8,
    width: 10,
    height: 10,
    borderRadius: 5,
    borderWidth: 2,
  },
});
