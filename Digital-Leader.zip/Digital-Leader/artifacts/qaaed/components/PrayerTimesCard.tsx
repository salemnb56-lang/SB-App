import { Feather } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import React, { useEffect, useMemo, useState } from "react";
import { Modal, Pressable, ScrollView, StyleSheet, View } from "react-native";

import { ThemedText } from "@/components/ThemedText";
import { usePrayer } from "@/contexts/PrayerContext";
import { useColors } from "@/hooks/useColors";
import {
  PRAYER_LABELS,
  PRAYER_ORDER,
  PrayerKey,
  computePrayerTimes,
  formatPrayerTime,
  getNextPrayer,
} from "@/lib/prayerTimes";

const PRAYER_ICONS: Record<PrayerKey, keyof typeof Feather.glyphMap> = {
  fajr: "moon",
  sunrise: "sunrise",
  dhuhr: "sun",
  asr: "cloud-snow",
  maghrib: "sunset",
  isha: "star",
};

function pad2(n: number) {
  return n < 10 ? `0${n}` : String(n);
}

function formatRemaining(ms: number) {
  const total = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  if (h > 0) return `${h} س ${pad2(m)} د`;
  return `${m} د ${pad2(s)} ث`;
}

export function PrayerTimesCard() {
  const colors = useColors();
  const { city, cities, setCityById } = usePrayer();
  const [now, setNow] = useState<Date>(new Date());
  const [pickerOpen, setPickerOpen] = useState(false);

  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);

  const times = useMemo(() => computePrayerTimes(now, city), [now, city]);
  const next = useMemo(() => getNextPrayer(times, now), [times, now]);

  return (
    <>
      <LinearGradient
        colors={[colors.gradientFrom, colors.gradientTo]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.card}
      >
        <View style={styles.headerRow}>
          <View style={[styles.iconBubble, { backgroundColor: "rgba(255,255,255,0.18)" }]}>
            <Feather name={PRAYER_ICONS[next.key]} size={18} color="#FFFFFF" />
          </View>
          <View style={{ flex: 1, marginHorizontal: 10 }}>
            <ThemedText
              variant="caption"
              align="right"
              color="rgba(255,255,255,0.7)"
              weight="semibold"
            >
              الصلاة القادمة
            </ThemedText>
            <ThemedText
              align="right"
              color="#FFFFFF"
              weight="bold"
              style={{ fontSize: 22, marginTop: 2 }}
            >
              {PRAYER_LABELS[next.key]} · {formatPrayerTime(next.at)}
            </ThemedText>
          </View>
          <Pressable
            onPress={() => setPickerOpen(true)}
            style={({ pressed }) => [
              styles.cityBtn,
              { backgroundColor: "rgba(255,255,255,0.15)", opacity: pressed ? 0.8 : 1 },
            ]}
          >
            <Feather name="map-pin" size={13} color="#FFFFFF" />
            <ThemedText
              color="#FFFFFF"
              style={{ fontSize: 12, marginRight: 4 }}
              weight="semibold"
            >
              {city.name}
            </ThemedText>
          </Pressable>
        </View>

        <View style={styles.countdownRow}>
          <ThemedText
            color="rgba(255,255,255,0.85)"
            align="center"
            weight="semibold"
            style={{ fontSize: 13 }}
          >
            متبقي {formatRemaining(next.remainingMs)}
          </ThemedText>
        </View>

        <View style={styles.divider} />

        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.timesRow}
        >
          {PRAYER_ORDER.map((key) => {
            const isNext = key === next.key && !next.isTomorrow;
            return (
              <View
                key={key}
                style={[
                  styles.timeBlock,
                  {
                    backgroundColor: isNext
                      ? "rgba(255,255,255,0.22)"
                      : "rgba(255,255,255,0.06)",
                    borderColor: isNext ? "rgba(255,255,255,0.4)" : "transparent",
                  },
                ]}
              >
                <Feather
                  name={PRAYER_ICONS[key]}
                  size={14}
                  color={isNext ? "#FFFFFF" : "rgba(255,255,255,0.8)"}
                />
                <ThemedText
                  color={isNext ? "#FFFFFF" : "rgba(255,255,255,0.85)"}
                  weight="semibold"
                  align="center"
                  style={{ fontSize: 12, marginTop: 4 }}
                >
                  {PRAYER_LABELS[key]}
                </ThemedText>
                <ThemedText
                  color={isNext ? "#FFFFFF" : "rgba(255,255,255,0.7)"}
                  align="center"
                  weight={isNext ? "bold" : "semibold"}
                  style={{ fontSize: 11, marginTop: 2, fontVariant: ["tabular-nums"] }}
                >
                  {formatPrayerTime(times[key])}
                </ThemedText>
              </View>
            );
          })}
        </ScrollView>
      </LinearGradient>

      <Modal
        visible={pickerOpen}
        animationType="slide"
        transparent
        onRequestClose={() => setPickerOpen(false)}
      >
        <Pressable
          style={[styles.modalBackdrop, { backgroundColor: colors.overlay }]}
          onPress={() => setPickerOpen(false)}
        >
          <Pressable
            style={[styles.modalSheet, { backgroundColor: colors.card, borderColor: colors.border }]}
            onPress={(e) => e.stopPropagation()}
          >
            <View style={styles.modalHandle} />
            <View style={styles.modalHeader}>
              <Pressable onPress={() => setPickerOpen(false)} hitSlop={10}>
                <Feather name="x" size={20} color={colors.foreground} />
              </Pressable>
              <ThemedText variant="heading" align="right" weight="bold">
                اختر مدينتك
              </ThemedText>
            </View>
            <ScrollView style={{ maxHeight: 420 }} showsVerticalScrollIndicator={false}>
              {cities.map((c) => {
                const active = c.id === city.id;
                return (
                  <Pressable
                    key={c.id}
                    onPress={() => {
                      setCityById(c.id);
                      setPickerOpen(false);
                    }}
                    style={({ pressed }) => [
                      styles.cityRow,
                      {
                        backgroundColor: active
                          ? colors.secondary + "1A"
                          : pressed
                          ? colors.muted
                          : "transparent",
                      },
                    ]}
                  >
                    {active ? (
                      <Feather name="check-circle" size={18} color={colors.secondary} />
                    ) : (
                      <Feather name="map-pin" size={18} color={colors.mutedForeground} />
                    )}
                    <ThemedText
                      align="right"
                      weight={active ? "bold" : "semibold"}
                      color={active ? colors.secondary : colors.foreground}
                      style={{ flex: 1, marginRight: 12, fontSize: 16 }}
                    >
                      {c.name}
                    </ThemedText>
                  </Pressable>
                );
              })}
            </ScrollView>
          </Pressable>
        </Pressable>
      </Modal>
    </>
  );
}

const styles = StyleSheet.create({
  card: {
    borderRadius: 22,
    padding: 16,
    overflow: "hidden",
  },
  headerRow: {
    flexDirection: "row-reverse",
    alignItems: "center",
  },
  iconBubble: {
    width: 40,
    height: 40,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
  },
  cityBtn: {
    flexDirection: "row-reverse",
    alignItems: "center",
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 10,
  },
  countdownRow: {
    marginTop: 10,
    paddingVertical: 8,
    borderRadius: 12,
    backgroundColor: "rgba(255,255,255,0.08)",
  },
  divider: {
    marginVertical: 12,
    height: 1,
    backgroundColor: "rgba(255,255,255,0.12)",
  },
  timesRow: {
    flexDirection: "row-reverse",
    gap: 8,
    paddingHorizontal: 2,
  },
  timeBlock: {
    width: 76,
    paddingVertical: 12,
    paddingHorizontal: 4,
    borderRadius: 14,
    alignItems: "center",
    borderWidth: 1,
  },
  modalBackdrop: {
    flex: 1,
    justifyContent: "flex-end",
  },
  modalSheet: {
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    borderTopWidth: 1,
    paddingHorizontal: 20,
    paddingTop: 12,
    paddingBottom: 32,
  },
  modalHandle: {
    width: 44,
    height: 4,
    borderRadius: 2,
    backgroundColor: "rgba(127,127,127,0.4)",
    alignSelf: "center",
    marginBottom: 12,
  },
  modalHeader: {
    flexDirection: "row-reverse",
    justifyContent: "space-between",
    alignItems: "center",
    paddingBottom: 14,
  },
  cityRow: {
    flexDirection: "row-reverse",
    alignItems: "center",
    paddingHorizontal: 12,
    paddingVertical: 14,
    borderRadius: 12,
  },
});
