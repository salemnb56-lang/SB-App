import React, { useState } from "react";
import {
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  StyleSheet,
  TextInput,
  View,
} from "react-native";

import { ThemedText } from "@/components/ThemedText";
import { useUser } from "@/contexts/UserContext";
import { useColors } from "@/hooks/useColors";

export function OnboardingModal() {
  const { needsOnboarding, saveName } = useUser();
  const colors = useColors();
  const [value, setValue] = useState("");

  const handleSave = async () => {
    if (!value.trim()) return;
    await saveName(value);
  };

  return (
    <Modal
      visible={needsOnboarding}
      transparent
      animationType="fade"
      onRequestClose={() => {}}
    >
      <View style={[styles.overlay, { backgroundColor: colors.overlay }]}>
        <KeyboardAvoidingView
          behavior={Platform.OS === "ios" ? "padding" : undefined}
          style={styles.center}
        >
          <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={[styles.badge, { backgroundColor: colors.secondary }]}>
              <ThemedText variant="title" color="#FFFFFF" align="center">
                ق
              </ThemedText>
            </View>
            <ThemedText variant="title" align="center" style={styles.gap}>
              مرحباً بك في القائد الرقمي
            </ThemedText>
            <ThemedText variant="muted" align="center" style={styles.gap}>
              لنُخصّص تجربتك، أخبرنا اسمك أولاً
            </ThemedText>

            <View style={styles.inputWrap}>
              <ThemedText variant="subtitle" align="right" style={styles.label}>
                أدخل اسمك
              </ThemedText>
              <TextInput
                value={value}
                onChangeText={setValue}
                placeholder="مثال: محمد أحمد"
                placeholderTextColor={colors.mutedForeground}
                style={[
                  styles.input,
                  {
                    backgroundColor: colors.input,
                    borderColor: colors.border,
                    color: colors.foreground,
                  },
                ]}
                textAlign="right"
                writingDirection="rtl"
                returnKeyType="done"
                onSubmitEditing={handleSave}
                autoFocus
              />
            </View>

            <Pressable
              onPress={handleSave}
              disabled={!value.trim()}
              style={({ pressed }) => [
                styles.btn,
                {
                  backgroundColor: value.trim() ? colors.secondary : colors.muted,
                  opacity: pressed ? 0.85 : 1,
                },
              ]}
            >
              <ThemedText variant="heading" color="#FFFFFF" align="center">
                حفظ والمتابعة
              </ThemedText>
            </Pressable>
          </View>
        </KeyboardAvoidingView>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, padding: 24 },
  center: { flex: 1, justifyContent: "center" },
  card: {
    borderRadius: 24,
    padding: 24,
    borderWidth: 1,
    gap: 12,
  },
  badge: {
    width: 56,
    height: 56,
    borderRadius: 18,
    alignItems: "center",
    justifyContent: "center",
    alignSelf: "center",
    marginBottom: 4,
  },
  gap: { marginTop: 4 },
  inputWrap: { marginTop: 16, gap: 8 },
  label: { opacity: 0.85 },
  input: {
    height: 52,
    borderRadius: 14,
    borderWidth: 1,
    paddingHorizontal: 16,
    fontSize: 16,
  },
  btn: {
    marginTop: 16,
    height: 54,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
  },
});
