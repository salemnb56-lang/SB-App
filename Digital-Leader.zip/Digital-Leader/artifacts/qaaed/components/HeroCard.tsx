import { Feather } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import React, { useEffect, useRef, useState } from "react";
import { Animated, Easing, StyleSheet, View } from "react-native";

import { ThemedText } from "@/components/ThemedText";
import { useUser } from "@/contexts/UserContext";
import { useColors } from "@/hooks/useColors";
import { formatHijriShort, gregorianToHijri } from "@/lib/hijri";

const ARABIC_DAYS = [
  "الأحد",
  "الاثنين",
  "الثلاثاء",
  "الأربعاء",
  "الخميس",
  "الجمعة",
  "السبت",
];

function pad(n: number) {
  return n < 10 ? `0${n}` : String(n);
}

function getGreeting(name: string | null): { hello: string; emoji: string } {
  const h = new Date().getHours();
  const userName = name ?? "صديقي";
  if (h >= 4 && h < 12) return { hello: `صباح الخير ${userName}`, emoji: "☀️" };
  if (h >= 12 && h < 18) return { hello: `طاب مساؤك ${userName}`, emoji: "🌤️" };
  return { hello: `مساء النور ${userName}`, emoji: "🌙" };
}

export function HeroCard() {
  const colors = useColors();
  const { name } = useUser();
  const [now, setNow] = useState(new Date());

  const shimmer = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(shimmer, {
          toValue: 1,
          duration: 4000,
          easing: Easing.inOut(Easing.sin),
          useNativeDriver: true,
        }),
        Animated.timing(shimmer, {
          toValue: 0,
          duration: 4000,
          easing: Easing.inOut(Easing.sin),
          useNativeDriver: true,
        }),
      ]),
    );
    loop.start();
    return () => loop.stop();
  }, [shimmer]);

  const greeting = getGreeting(name);
  const dayName = ARABIC_DAYS[now.getDay()];
  const hijri = gregorianToHijri(now);
  const timeStr = `${pad(now.getHours())}:${pad(now.getMinutes())}`;
  const seconds = pad(now.getSeconds());

  const orbX = shimmer.interpolate({ inputRange: [0, 1], outputRange: [-20, 20] });
  const orbY = shimmer.interpolate({ inputRange: [0, 1], outputRange: [-10, 10] });

  return (
    <LinearGradient
      colors={[colors.gradientFrom, colors.gradientTo]}
      start={{ x: 1, y: 0 }}
      end={{ x: 0, y: 1 }}
      style={styles.card}
    >
      {/* Decorative orbs */}
      <Animated.View
        style={[
          styles.orb,
          {
            backgroundColor: colors.accent + "44",
            top: -40,
            left: -30,
            transform: [{ translateX: orbX }, { translateY: orbY }],
          },
        ]}
      />
      <Animated.View
        style={[
          styles.orbSmall,
          {
            backgroundColor: "rgba(255,255,255,0.08)",
            bottom: -20,
            right: 40,
            transform: [{ translateX: orbX }, { translateY: orbY }],
          },
        ]}
      />

      <View style={styles.topRow}>
        <View style={[styles.greetBadge, { backgroundColor: "rgba(255,255,255,0.15)" }]}>
          <ThemedText
            color="#FFFFFF"
            style={{ fontSize: 11 }}
            weight="semibold"
            align="center"
          >
            {greeting.emoji}  مرحباً بعودتك
          </ThemedText>
        </View>
      </View>

      <ThemedText
        align="right"
        color="#FFFFFF"
        weight="bold"
        style={{ fontSize: 26, marginTop: 14, lineHeight: 36 }}
      >
        {greeting.hello}
      </ThemedText>

      <View style={styles.metaRow}>
        <View style={styles.metaBlock}>
          <ThemedText
            color="rgba(255,255,255,0.72)"
            variant="caption"
            align="right"
          >
            الوقت الآن
          </ThemedText>
          <View style={styles.timeRow}>
            <ThemedText
              color="rgba(255,255,255,0.6)"
              align="right"
              weight="semibold"
              style={{ fontSize: 14, marginLeft: 6, fontVariant: ["tabular-nums"] }}
            >
              :{seconds}
            </ThemedText>
            <ThemedText
              color="#FFFFFF"
              align="right"
              weight="bold"
              style={{ fontSize: 28, fontVariant: ["tabular-nums"], letterSpacing: 0.6 }}
            >
              {timeStr}
            </ThemedText>
          </View>
        </View>

        <View style={[styles.metaDivider, { backgroundColor: "rgba(255,255,255,0.18)" }]} />

        <View style={styles.metaBlock}>
          <ThemedText
            color="rgba(255,255,255,0.72)"
            variant="caption"
            align="right"
          >
            {dayName}
          </ThemedText>
          <ThemedText
            color="#FFFFFF"
            align="right"
            weight="bold"
            style={{ fontSize: 16, marginTop: 4 }}
          >
            {formatHijriShort(hijri)}
          </ThemedText>
          <ThemedText
            color="rgba(255,255,255,0.65)"
            align="right"
            style={{ fontSize: 11, marginTop: 2 }}
          >
            {now.getDate()}/{pad(now.getMonth() + 1)}/{now.getFullYear()}م
          </ThemedText>
        </View>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  card: {
    borderRadius: 24,
    padding: 20,
    overflow: "hidden",
    minHeight: 200,
  },
  orb: {
    position: "absolute",
    width: 180,
    height: 180,
    borderRadius: 90,
  },
  orbSmall: {
    position: "absolute",
    width: 120,
    height: 120,
    borderRadius: 60,
  },
  topRow: { flexDirection: "row-reverse" },
  greetBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  metaRow: {
    flexDirection: "row-reverse",
    alignItems: "center",
    marginTop: 18,
    paddingTop: 14,
    borderTopWidth: 1,
    borderTopColor: "rgba(255,255,255,0.12)",
  },
  metaBlock: { flex: 1 },
  metaDivider: { width: 1, height: 50, marginHorizontal: 12 },
  timeRow: {
    flexDirection: "row-reverse",
    alignItems: "baseline",
    marginTop: 4,
  },
});
