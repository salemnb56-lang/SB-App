import React from "react";
import { View, ViewProps, ViewStyle } from "react-native";

import { useColors } from "@/hooks/useColors";

interface ThemedViewProps extends ViewProps {
  variant?: "background" | "card" | "muted" | "surface";
}

export function ThemedView({ variant = "background", style, ...rest }: ThemedViewProps) {
  const colors = useColors();
  const backgroundColor =
    variant === "card"
      ? colors.card
      : variant === "muted"
      ? colors.muted
      : variant === "surface"
      ? colors.surface
      : colors.background;

  return (
    <View style={[{ backgroundColor } as ViewStyle, style]} {...rest} />
  );
}
