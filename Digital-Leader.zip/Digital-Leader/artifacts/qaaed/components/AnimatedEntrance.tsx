import React, { useEffect, useRef } from "react";
import { Animated, Easing, ViewProps } from "react-native";

interface AnimatedEntranceProps extends ViewProps {
  delay?: number;
  from?: "bottom" | "right" | "left" | "fade";
  distance?: number;
}

export function AnimatedEntrance({
  delay = 0,
  from = "bottom",
  distance = 14,
  style,
  children,
  ...rest
}: AnimatedEntranceProps) {
  const anim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(anim, {
      toValue: 1,
      duration: 480,
      delay,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: true,
    }).start();
  }, [anim, delay]);

  const translateMap = {
    bottom: { translateY: anim.interpolate({ inputRange: [0, 1], outputRange: [distance, 0] }) },
    right: { translateX: anim.interpolate({ inputRange: [0, 1], outputRange: [distance, 0] }) },
    left: { translateX: anim.interpolate({ inputRange: [0, 1], outputRange: [-distance, 0] }) },
    fade: { translateY: anim.interpolate({ inputRange: [0, 1], outputRange: [0, 0] }) },
  };

  return (
    <Animated.View
      style={[
        {
          opacity: anim,
          transform: [translateMap[from]],
        },
        style,
      ]}
      {...rest}
    >
      {children}
    </Animated.View>
  );
}
