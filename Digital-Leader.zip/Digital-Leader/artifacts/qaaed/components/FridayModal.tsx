import React, { useEffect, useRef, useState } from "react";
import { Animated, Easing, Modal, Pressable, StyleSheet, View } from "react-native";

import { ThemedText } from "@/components/ThemedText";
import { useColors } from "@/hooks/useColors";

interface FridayModalProps {
  visible: boolean;
  onClose: () => void;
}

const TARGET = 10;

export function FridayModal({ visible, onClose }: FridayModalProps) {
  const colors = useColors();
  const [count, setCount] = useState(0);
  const breath = useRef(new Animated.Value(0)).current;
  const pop = useRef(new Animated.Value(1)).current;
  const progress = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (!visible) {
      setCount(0);
      progress.setValue(0);
      return;
    }
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(breath, {
          toValue: 1,
          duration: 1800,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
        Animated.timing(breath, {
          toValue: 0,
          duration: 1800,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
      ]),
    );
    loop.start();
    return () => loop.stop();
  }, [visible, breath, progress]);

  useEffect(() => {
    Animated.timing(progress, {
      toValue: count / TARGET,
      duration: 280,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: false,
    }).start();
    if (count >= TARGET) {
      const t = setTimeout(() => onClose(), 350);
      return () => clearTimeout(t);
    }
    return undefined;
  }, [count, onClose, progress]);

  const handlePress = () => {
    Animated.sequence([
      Animated.timing(pop, { toValue: 0.9, duration: 80, useNativeDriver: true }),
      Animated.timing(pop, { toValue: 1, duration: 120, useNativeDriver: true }),
    ]).start();
    setCount((c) => Math.min(TARGET, c + 1));
  };

  const auraScale = breath.interpolate({ inputRange: [0, 1], outputRange: [1, 1.15] });
  const auraOpacity = breath.interpolate({ inputRange: [0, 1], outputRange: [0.35, 0.7] });
  const halo2Scale = breath.interpolate({ inputRange: [0, 1], outputRange: [1.1, 1.35] });
  const halo2Opacity = breath.interpolate({ inputRange: [0, 1], outputRange: [0.18, 0.4] });

  const SIZE = 220;
  const STROKE = 6;
  const RADIUS = SIZE / 2 + STROKE;

  return (
    <Modal visible={visible} animationType="fade" transparent onRequestClose={onClose}>
      <View style={[styles.overlay, { backgroundColor: colors.background }]}>
        <Pressable style={styles.closeBtn} onPress={onClose} hitSlop={10}>
          <ThemedText variant="heading" color={colors.foreground}>
            ✕
          </ThemedText>
        </Pressable>

        <View style={styles.content}>
          <ThemedText variant="title" align="center" style={{ marginBottom: 36 }}>
            اللهم صلي وسلم على نبينا محمد
          </ThemedText>

          <View
            style={{
              width: RADIUS * 2,
              height: RADIUS * 2,
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Animated.View
              style={[
                styles.halo,
                {
                  width: SIZE * 1.5,
                  height: SIZE * 1.5,
                  borderRadius: SIZE * 0.75,
                  backgroundColor: colors.accent,
                  opacity: halo2Opacity,
                  transform: [{ scale: halo2Scale }],
                },
              ]}
            />
            <Animated.View
              style={[
                styles.halo,
                {
                  width: SIZE * 1.2,
                  height: SIZE * 1.2,
                  borderRadius: SIZE * 0.6,
                  backgroundColor: colors.secondary,
                  opacity: auraOpacity,
                  transform: [{ scale: auraScale }],
                },
              ]}
            />

            {/* Progress ring (segmented) */}
            <View
              style={{
                position: "absolute",
                width: SIZE + STROKE * 2,
                height: SIZE + STROKE * 2,
                borderRadius: (SIZE + STROKE * 2) / 2,
                borderWidth: STROKE,
                borderColor: colors.muted,
              }}
            />
            <ProgressArc
              size={SIZE + STROKE * 2}
              stroke={STROKE}
              progress={count / TARGET}
              color={colors.accent}
            />

            <Animated.View style={{ transform: [{ scale: pop }] }}>
              <Pressable onPress={handlePress}>
                <View
                  style={[
                    styles.center,
                    {
                      width: SIZE,
                      height: SIZE,
                      borderRadius: SIZE / 2,
                      backgroundColor: colors.secondary,
                      borderColor: colors.accent,
                    },
                  ]}
                >
                  <ThemedText
                    align="center"
                    color="#FFFFFF"
                    style={{ fontSize: 64, fontWeight: "700" }}
                  >
                    {count}
                  </ThemedText>
                  <ThemedText align="center" color="rgba(255,255,255,0.85)" variant="subtitle">
                    من {TARGET}
                  </ThemedText>
                </View>
              </Pressable>
            </Animated.View>
          </View>

          <ThemedText variant="muted" align="center" style={{ marginTop: 36 }}>
            اضغط على الدائرة لإحصاء الصلاة
          </ThemedText>
        </View>
      </View>
    </Modal>
  );
}

function ProgressArc({
  size,
  stroke,
  progress,
  color,
}: {
  size: number;
  stroke: number;
  progress: number;
  color: string;
}) {
  // Segmented progress: render `count` filled dots around the circle
  const dots = TARGET;
  const filled = Math.round(progress * dots);
  return (
    <View
      style={{
        position: "absolute",
        width: size,
        height: size,
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      {Array.from({ length: dots }).map((_, i) => {
        const angle = (i / dots) * 2 * Math.PI - Math.PI / 2;
        const r = size / 2 - stroke / 2;
        const x = Math.cos(angle) * r;
        const y = Math.sin(angle) * r;
        return (
          <View
            key={i}
            style={{
              position: "absolute",
              left: size / 2 + x - 8,
              top: size / 2 + y - 8,
              width: 16,
              height: 16,
              borderRadius: 8,
              backgroundColor: i < filled ? color : "transparent",
              borderWidth: 2,
              borderColor: color,
            }}
          />
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, alignItems: "center", justifyContent: "center", padding: 24 },
  closeBtn: {
    position: "absolute",
    top: 60,
    right: 24,
    width: 42,
    height: 42,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
  },
  content: { alignItems: "center", justifyContent: "center" },
  halo: { position: "absolute" },
  center: { alignItems: "center", justifyContent: "center", borderWidth: 3 },
});
