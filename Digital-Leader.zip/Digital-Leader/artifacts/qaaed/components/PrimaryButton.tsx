import { Feather } from "@expo/vector-icons";
import React from "react";
import { Pressable, PressableProps, StyleSheet, View, ViewStyle } from "react-native";

import { ThemedText } from "@/components/ThemedText";
import { useColors } from "@/hooks/useColors";

interface PrimaryButtonProps extends Omit<PressableProps, "style" | "children"> {
  label: string;
  variant?: "primary" | "secondary" | "outline" | "ghost" | "destructive" | "success";
  icon?: keyof typeof Feather.glyphMap;
  iconRight?: keyof typeof Feather.glyphMap;
  fullWidth?: boolean;
  size?: "sm" | "md" | "lg";
  style?: ViewStyle;
}

export function PrimaryButton({
  label,
  variant = "primary",
  icon,
  iconRight,
  fullWidth = false,
  size = "md",
  style,
  disabled,
  ...rest
}: PrimaryButtonProps) {
  const colors = useColors();

  const palette = {
    primary: { bg: colors.secondary, fg: "#FFFFFF", border: colors.secondary },
    secondary: { bg: colors.muted, fg: colors.foreground, border: colors.border },
    outline: { bg: "transparent", fg: colors.foreground, border: colors.border },
    ghost: { bg: "transparent", fg: colors.foreground, border: "transparent" },
    destructive: { bg: colors.destructive, fg: "#FFFFFF", border: colors.destructive },
    success: { bg: colors.success, fg: "#FFFFFF", border: colors.success },
  }[variant];

  const sizing = {
    sm: { height: 40, paddingHorizontal: 14, fontSize: 14 },
    md: { height: 50, paddingHorizontal: 18, fontSize: 15 },
    lg: { height: 58, paddingHorizontal: 22, fontSize: 17 },
  }[size];

  return (
    <Pressable
      disabled={disabled}
      style={({ pressed }) => [
        styles.btn,
        {
          backgroundColor: palette.bg,
          borderColor: palette.border,
          height: sizing.height,
          paddingHorizontal: sizing.paddingHorizontal,
          opacity: disabled ? 0.5 : pressed ? 0.85 : 1,
          flexGrow: fullWidth ? 1 : 0,
          alignSelf: fullWidth ? "stretch" : "center",
        },
        style,
      ]}
      {...rest}
    >
      <View style={styles.row}>
        {icon ? <Feather name={icon} size={18} color={palette.fg} /> : null}
        <ThemedText
          align="center"
          color={palette.fg}
          weight="semibold"
          style={{ fontSize: sizing.fontSize }}
        >
          {label}
        </ThemedText>
        {iconRight ? <Feather name={iconRight} size={18} color={palette.fg} /> : null}
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  btn: {
    borderRadius: 14,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  row: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 8,
  },
});
