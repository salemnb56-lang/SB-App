import AsyncStorage from "@react-native-async-storage/async-storage";
import React, {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";

import { useUser } from "@/contexts/UserContext";

const TIP_DURATION_MS = 24 * 60 * 60 * 1000; // 24 hours
const NOTIFIED_KEY = "@qaaed/tip_notified";

interface TipContextValue {
  remainingMs: number;
  isReady: boolean;
  totalMs: number;
}

const TipContext = createContext<TipContextValue | undefined>(undefined);

export function TipProvider({ children }: { children: React.ReactNode }) {
  const { firstLaunchAt } = useUser();
  const [now, setNow] = useState<number>(Date.now());

  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);

  const value = useMemo<TipContextValue>(() => {
    const start = firstLaunchAt ?? Date.now();
    const elapsed = now - start;
    const remaining = Math.max(0, TIP_DURATION_MS - elapsed);
    const isReady = elapsed >= TIP_DURATION_MS;

    if (isReady) {
      AsyncStorage.getItem(NOTIFIED_KEY).then((v) => {
        if (!v) AsyncStorage.setItem(NOTIFIED_KEY, "1").catch(() => {});
      });
    }

    return {
      remainingMs: remaining,
      totalMs: TIP_DURATION_MS,
      isReady,
    };
  }, [firstLaunchAt, now]);

  return <TipContext.Provider value={value}>{children}</TipContext.Provider>;
}

export function useTip(): TipContextValue {
  const ctx = useContext(TipContext);
  if (!ctx) {
    return { remainingMs: 0, totalMs: TIP_DURATION_MS, isReady: false };
  }
  return ctx;
}
