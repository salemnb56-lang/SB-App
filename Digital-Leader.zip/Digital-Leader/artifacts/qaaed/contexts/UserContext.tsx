import AsyncStorage from "@react-native-async-storage/async-storage";
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";

interface UserContextValue {
  name: string | null;
  ready: boolean;
  needsOnboarding: boolean;
  saveName: (name: string) => Promise<void>;
  firstLaunchAt: number | null;
}

const NAME_KEY = "@qaaed/user_name";
const FIRST_LAUNCH_KEY = "@qaaed/first_launch_at";

const UserContext = createContext<UserContextValue | undefined>(undefined);

export function UserProvider({ children }: { children: React.ReactNode }) {
  const [name, setName] = useState<string | null>(null);
  const [ready, setReady] = useState(false);
  const [firstLaunchAt, setFirstLaunchAt] = useState<number | null>(null);

  useEffect(() => {
    (async () => {
      const [storedName, firstLaunch] = await Promise.all([
        AsyncStorage.getItem(NAME_KEY),
        AsyncStorage.getItem(FIRST_LAUNCH_KEY),
      ]);
      if (storedName) setName(storedName);
      if (firstLaunch) {
        setFirstLaunchAt(parseInt(firstLaunch, 10));
      } else {
        const ts = Date.now();
        await AsyncStorage.setItem(FIRST_LAUNCH_KEY, String(ts));
        setFirstLaunchAt(ts);
      }
      setReady(true);
    })();
  }, []);

  const saveName = useCallback(async (newName: string) => {
    const trimmed = newName.trim();
    if (!trimmed) return;
    await AsyncStorage.setItem(NAME_KEY, trimmed);
    setName(trimmed);
  }, []);

  const value = useMemo(
    () => ({
      name,
      ready,
      needsOnboarding: ready && !name,
      saveName,
      firstLaunchAt,
    }),
    [name, ready, saveName, firstLaunchAt],
  );

  return <UserContext.Provider value={value}>{children}</UserContext.Provider>;
}

export function useUser(): UserContextValue {
  const ctx = useContext(UserContext);
  if (!ctx) {
    return {
      name: null,
      ready: false,
      needsOnboarding: false,
      saveName: async () => {},
      firstLaunchAt: null,
    };
  }
  return ctx;
}
