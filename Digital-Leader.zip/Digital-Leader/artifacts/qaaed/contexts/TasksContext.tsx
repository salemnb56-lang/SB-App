import AsyncStorage from "@react-native-async-storage/async-storage";
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";

export type Urgency = "low" | "medium" | "high";
export type Importance = "low" | "medium" | "high";

export interface Task {
  id: string;
  title: string;
  urgency: Urgency;
  importance: Importance;
  done: boolean;
  createdAt: number;
}

interface TasksContextValue {
  tasks: Task[];
  ready: boolean;
  add: (input: { title: string; urgency: Urgency; importance: Importance }) => void;
  remove: (id: string) => void;
  toggle: (id: string) => void;
  clearCompleted: () => void;
  organize: () => void;
  organized: boolean;
  pendingTasks: Task[];
  topPriority: Task | null;
}

const STORAGE_KEY = "@qaaed/tasks";

const TasksContext = createContext<TasksContextValue | undefined>(undefined);

const URGENCY_WEIGHT: Record<Urgency, number> = { high: 3, medium: 2, low: 1 };
const IMPORTANCE_WEIGHT: Record<Importance, number> = {
  high: 3,
  medium: 2,
  low: 1,
};

function priorityScore(t: Task): number {
  // Eisenhower-style: importance weighs slightly higher than urgency
  return IMPORTANCE_WEIGHT[t.importance] * 4 + URGENCY_WEIGHT[t.urgency] * 3;
}

function sortByPriority(list: Task[]): Task[] {
  return [...list].sort((a, b) => {
    if (a.done !== b.done) return a.done ? 1 : -1;
    const diff = priorityScore(b) - priorityScore(a);
    if (diff !== 0) return diff;
    return a.createdAt - b.createdAt;
  });
}

export function TasksProvider({ children }: { children: React.ReactNode }) {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [ready, setReady] = useState(false);
  const [organized, setOrganized] = useState(false);

  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY).then((raw) => {
      if (raw) {
        try {
          const parsed = JSON.parse(raw) as Task[];
          if (Array.isArray(parsed)) setTasks(parsed);
        } catch {}
      }
      setReady(true);
    });
  }, []);

  useEffect(() => {
    if (ready) AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(tasks)).catch(() => {});
  }, [tasks, ready]);

  const add = useCallback(
    ({ title, urgency, importance }: { title: string; urgency: Urgency; importance: Importance }) => {
      const t: Task = {
        id: Date.now().toString() + Math.random().toString(36).substring(2, 9),
        title: title.trim(),
        urgency,
        importance,
        done: false,
        createdAt: Date.now(),
      };
      if (!t.title) return;
      setTasks((prev) => [...prev, t]);
      setOrganized(false);
    },
    [],
  );

  const remove = useCallback((id: string) => {
    setTasks((prev) => prev.filter((x) => x.id !== id));
  }, []);

  const toggle = useCallback((id: string) => {
    setTasks((prev) => prev.map((x) => (x.id === id ? { ...x, done: !x.done } : x)));
  }, []);

  const clearCompleted = useCallback(() => {
    setTasks((prev) => prev.filter((x) => !x.done));
  }, []);

  const organize = useCallback(() => {
    setTasks((prev) => sortByPriority(prev));
    setOrganized(true);
  }, []);

  const pendingTasks = useMemo(
    () => sortByPriority(tasks.filter((t) => !t.done)),
    [tasks],
  );
  const topPriority = pendingTasks[0] ?? null;

  const value = useMemo<TasksContextValue>(
    () => ({
      tasks,
      ready,
      add,
      remove,
      toggle,
      clearCompleted,
      organize,
      organized,
      pendingTasks,
      topPriority,
    }),
    [tasks, ready, add, remove, toggle, clearCompleted, organize, organized, pendingTasks, topPriority],
  );

  return <TasksContext.Provider value={value}>{children}</TasksContext.Provider>;
}

export function useTasks(): TasksContextValue {
  const ctx = useContext(TasksContext);
  if (!ctx) {
    return {
      tasks: [],
      ready: false,
      add: () => {},
      remove: () => {},
      toggle: () => {},
      clearCompleted: () => {},
      organize: () => {},
      organized: false,
      pendingTasks: [],
      topPriority: null,
    };
  }
  return ctx;
}
