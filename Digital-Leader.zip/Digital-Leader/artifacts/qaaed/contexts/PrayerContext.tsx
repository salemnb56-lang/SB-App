import AsyncStorage from "@react-native-async-storage/async-storage";
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";

import { City, YEMENI_CITIES } from "@/lib/prayerTimes";

const STORAGE_KEY = "@qaaed/city";

interface PrayerContextValue {
  city: City;
  cities: City[];
  setCityById: (id: string) => void;
}

const PrayerContext = createContext<PrayerContextValue | undefined>(undefined);

export function PrayerProvider({ children }: { children: React.ReactNode }) {
  const [cityId, setCityId] = useState<string>(YEMENI_CITIES[0].id);

  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY).then((stored) => {
      if (stored && YEMENI_CITIES.some((c) => c.id === stored)) {
        setCityId(stored);
      }
    });
  }, []);

  const setCityById = useCallback((id: string) => {
    setCityId(id);
    AsyncStorage.setItem(STORAGE_KEY, id).catch(() => {});
  }, []);

  const city = useMemo(
    () => YEMENI_CITIES.find((c) => c.id === cityId) ?? YEMENI_CITIES[0],
    [cityId],
  );

  const value = useMemo<PrayerContextValue>(
    () => ({ city, cities: YEMENI_CITIES, setCityById }),
    [city, setCityById],
  );

  return <PrayerContext.Provider value={value}>{children}</PrayerContext.Provider>;
}

export function usePrayer(): PrayerContextValue {
  const ctx = useContext(PrayerContext);
  if (!ctx) {
    return {
      city: YEMENI_CITIES[0],
      cities: YEMENI_CITIES,
      setCityById: () => {},
    };
  }
  return ctx;
}
