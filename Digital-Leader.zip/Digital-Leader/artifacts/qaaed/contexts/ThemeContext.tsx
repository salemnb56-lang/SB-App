import AsyncStorage from "@react-native-async-storage/async-storage";
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import { Appearance } from "react-native";

export type ThemeMode = "light" | "dark" | "system" | "auto";
export type ResolvedTheme = "light" | "dark";

interface ThemeContextValue {
  mode: ThemeMode;
  resolvedTheme: ResolvedTheme;
  setMode: (mode: ThemeMode) => void;
  ready: boolean;
}

const STORAGE_KEY = "@qaaed/theme_mode";

const ThemeContext = createContext<ThemeContextValue | undefined>(undefined);

function resolveAuto(): ResolvedTheme {
  const hour = new Date().getHours();
  // Light during 06:00-17:59, Dark during 18:00-05:59
  return hour >= 6 && hour < 18 ? "light" : "dark";
}

function resolveMode(mode: ThemeMode, systemScheme: "light" | "dark" | null | undefined): ResolvedTheme {
  if (mode === "light") return "light";
  if (mode === "dark") return "dark";
  if (mode === "auto") return resolveAuto();
  return systemScheme === "dark" ? "dark" : "light";
}

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [mode, setModeState] = useState<ThemeMode>("system");
  const [systemScheme, setSystemScheme] = useState<"light" | "dark" | null>(
    Appearance.getColorScheme() ?? "light",
  );
  const [ready, setReady] = useState(false);
  const [tick, setTick] = useState(0);

  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY).then((stored) => {
      if (stored === "light" || stored === "dark" || stored === "system" || stored === "auto") {
        setModeState(stored);
      }
      setReady(true);
    });
    const sub = Appearance.addChangeListener(({ colorScheme }) => {
      setSystemScheme(colorScheme ?? "light");
    });
    return () => sub.remove();
  }, []);

  // Re-evaluate auto theme every minute
  useEffect(() => {
    if (mode !== "auto") return;
    const id = setInterval(() => setTick((t) => t + 1), 60_000);
    return () => clearInterval(id);
  }, [mode]);

  const setMode = useCallback((next: ThemeMode) => {
    setModeState(next);
    AsyncStorage.setItem(STORAGE_KEY, next).catch(() => {});
  }, []);

  const resolvedTheme = useMemo(
    () => resolveMode(mode, systemScheme),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [mode, systemScheme, tick],
  );

  const value = useMemo(
    () => ({ mode, resolvedTheme, setMode, ready }),
    [mode, resolvedTheme, setMode, ready],
  );

  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}

export function useTheme(): ThemeContextValue {
  const ctx = useContext(ThemeContext);
  if (!ctx) {
    return {
      mode: "system",
      resolvedTheme: "light",
      setMode: () => {},
      ready: false,
    };
  }
  return ctx;
}
