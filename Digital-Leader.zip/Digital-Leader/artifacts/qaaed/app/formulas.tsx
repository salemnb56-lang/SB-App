import { Feather } from "@expo/vector-icons";
import React, { useMemo, useState } from "react";
import { Pressable, ScrollView, StyleSheet, TextInput, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { AppHeader } from "@/components/AppHeader";
import { Card } from "@/components/Card";
import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { useColors } from "@/hooks/useColors";

type Subject = "physics" | "math" | "chemistry";

interface Formula {
  title: string;
  formula: string;
  desc: string;
}

const DATA: Record<Subject, { label: string; icon: keyof typeof Feather.glyphMap; sections: { name: string; items: Formula[] }[] }> = {
  physics: {
    label: "الفيزياء",
    icon: "zap",
    sections: [
      {
        name: "الحركة في خط مستقيم",
        items: [
          { title: "السرعة المتوسطة", formula: "v = Δx / Δt", desc: "النسبة بين الإزاحة والزمن المستغرق" },
          { title: "التسارع", formula: "a = Δv / Δt", desc: "معدل التغير في السرعة بالنسبة للزمن" },
          { title: "المعادلة الأولى", formula: "v = v₀ + a·t", desc: "السرعة النهائية في الحركة بتسارع منتظم" },
          { title: "المعادلة الثانية", formula: "x = v₀·t + ½·a·t²", desc: "الإزاحة عند تسارع منتظم" },
          { title: "المعادلة الثالثة", formula: "v² = v₀² + 2·a·Δx", desc: "علاقة بدون زمن" },
        ],
      },
      {
        name: "قوانين نيوتن",
        items: [
          { title: "القانون الثاني", formula: "F = m · a", desc: "القوة المحصلة تساوي الكتلة مضروبة بالتسارع" },
          { title: "وزن الجسم", formula: "W = m · g", desc: "الوزن يساوي الكتلة في تسارع الجاذبية" },
          { title: "قوة الاحتكاك", formula: "f = μ · N", desc: "معامل الاحتكاك مضروب بالقوة العمودية" },
        ],
      },
      {
        name: "الشغل والطاقة",
        items: [
          { title: "الشغل", formula: "W = F · d · cos(θ)", desc: "الشغل ناتج عن قوة تحرك جسماً مسافة" },
          { title: "الطاقة الحركية", formula: "Eₖ = ½ · m · v²", desc: "طاقة الجسم بسبب حركته" },
          { title: "طاقة الوضع", formula: "Eₚ = m · g · h", desc: "طاقة الوضع الجاذبي" },
          { title: "القدرة", formula: "P = W / t", desc: "معدل بذل الشغل" },
        ],
      },
    ],
  },
  math: {
    label: "الرياضيات",
    icon: "divide",
    sections: [
      {
        name: "الجبر",
        items: [
          { title: "المعادلة التربيعية", formula: "x = (-b ± √(b² - 4ac)) / 2a", desc: "حل المعادلة ax² + bx + c = 0" },
          { title: "المميز", formula: "Δ = b² - 4·a·c", desc: "يحدد عدد الحلول الحقيقية" },
          { title: "متطابقات", formula: "(a + b)² = a² + 2ab + b²", desc: "مربع المجموع" },
          { title: "متطابقات", formula: "a² - b² = (a - b)(a + b)", desc: "الفرق بين مربعين" },
        ],
      },
      {
        name: "المتتاليات",
        items: [
          { title: "متتالية حسابية", formula: "aₙ = a₁ + (n - 1)·d", desc: "الحد العام للمتتالية الحسابية" },
          { title: "مجموع حسابية", formula: "Sₙ = n·(a₁ + aₙ) / 2", desc: "مجموع n من حدود المتتالية الحسابية" },
          { title: "متتالية هندسية", formula: "aₙ = a₁ · r^(n-1)", desc: "الحد العام للمتتالية الهندسية" },
          { title: "مجموع هندسية", formula: "Sₙ = a₁·(1 - rⁿ) / (1 - r)", desc: "مجموع متتالية هندسية" },
        ],
      },
      {
        name: "الهندسة المثلثية",
        items: [
          { title: "المتطابقة الأساسية", formula: "sin²θ + cos²θ = 1", desc: "العلاقة الأساسية بين الجيب وجيب التمام" },
          { title: "الظل", formula: "tan(θ) = sin(θ) / cos(θ)", desc: "تعريف ظل الزاوية" },
          { title: "قانون الجيب", formula: "a/sinA = b/sinB = c/sinC", desc: "في أي مثلث" },
          { title: "قانون جيب التمام", formula: "c² = a² + b² - 2ab·cosC", desc: "تعميم نظرية فيثاغورس" },
        ],
      },
    ],
  },
  chemistry: {
    label: "الكيمياء",
    icon: "thermometer",
    sections: [
      {
        name: "المول والكتلة",
        items: [
          { title: "عدد المولات", formula: "n = m / M", desc: "عدد المولات = الكتلة ÷ الكتلة المولية" },
          { title: "عدد الجسيمات", formula: "N = n · Nₐ", desc: "Nₐ = 6.022 × 10²³ (عدد أفوغادرو)" },
          { title: "الحجم المولي للغازات", formula: "V = n · 22.4 L", desc: "في الظروف القياسية STP" },
        ],
      },
      {
        name: "التركيز والمحاليل",
        items: [
          { title: "المولارية", formula: "M = n / V(L)", desc: "عدد المولات لكل لتر من المحلول" },
          { title: "النسبة المئوية الكتلية", formula: "% = (m المذاب / m المحلول) × 100", desc: "تركيز كتلي" },
          { title: "التخفيف", formula: "M₁ · V₁ = M₂ · V₂", desc: "قبل وبعد التخفيف" },
        ],
      },
      {
        name: "قوانين الغازات",
        items: [
          { title: "قانون بويل", formula: "P₁ · V₁ = P₂ · V₂", desc: "عند ثبوت درجة الحرارة" },
          { title: "قانون شارل", formula: "V₁ / T₁ = V₂ / T₂", desc: "عند ثبوت الضغط" },
          { title: "قانون الغاز المثالي", formula: "P · V = n · R · T", desc: "R = 0.0821 L·atm/(mol·K)" },
        ],
      },
    ],
  },
};

export default function FormulasScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [active, setActive] = useState<Subject>("physics");
  const [search, setSearch] = useState("");

  const sections = useMemo(() => {
    const all = DATA[active].sections;
    if (!search.trim()) return all;
    const q = search.trim();
    return all
      .map((sec) => ({
        ...sec,
        items: sec.items.filter(
          (it) =>
            it.title.includes(q) ||
            it.desc.includes(q) ||
            it.formula.toLowerCase().includes(q.toLowerCase()),
        ),
      }))
      .filter((sec) => sec.items.length > 0);
  }, [active, search]);

  return (
    <ThemedView style={{ flex: 1, paddingTop: insets.top }}>
      <AppHeader title="مرجع القوانين" showBack showMenu={false} showNotification={false} />

      <View style={{ paddingHorizontal: 18, paddingTop: 14 }}>
        <View style={[styles.searchBox, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Feather name="search" size={18} color={colors.mutedForeground} />
          <TextInput
            value={search}
            onChangeText={setSearch}
            placeholder="ابحث في القوانين..."
            placeholderTextColor={colors.mutedForeground}
            style={{ flex: 1, color: colors.foreground, marginHorizontal: 10, fontSize: 14 }}
            textAlign="right"
            writingDirection="rtl"
          />
        </View>

        <View style={styles.tabs}>
          {(Object.keys(DATA) as Subject[]).map((s) => {
            const isActive = active === s;
            return (
              <Pressable
                key={s}
                onPress={() => setActive(s)}
                style={({ pressed }) => [
                  styles.tab,
                  {
                    backgroundColor: isActive ? colors.secondary : colors.muted,
                    opacity: pressed ? 0.85 : 1,
                  },
                ]}
              >
                <Feather name={DATA[s].icon} size={16} color={isActive ? "#FFFFFF" : colors.foreground} />
                <ThemedText
                  align="center"
                  color={isActive ? "#FFFFFF" : colors.foreground}
                  weight="semibold"
                  style={{ fontSize: 13, marginRight: 6 }}
                >
                  {DATA[s].label}
                </ThemedText>
              </Pressable>
            );
          })}
        </View>
      </View>

      <ScrollView
        contentContainerStyle={{ padding: 18, paddingBottom: insets.bottom + 32 }}
        showsVerticalScrollIndicator={false}
      >
        {sections.length === 0 ? (
          <Card style={{ alignItems: "center", paddingVertical: 30 }}>
            <Feather name="search" size={28} color={colors.mutedForeground} />
            <ThemedText variant="muted" align="center" style={{ marginTop: 8 }}>
              لا توجد نتائج مطابقة
            </ThemedText>
          </Card>
        ) : (
          sections.map((sec, si) => (
            <View key={si} style={{ marginBottom: 22 }}>
              <ThemedText
                variant="heading"
                align="right"
                weight="bold"
                color={colors.secondary}
                style={{ marginBottom: 10 }}
              >
                {sec.name}
              </ThemedText>
              <View style={{ gap: 10 }}>
                {sec.items.map((item, ii) => (
                  <Card key={ii}>
                    <View style={styles.itemRow}>
                      <ThemedText variant="heading" align="right" weight="semibold">
                        {item.title}
                      </ThemedText>
                    </View>
                    <View style={[styles.formulaBox, { backgroundColor: colors.muted }]}>
                      <ThemedText
                        align="center"
                        color={colors.foreground}
                        weight="bold"
                        style={{ fontSize: 18, fontVariant: ["tabular-nums"] }}
                      >
                        {item.formula}
                      </ThemedText>
                    </View>
                    <ThemedText
                      variant="caption"
                      align="right"
                      color={colors.mutedForeground}
                      style={{ marginTop: 8 }}
                    >
                      {item.desc}
                    </ThemedText>
                  </Card>
                ))}
              </View>
            </View>
          ))
        )}
      </ScrollView>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  searchBox: {
    flexDirection: "row-reverse",
    alignItems: "center",
    height: 50,
    paddingHorizontal: 14,
    borderRadius: 14,
    borderWidth: 1,
  },
  tabs: { flexDirection: "row-reverse", marginTop: 12, gap: 8 },
  tab: {
    flex: 1,
    flexDirection: "row-reverse",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 12,
    borderRadius: 12,
  },
  itemRow: { flexDirection: "row-reverse", justifyContent: "space-between" },
  formulaBox: {
    marginTop: 12,
    padding: 14,
    borderRadius: 12,
  },
});
