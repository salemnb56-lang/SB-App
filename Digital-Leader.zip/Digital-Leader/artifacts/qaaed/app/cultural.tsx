import { Feather } from "@expo/vector-icons";
import { Image } from "expo-image";
import React from "react";
import { ScrollView, StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { AppHeader } from "@/components/AppHeader";
import { Card } from "@/components/Card";
import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { useColors } from "@/hooks/useColors";

const PILLARS = [
  {
    icon: "compass" as const,
    title: "الوعي الإدراكي",
    desc: "تعزيز قدرات التفكير النقدي وحل المشكلات لدى الطالب",
  },
  {
    icon: "users" as const,
    title: "روح القيادة",
    desc: "بناء شخصية قيادية قادرة على اتخاذ القرار وتحمل المسؤولية",
  },
  {
    icon: "book-open" as const,
    title: "المعرفة الشاملة",
    desc: "إثراء الجانب الثقافي والعلمي بأنشطة هادفة",
  },
];

export default function CulturalScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();

  return (
    <ThemedView style={{ flex: 1, paddingTop: insets.top }}>
      <AppHeader title="الأسبوع الثقافي" showBack showMenu={false} showNotification={false} />

      <ScrollView
        contentContainerStyle={{ padding: 18, paddingBottom: insets.bottom + 32 }}
        showsVerticalScrollIndicator={false}
      >
        <View style={[styles.heroCard, { backgroundColor: colors.secondary }]}>
          <View style={[styles.logoWrap, { backgroundColor: "rgba(255,255,255,0.15)" }]}>
            <Image
              source={require("@/assets/images/app_logo.png")}
              style={styles.logo}
              contentFit="contain"
            />
          </View>
          <ThemedText
            color="#FFFFFF"
            align="center"
            weight="bold"
            style={{ fontSize: 22, marginTop: 14 }}
          >
            القائد الرقمي
          </ThemedText>
          <ThemedText
            color="rgba(255,255,255,0.8)"
            align="center"
            style={{ marginTop: 6 }}
          >
            الأسبوع الثقافي 2026
          </ThemedText>
        </View>

        <Card style={{ marginTop: 14 }}>
          <ThemedText variant="heading" align="right" weight="bold">
            عن الأسبوع الثقافي
          </ThemedText>
          <ThemedText
            align="right"
            style={{ marginTop: 12, lineHeight: 28 }}
            color={colors.foreground}
          >
            الأسبوع الثقافي لطلاب الصف الأول ثانوي الشعبة 3. يهدف أسبوعنا الثقافي
            لتنمية الوعي الإدراكي والقيادي لدى الطالب، ويسعى إلى صقل المهارات
            الفكرية وتعزيز روح المبادرة والعمل الجماعي بين الطلاب من خلال أنشطة
            متنوعة تجمع بين العلم والثقافة والإبداع.
          </ThemedText>
        </Card>

        <View style={{ marginTop: 18 }}>
          <ThemedText variant="title" align="right" weight="bold">
            محاور الأسبوع
          </ThemedText>
          <View style={{ marginTop: 12, gap: 10 }}>
            {PILLARS.map((p, i) => (
              <Card key={i}>
                <View style={styles.pillarRow}>
                  <View style={[styles.pillarIcon, { backgroundColor: colors.secondary + "1A" }]}>
                    <Feather name={p.icon} size={20} color={colors.secondary} />
                  </View>
                  <View style={{ flex: 1, marginRight: 12 }}>
                    <ThemedText variant="heading" align="right" weight="semibold">
                      {p.title}
                    </ThemedText>
                    <ThemedText
                      variant="caption"
                      align="right"
                      color={colors.mutedForeground}
                      style={{ marginTop: 4, lineHeight: 20 }}
                    >
                      {p.desc}
                    </ThemedText>
                  </View>
                </View>
              </Card>
            ))}
          </View>
        </View>
      </ScrollView>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  heroCard: {
    padding: 24,
    borderRadius: 22,
    alignItems: "center",
  },
  logoWrap: {
    width: 96,
    height: 96,
    borderRadius: 28,
    alignItems: "center",
    justifyContent: "center",
  },
  logo: { width: 70, height: 70 },
  pillarRow: { flexDirection: "row-reverse", alignItems: "center" },
  pillarIcon: {
    width: 46,
    height: 46,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
  },
});
