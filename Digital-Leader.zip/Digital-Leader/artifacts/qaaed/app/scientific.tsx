import React, { useMemo, useState } from "react";
import { Pressable, ScrollView, StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { AppHeader } from "@/components/AppHeader";
import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { useColors } from "@/hooks/useColors";

type Mode = "DEG" | "RAD";

interface Btn {
  label: string;
  value?: string;
  action?: string;
  style?: "primary" | "secondary" | "func" | "num" | "op" | "equals" | "clear";
  flex?: number;
}

const ROWS: Btn[][] = [
  [
    { label: "MODE", action: "mode", style: "func" },
    { label: "2nd", action: "shift", style: "func" },
    { label: "(", value: "(", style: "func" },
    { label: ")", value: ")", style: "func" },
    { label: "AC", action: "ac", style: "clear" },
  ],
  [
    { label: "sin", action: "sin", style: "secondary" },
    { label: "cos", action: "cos", style: "secondary" },
    { label: "tan", action: "tan", style: "secondary" },
    { label: "x²", action: "sq", style: "secondary" },
    { label: "DEL", action: "del", style: "clear" },
  ],
  [
    { label: "log", action: "log", style: "secondary" },
    { label: "ln", action: "ln", style: "secondary" },
    { label: "√", action: "sqrt", style: "secondary" },
    { label: "xʸ", value: "^", style: "secondary" },
    { label: "1/x", action: "inv", style: "secondary" },
  ],
  [
    { label: "π", value: "π", style: "secondary" },
    { label: "e", value: "e", style: "secondary" },
    { label: "x!", action: "fact", style: "secondary" },
    { label: "a/b", value: "/", style: "secondary" },
    { label: "%", action: "pct", style: "secondary" },
  ],
  [
    { label: "7", value: "7", style: "num" },
    { label: "8", value: "8", style: "num" },
    { label: "9", value: "9", style: "num" },
    { label: "÷", value: "÷", style: "op" },
    { label: "×", value: "×", style: "op" },
  ],
  [
    { label: "4", value: "4", style: "num" },
    { label: "5", value: "5", style: "num" },
    { label: "6", value: "6", style: "num" },
    { label: "−", value: "-", style: "op" },
    { label: "+", value: "+", style: "op" },
  ],
  [
    { label: "1", value: "1", style: "num" },
    { label: "2", value: "2", style: "num" },
    { label: "3", value: "3", style: "num" },
    { label: "Ans", action: "ans", style: "func" },
    { label: "=", action: "equals", style: "equals", flex: 1 },
  ],
  [
    { label: "0", value: "0", style: "num", flex: 2 },
    { label: ".", value: ".", style: "num" },
    { label: "EXP", value: "E", style: "num" },
    { label: "+/-", action: "neg", style: "op" },
  ],
];

function factorial(n: number): number {
  if (n < 0 || !Number.isInteger(n)) return NaN;
  if (n > 170) return Infinity;
  let r = 1;
  for (let i = 2; i <= n; i++) r *= i;
  return r;
}

function evaluate(expr: string, mode: Mode): number {
  let s = expr
    .replace(/×/g, "*")
    .replace(/÷/g, "/")
    .replace(/−/g, "-")
    .replace(/π/g, String(Math.PI))
    .replace(/(?<![A-Za-z])e(?![A-Za-z])/g, String(Math.E))
    .replace(/\^/g, "**");

  // Replace function names with safe wrappers
  const trig = (v: number) => (mode === "DEG" ? (v * Math.PI) / 180 : v);

  s = s.replace(/sin\(/g, "__sin(");
  s = s.replace(/cos\(/g, "__cos(");
  s = s.replace(/tan\(/g, "__tan(");
  s = s.replace(/log\(/g, "__log10(");
  s = s.replace(/ln\(/g, "Math.log(");
  s = s.replace(/sqrt\(/g, "Math.sqrt(");
  s = s.replace(/sq\(([^)]*)\)/g, "(($1)**2)");
  s = s.replace(/inv\(([^)]*)\)/g, "(1/($1))");
  s = s.replace(/fact\(([^)]*)\)/g, "__fact($1)");
  s = s.replace(/(\d+(?:\.\d+)?)E(-?\d+)/g, "($1*10**$2)");

  const __sin = (v: number) => Math.sin(trig(v));
  const __cos = (v: number) => Math.cos(trig(v));
  const __tan = (v: number) => Math.tan(trig(v));
  const __log10 = (v: number) => Math.log10(v);
  const __fact = factorial;

  // eslint-disable-next-line @typescript-eslint/no-implied-eval, no-new-func
  const fn = new Function(
    "__sin",
    "__cos",
    "__tan",
    "__log10",
    "__fact",
    "Math",
    `"use strict"; return (${s});`,
  );
  const result = fn(__sin, __cos, __tan, __log10, __fact, Math);
  if (typeof result !== "number") throw new Error("Invalid");
  return result;
}

function formatResult(n: number): string {
  if (!isFinite(n)) return "خطأ";
  if (Number.isInteger(n) && Math.abs(n) < 1e15) return String(n);
  const fixed = n.toPrecision(12);
  return parseFloat(fixed).toString();
}

export default function ScientificScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();

  const [expr, setExpr] = useState("");
  const [result, setResult] = useState("");
  const [ans, setAns] = useState(0);
  const [mode, setMode] = useState<Mode>("DEG");

  const handlePress = (btn: Btn) => {
    if (btn.value !== undefined) {
      setExpr((e) => e + btn.value);
      return;
    }
    switch (btn.action) {
      case "ac":
        setExpr("");
        setResult("");
        break;
      case "del":
        setExpr((e) => e.slice(0, -1));
        break;
      case "equals": {
        try {
          const r = evaluate(expr, mode);
          const out = formatResult(r);
          setResult(out);
          if (typeof r === "number" && isFinite(r)) setAns(r);
        } catch {
          setResult("خطأ");
        }
        break;
      }
      case "ans":
        setExpr((e) => e + String(ans));
        break;
      case "mode":
        setMode((m) => (m === "DEG" ? "RAD" : "DEG"));
        break;
      case "sin":
      case "cos":
      case "tan":
      case "log":
      case "ln":
      case "sqrt":
      case "sq":
      case "inv":
      case "fact":
        setExpr((e) => e + `${btn.action}(`);
        break;
      case "pct":
        setExpr((e) => e + "*0.01");
        break;
      case "neg":
        setExpr((e) => `-(${e})`);
        break;
      case "shift":
        // Currently a placeholder for second-function toggle
        break;
      default:
        break;
    }
  };

  const displayExpr = useMemo(() => expr || "0", [expr]);

  return (
    <ThemedView style={{ flex: 1, paddingTop: insets.top }}>
      <AppHeader title="الحاسبة العلمية" showBack showMenu={false} showNotification={false} />

      {/* Display */}
      <View style={[styles.display, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <View style={styles.modeRow}>
          <View style={[styles.modeBadge, { backgroundColor: colors.muted }]}>
            <ThemedText style={{ fontSize: 11 }} color={colors.mutedForeground} weight="semibold">
              {mode}
            </ThemedText>
          </View>
          <ThemedText variant="caption" color={colors.mutedForeground}>
            fx-991ES PLUS
          </ThemedText>
        </View>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ flexGrow: 1, justifyContent: "flex-start", flexDirection: "row-reverse" }}
        >
          <ThemedText
            color={colors.mutedForeground}
            style={{ fontSize: 22, paddingTop: 10, fontVariant: ["tabular-nums"] }}
            align="left"
          >
            {displayExpr}
          </ThemedText>
        </ScrollView>
        <ThemedText
          color={colors.foreground}
          style={{ fontSize: 36, fontWeight: "700", marginTop: 6, fontVariant: ["tabular-nums"] }}
          align="left"
        >
          {result || " "}
        </ThemedText>
      </View>

      {/* Keyboard */}
      <View style={[styles.keyboard, { paddingBottom: insets.bottom + 12 }]}>
        {ROWS.map((row, ri) => (
          <View key={ri} style={styles.row}>
            {row.map((btn, bi) => {
              const palette = getPalette(btn.style ?? "num", colors);
              return (
                <Pressable
                  key={bi}
                  onPress={() => handlePress(btn)}
                  style={({ pressed }) => [
                    styles.btn,
                    {
                      backgroundColor: palette.bg,
                      borderColor: palette.border,
                      flex: btn.flex ?? 1,
                      opacity: pressed ? 0.75 : 1,
                    },
                  ]}
                >
                  <ThemedText
                    align="center"
                    color={palette.fg}
                    weight={btn.style === "num" || btn.style === "equals" ? "bold" : "semibold"}
                    style={{ fontSize: btn.style === "equals" ? 22 : 17 }}
                  >
                    {btn.label}
                  </ThemedText>
                </Pressable>
              );
            })}
          </View>
        ))}
      </View>
    </ThemedView>
  );
}

function getPalette(
  style: NonNullable<Btn["style"]>,
  colors: ReturnType<typeof useColors>,
): { bg: string; fg: string; border: string } {
  switch (style) {
    case "num":
      return { bg: colors.card, fg: colors.foreground, border: colors.border };
    case "op":
      return { bg: colors.secondary, fg: "#FFFFFF", border: colors.secondary };
    case "equals":
      return { bg: colors.accent, fg: "#FFFFFF", border: colors.accent };
    case "clear":
      return { bg: colors.destructive, fg: "#FFFFFF", border: colors.destructive };
    case "func":
      return { bg: colors.muted, fg: colors.foreground, border: colors.border };
    case "secondary":
      return { bg: colors.muted, fg: colors.secondary, border: colors.border };
    default:
      return { bg: colors.card, fg: colors.foreground, border: colors.border };
  }
}

const styles = StyleSheet.create({
  display: {
    margin: 14,
    padding: 18,
    borderRadius: 18,
    borderWidth: 1,
    minHeight: 140,
  },
  modeRow: {
    flexDirection: "row-reverse",
    justifyContent: "space-between",
    alignItems: "center",
  },
  modeBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8 },
  keyboard: { flex: 1, paddingHorizontal: 10, gap: 8 },
  row: { flex: 1, flexDirection: "row-reverse", gap: 8 },
  btn: {
    borderRadius: 14,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
  },
});
