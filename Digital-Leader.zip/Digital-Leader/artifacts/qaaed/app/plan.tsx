import { Feather } from "@expo/vector-icons";
import { Image } from "expo-image";
import React, { useState } from "react";
import { Modal, Pressable, ScrollView, StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { AppHeader } from "@/components/AppHeader";
import { Card } from "@/components/Card";
import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { useColors } from "@/hooks/useColors";

type Plan = "exams" | "holidays" | "normal";

const PLANS: {
  key: Plan;
  title: string;
  subtitle: string;
  icon: keyof typeof Feather.glyphMap;
  source: any;
}[] = [
  {
    key: "exams",
    title: "فترات الامتحانات",
    subtitle: "الجدول اليومي المثالي للمذاكرة المكثفة",
    icon: "book",
    source: require("@/assets/images/img_plan_exams.png"),
  },
  {
    key: "normal",
    title: "الأيام العادية",
    subtitle: "كيف تنظم يومك بذكاء وتوازن",
    icon: "sun",
    source: require("@/assets/images/img_plan_normal.png"),
  },
  {
    key: "holidays",
    title: "أيام العطل",
    subtitle: "الجدول الزمني الدراسي للعطل",
    icon: "coffee",
    source: require("@/assets/images/img_plan_holidays.png"),
  },
];

export default function PlanScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [zoomed, setZoomed] = useState<Plan | null>(null);

  const zoomedPlan = PLANS.find((p) => p.key === zoomed);

  return (
    <ThemedView style={{ flex: 1, paddingTop: insets.top }}>
      <AppHeader title="خطة تنظيم الوقت" showBack showMenu={false} showNotification={false} />
      <ScrollView
        contentContainerStyle={{ padding: 18, paddingBottom: insets.bottom + 32 }}
        showsVerticalScrollIndicator={false}
      >
        <ThemedText variant="title" align="right" weight="bold">
          خرائط طريقك للنجاح
        </ThemedText>
        <ThemedText
          variant="muted"
          align="right"
          color={colors.mutedForeground}
          style={{ marginTop: 4 }}
        >
          ثلاث خطط مدروسة لتنظم وقتك في كل مرحلة دراسية
        </ThemedText>

        <View style={{ marginTop: 18, gap: 14 }}>
          {PLANS.map((p) => (
            <Pressable key={p.key} onPress={() => setZoomed(p.key)}>
              {({ pressed }) => (
                <Card
                  style={{
                    padding: 0,
                    overflow: "hidden",
                    opacity: pressed ? 0.92 : 1,
                  }}
                >
                  <Image
                    source={p.source}
                    style={styles.image}
                    contentFit="cover"
                  />
                  <View style={styles.cardFooter}>
                    <View style={[styles.iconWrap, { backgroundColor: colors.secondary }]}>
                      <Feather name={p.icon} size={18} color="#FFFFFF" />
                    </View>
                    <View style={{ flex: 1, marginRight: 12 }}>
                      <ThemedText variant="heading" align="right" weight="semibold">
                        {p.title}
                      </ThemedText>
                      <ThemedText
                        variant="caption"
                        align="right"
                        color={colors.mutedForeground}
                        style={{ marginTop: 2 }}
                      >
                        {p.subtitle}
                      </ThemedText>
                    </View>
                    <Feather name="maximize-2" size={16} color={colors.mutedForeground} />
                  </View>
                </Card>
              )}
            </Pressable>
          ))}
        </View>
      </ScrollView>

      <Modal
        visible={!!zoomed}
        transparent
        animationType="fade"
        onRequestClose={() => setZoomed(null)}
      >
        <View style={[styles.modalOverlay, { backgroundColor: "rgba(0,0,0,0.92)" }]}>
          <Pressable style={styles.closeBtn} onPress={() => setZoomed(null)}>
            <Feather name="x" size={22} color="#FFFFFF" />
          </Pressable>
          {zoomedPlan && (
            <ScrollView
              maximumZoomScale={3}
              minimumZoomScale={1}
              contentContainerStyle={styles.zoomContent}
              showsHorizontalScrollIndicator={false}
              showsVerticalScrollIndicator={false}
            >
              <Image
                source={zoomedPlan.source}
                style={styles.fullImage}
                contentFit="contain"
              />
            </ScrollView>
          )}
        </View>
      </Modal>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  image: { width: "100%", aspectRatio: 16 / 10, backgroundColor: "#000" },
  cardFooter: {
    flexDirection: "row-reverse",
    alignItems: "center",
    padding: 14,
  },
  iconWrap: {
    width: 38,
    height: 38,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  modalOverlay: { flex: 1, alignItems: "center", justifyContent: "center" },
  closeBtn: {
    position: "absolute",
    top: 60,
    right: 24,
    width: 44,
    height: 44,
    borderRadius: 14,
    backgroundColor: "rgba(255,255,255,0.15)",
    alignItems: "center",
    justifyContent: "center",
    zIndex: 10,
  },
  zoomContent: { flexGrow: 1, alignItems: "center", justifyContent: "center" },
  fullImage: { width: 360, height: 600 },
});
