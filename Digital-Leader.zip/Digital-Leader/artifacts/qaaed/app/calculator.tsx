import { Feather } from "@expo/vector-icons";
import React, { useMemo, useState } from "react";
import {
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { AppHeader } from "@/components/AppHeader";
import { Card } from "@/components/Card";
import { PrimaryButton } from "@/components/PrimaryButton";
import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { useColors } from "@/hooks/useColors";

type ExamType = "monthly" | "midfinal" | "ministry";

const EXAM_TYPES: { value: ExamType; label: string; max: number }[] = [
  { value: "monthly", label: "اختبارات شهرية", max: 40 },
  { value: "midfinal", label: "نصفية أو نهائية", max: 30 },
  { value: "ministry", label: "وزارية", max: 100 },
];

interface SubjectRow {
  id: string;
  name: string;
  score: string;
}

function newRow(): SubjectRow {
  return {
    id: Date.now().toString() + Math.random().toString(36).substring(2, 7),
    name: "",
    score: "",
  };
}

export default function CalculatorScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [examType, setExamType] = useState<ExamType>("monthly");
  const [rows, setRows] = useState<SubjectRow[]>([newRow(), newRow(), newRow()]);
  const [target, setTarget] = useState("");
  const [calculated, setCalculated] = useState(false);
  const [goalCalculated, setGoalCalculated] = useState(false);

  const max = EXAM_TYPES.find((e) => e.value === examType)?.max ?? 100;

  const updateRow = (id: string, key: "name" | "score", value: string) => {
    setRows((prev) => prev.map((r) => (r.id === id ? { ...r, [key]: value } : r)));
    setCalculated(false);
    setGoalCalculated(false);
  };

  const addRow = () => setRows((prev) => [...prev, newRow()]);
  const removeRow = (id: string) =>
    setRows((prev) => (prev.length > 1 ? prev.filter((r) => r.id !== id) : prev));

  const validRows = useMemo(
    () =>
      rows
        .map((r) => ({
          ...r,
          parsed: parseFloat(r.score),
        }))
        .filter((r) => !Number.isNaN(r.parsed) && r.parsed >= 0 && r.parsed <= max),
    [rows, max],
  );

  const totals = useMemo(() => {
    if (validRows.length === 0) return { sum: 0, total: 0, percent: 0 };
    const sum = validRows.reduce((acc, r) => acc + r.parsed, 0);
    const total = validRows.length * max;
    const percent = (sum / total) * 100;
    return { sum, total, percent };
  }, [validRows, max]);

  const goal = useMemo(() => {
    const t = parseFloat(target);
    if (Number.isNaN(t) || t <= 0 || t > 100) return null;

    const namedRows = rows.filter((r) => r.name.trim());
    if (namedRows.length === 0) return null;

    // Determine which rows are "completed" (have score) vs "upcoming" (no score)
    const completed = namedRows.filter((r) => {
      const s = parseFloat(r.score);
      return !Number.isNaN(s);
    });
    const upcoming = namedRows.filter((r) => {
      const s = parseFloat(r.score);
      return Number.isNaN(s);
    });

    const targetSubjects = upcoming.length > 0 ? upcoming : namedRows;

    const totalAll = namedRows.length * max;
    const targetSum = (t / 100) * totalAll;
    const completedSum = completed.reduce((acc, r) => acc + parseFloat(r.score), 0);
    const remainingSum = targetSum - completedSum;

    if (upcoming.length === 0) {
      // No upcoming subjects — analyze each named subject
      const breakdown = namedRows.map((r) => {
        const need = (t / 100) * max;
        const got = parseFloat(r.score);
        if (got >= need) {
          return { name: r.name, msg: `حافظ على مستواك في "${r.name}" لتصل لهدفك`, ok: true };
        }
        return {
          name: r.name,
          msg: `تحتاج لرفع علامتك في "${r.name}" بمقدار ${(need - got).toFixed(1)} درجة على الأقل`,
          ok: false,
        };
      });
      return { feasible: completedSum / totalAll >= t / 100, breakdown, perSubject: 0, max, target: t };
    }

    const perSubjectNeeded = remainingSum / upcoming.length;

    if (perSubjectNeeded > max) {
      return {
        feasible: false,
        breakdown: targetSubjects.map((r) => ({
          name: r.name,
          msg: `تحتاج لعلامة كاملة (${max}) في "${r.name}" والوصول للهدف صعب جداً`,
          ok: false,
        })),
        perSubject: max,
        max,
        target: t,
      };
    }

    if (perSubjectNeeded <= 0) {
      return {
        feasible: true,
        breakdown: targetSubjects.map((r) => ({
          name: r.name,
          msg: `حافظ على مستواك في "${r.name}" — لقد حققت هدفك بالفعل`,
          ok: true,
        })),
        perSubject: 0,
        max,
        target: t,
      };
    }

    const breakdown = targetSubjects.map((r) => {
      const ratio = perSubjectNeeded / max;
      let msg: string;
      let ok = true;
      if (ratio >= 0.95) {
        msg = `تحتاج لعلامة كاملة في "${r.name}" (${perSubjectNeeded.toFixed(1)} من ${max})`;
        ok = false;
      } else if (ratio >= 0.8) {
        msg = `ركّز جيداً في "${r.name}" — تحتاج ${perSubjectNeeded.toFixed(1)} من ${max}`;
        ok = false;
      } else if (ratio >= 0.5) {
        msg = `ادرس بانتظام "${r.name}" — تحتاج ${perSubjectNeeded.toFixed(1)} من ${max}`;
      } else {
        msg = `حافظ على مستواك في "${r.name}" — يكفي ${perSubjectNeeded.toFixed(1)} من ${max}`;
      }
      return { name: r.name, msg, ok };
    });

    return { feasible: true, breakdown, perSubject: perSubjectNeeded, max, target: t };
  }, [target, rows, max]);

  return (
    <ThemedView style={{ flex: 1, paddingTop: insets.top }}>
      <AppHeader title="حاسبة المعدل" showBack showMenu={false} showNotification={false} />
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        <ScrollView
          contentContainerStyle={{ padding: 18, paddingBottom: insets.bottom + 32 }}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          {/* Exam type */}
          <Card>
            <ThemedText variant="heading" align="right" weight="semibold">
              نوع الاختبار
            </ThemedText>
            <View style={styles.chipsRow}>
              {EXAM_TYPES.map((opt) => {
                const active = examType === opt.value;
                return (
                  <Pressable
                    key={opt.value}
                    onPress={() => {
                      setExamType(opt.value);
                      setCalculated(false);
                      setGoalCalculated(false);
                    }}
                    style={({ pressed }) => [
                      styles.chip,
                      {
                        backgroundColor: active ? colors.secondary : colors.muted,
                        opacity: pressed ? 0.85 : 1,
                      },
                    ]}
                  >
                    <ThemedText
                      align="center"
                      color={active ? "#FFFFFF" : colors.foreground}
                      weight="semibold"
                      style={{ fontSize: 13 }}
                    >
                      {opt.label}
                    </ThemedText>
                    <ThemedText
                      align="center"
                      color={active ? "rgba(255,255,255,0.85)" : colors.mutedForeground}
                      style={{ fontSize: 11, marginTop: 2 }}
                    >
                      من {opt.max}
                    </ThemedText>
                  </Pressable>
                );
              })}
            </View>
          </Card>

          {/* Subjects */}
          <Card style={{ marginTop: 14 }}>
            <View style={styles.headerRow}>
              <ThemedText variant="heading" align="right" weight="semibold">
                المواد ({rows.length})
              </ThemedText>
              <Pressable
                onPress={addRow}
                style={({ pressed }) => [
                  styles.addBtn,
                  { backgroundColor: colors.secondary, opacity: pressed ? 0.85 : 1 },
                ]}
              >
                <Feather name="plus" size={16} color="#FFFFFF" />
                <ThemedText color="#FFFFFF" weight="semibold" style={{ fontSize: 13, marginRight: 4 }}>
                  إضافة
                </ThemedText>
              </Pressable>
            </View>

            <View style={{ marginTop: 12, gap: 10 }}>
              {rows.map((row, idx) => (
                <View key={row.id} style={styles.subjRow}>
                  <Pressable
                    onPress={() => removeRow(row.id)}
                    style={({ pressed }) => [
                      styles.removeBtn,
                      {
                        backgroundColor: colors.muted,
                        opacity: pressed ? 0.7 : 1,
                      },
                    ]}
                  >
                    <Feather name="x" size={16} color={colors.destructive} />
                  </Pressable>

                  <TextInput
                    value={row.score}
                    onChangeText={(v) => updateRow(row.id, "score", v.replace(/[^0-9.]/g, ""))}
                    placeholder={`/${max}`}
                    placeholderTextColor={colors.mutedForeground}
                    keyboardType="numeric"
                    style={[
                      styles.scoreInput,
                      {
                        backgroundColor: colors.input,
                        borderColor: colors.border,
                        color: colors.foreground,
                      },
                    ]}
                    textAlign="center"
                  />

                  <TextInput
                    value={row.name}
                    onChangeText={(v) => updateRow(row.id, "name", v)}
                    placeholder={`المادة ${idx + 1}`}
                    placeholderTextColor={colors.mutedForeground}
                    style={[
                      styles.nameInput,
                      {
                        backgroundColor: colors.input,
                        borderColor: colors.border,
                        color: colors.foreground,
                      },
                    ]}
                    textAlign="right"
                    writingDirection="rtl"
                  />
                </View>
              ))}
            </View>

            <View style={{ marginTop: 14 }}>
              <PrimaryButton
                label="حساب النسبة"
                icon="bar-chart-2"
                onPress={() => setCalculated(true)}
                fullWidth
              />
            </View>

            {calculated && validRows.length > 0 && (
              <View style={[styles.resultBox, { backgroundColor: colors.muted }]}>
                <View style={styles.resRow}>
                  <ThemedText weight="semibold" color={colors.foreground}>
                    {totals.sum.toFixed(1)} / {totals.total}
                  </ThemedText>
                  <ThemedText variant="caption" color={colors.mutedForeground}>
                    المجموع
                  </ThemedText>
                </View>
                <View style={styles.resRow}>
                  <ThemedText
                    color={colors.secondary}
                    weight="bold"
                    style={{ fontSize: 32 }}
                  >
                    {totals.percent.toFixed(2)}%
                  </ThemedText>
                  <ThemedText variant="caption" color={colors.mutedForeground}>
                    النسبة المئوية
                  </ThemedText>
                </View>
              </View>
            )}
          </Card>

          {/* Goal Simulator */}
          <Card style={{ marginTop: 14 }}>
            <ThemedText variant="heading" align="right" weight="semibold">
              محاكي الأهداف
            </ThemedText>
            <ThemedText
              variant="caption"
              align="right"
              color={colors.mutedForeground}
              style={{ marginTop: 4 }}
            >
              أدخل النسبة المستهدفة واترك خانة الدرجة فارغة في المواد القادمة
            </ThemedText>

            <View style={{ marginTop: 12 }}>
              <ThemedText variant="subtitle" align="right" weight="semibold">
                النسبة المستهدفة
              </ThemedText>
              <TextInput
                value={target}
                onChangeText={(v) => {
                  setTarget(v.replace(/[^0-9.]/g, ""));
                  setGoalCalculated(false);
                }}
                placeholder="مثال: 90"
                placeholderTextColor={colors.mutedForeground}
                keyboardType="numeric"
                style={[
                  styles.targetInput,
                  {
                    backgroundColor: colors.input,
                    borderColor: colors.border,
                    color: colors.foreground,
                  },
                ]}
                textAlign="right"
              />
            </View>

            <View style={{ marginTop: 14 }}>
              <PrimaryButton
                label="حساب الخطة"
                variant="secondary"
                icon="target"
                onPress={() => setGoalCalculated(true)}
                fullWidth
              />
            </View>

            {goalCalculated && goal && (
              <View style={{ marginTop: 14, gap: 10 }}>
                <View
                  style={[
                    styles.summaryBox,
                    { backgroundColor: goal.feasible ? colors.success + "1A" : colors.destructive + "1A" },
                  ]}
                >
                  <ThemedText
                    align="right"
                    color={goal.feasible ? colors.success : colors.destructive}
                    weight="bold"
                  >
                    {goal.feasible
                      ? `هدف ${goal.target}% قابل للتحقيق ✓`
                      : `هدف ${goal.target}% صعب التحقيق ✗`}
                  </ThemedText>
                  {goal.perSubject > 0 && (
                    <ThemedText
                      align="right"
                      color={colors.foreground}
                      style={{ marginTop: 6 }}
                    >
                      المتوسط المطلوب في المواد القادمة:{" "}
                      <ThemedText weight="bold" color={colors.secondary}>
                        {goal.perSubject.toFixed(1)} / {goal.max}
                      </ThemedText>
                    </ThemedText>
                  )}
                </View>

                {goal.breakdown.map((b, i) => (
                  <View
                    key={i}
                    style={[
                      styles.adviceItem,
                      {
                        backgroundColor: colors.muted,
                        borderRightColor: b.ok ? colors.success : colors.warning,
                      },
                    ]}
                  >
                    <ThemedText align="right" color={colors.foreground}>
                      {b.msg}
                    </ThemedText>
                  </View>
                ))}
              </View>
            )}
          </Card>
        </ScrollView>
      </KeyboardAvoidingView>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  chipsRow: { flexDirection: "row-reverse", gap: 8, marginTop: 12 },
  chip: {
    flex: 1,
    paddingVertical: 12,
    paddingHorizontal: 8,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  headerRow: {
    flexDirection: "row-reverse",
    justifyContent: "space-between",
    alignItems: "center",
  },
  addBtn: {
    flexDirection: "row-reverse",
    alignItems: "center",
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 10,
  },
  subjRow: { flexDirection: "row-reverse", alignItems: "center", gap: 8 },
  nameInput: {
    flex: 1,
    height: 48,
    borderRadius: 12,
    borderWidth: 1,
    paddingHorizontal: 14,
    fontSize: 15,
  },
  scoreInput: {
    width: 80,
    height: 48,
    borderRadius: 12,
    borderWidth: 1,
    fontSize: 15,
    fontWeight: "600",
  },
  removeBtn: {
    width: 38,
    height: 38,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  resultBox: {
    marginTop: 14,
    padding: 16,
    borderRadius: 14,
  },
  resRow: {
    flexDirection: "row-reverse",
    justifyContent: "space-between",
    alignItems: "center",
    marginVertical: 4,
  },
  targetInput: {
    marginTop: 8,
    height: 50,
    borderRadius: 12,
    borderWidth: 1,
    paddingHorizontal: 14,
    fontSize: 16,
    fontWeight: "600",
  },
  summaryBox: { padding: 14, borderRadius: 12 },
  adviceItem: {
    padding: 14,
    borderRadius: 12,
    borderRightWidth: 4,
  },
});
