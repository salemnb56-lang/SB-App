import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React, { useEffect, useRef, useState } from "react";
import {
  Animated,
  Easing,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { AnimatedEntrance } from "@/components/AnimatedEntrance";
import { AppHeader } from "@/components/AppHeader";
import { Card } from "@/components/Card";
import { FridayModal } from "@/components/FridayModal";
import { HeroCard } from "@/components/HeroCard";
import { PrayerTimesCard } from "@/components/PrayerTimesCard";
import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { ToolCard } from "@/components/ToolCard";
import { useColors } from "@/hooks/useColors";

const DHIKR: Record<number, string> = {
  0: "الحمدلله على كل حال",
  1: "لاحول ولا قوة الا بالله",
  2: "أستغفر الله العظيم وأتوب إليه",
  3: "لا إله إلا الله وحده لا شريك له",
  4: "سبحان الله والحمد لله ولا إله إلا الله والله أكبر",
  6: "سبحان الله وبحمده سبحان الله العظيم",
};

function FridayPulseButton({ onPress }: { onPress: () => void }) {
  const colors = useColors();
  const pulse = useRef(new Animated.Value(0)).current;
  const glow = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, {
          toValue: 1,
          duration: 1200,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
        Animated.timing(pulse, {
          toValue: 0,
          duration: 1200,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
      ]),
    );
    const glowLoop = Animated.loop(
      Animated.sequence([
        Animated.timing(glow, { toValue: 1, duration: 1400, useNativeDriver: false }),
        Animated.timing(glow, { toValue: 0, duration: 1400, useNativeDriver: false }),
      ]),
    );
    loop.start();
    glowLoop.start();
    return () => {
      loop.stop();
      glowLoop.stop();
    };
  }, [pulse, glow]);

  const scale = pulse.interpolate({ inputRange: [0, 1], outputRange: [1, 1.04] });
  const haloOpacity = pulse.interpolate({ inputRange: [0, 1], outputRange: [0.25, 0.55] });
  const haloScale = pulse.interpolate({ inputRange: [0, 1], outputRange: [1, 1.18] });
  const shadowOpacity = glow.interpolate({ inputRange: [0, 1], outputRange: [0.15, 0.5] });

  return (
    <View style={{ alignItems: "center", marginTop: 14 }}>
      <Animated.View
        style={{
          position: "absolute",
          width: 320,
          height: 70,
          borderRadius: 35,
          backgroundColor: colors.accent,
          opacity: haloOpacity,
          transform: [{ scale: haloScale }],
        }}
      />
      <Animated.View style={{ transform: [{ scale }] }}>
        <Pressable
          onPress={() => {
            if (Platform.OS !== "web") {
              Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium).catch(() => {});
            }
            onPress();
          }}
        >
          <Animated.View
            style={[
              styles.fridayBtn,
              {
                backgroundColor: colors.accent,
                shadowColor: colors.accent,
                shadowOpacity,
                shadowRadius: 18,
                shadowOffset: { width: 0, height: 0 },
                elevation: 10,
              },
            ]}
          >
            <Feather name="moon" size={18} color="#FFFFFF" />
            <ThemedText
              align="center"
              color="#FFFFFF"
              weight="bold"
              style={{ fontSize: 16, marginHorizontal: 10 }}
            >
              هل صليت على النبي اليوم ؟
            </ThemedText>
            <Feather name="star" size={18} color="#FFFFFF" />
          </Animated.View>
        </Pressable>
      </Animated.View>
    </View>
  );
}

export default function HomeScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [fridayOpen, setFridayOpen] = useState(false);

  const today = new Date().getDay();
  const isFriday = today === 5;

  return (
    <ThemedView style={{ flex: 1, paddingTop: insets.top }}>
      <AppHeader />

      <ScrollView
        contentContainerStyle={{ paddingBottom: insets.bottom + 32, paddingHorizontal: 18 }}
        showsVerticalScrollIndicator={false}
      >
        <AnimatedEntrance delay={40}>
          <HeroCard />
        </AnimatedEntrance>

        <AnimatedEntrance delay={120} style={{ marginTop: 14 }}>
          <PrayerTimesCard />
        </AnimatedEntrance>

        <AnimatedEntrance delay={180} style={{ marginTop: 14 }}>
          <Card
            style={{
              backgroundColor: colors.secondary,
              borderColor: colors.secondary,
              paddingVertical: isFriday ? 14 : 22,
            }}
          >
            <View style={styles.dhikrHeader}>
              <Feather name="book" size={14} color="rgba(255,255,255,0.75)" />
              <ThemedText
                align="center"
                color="rgba(255,255,255,0.75)"
                variant="caption"
                weight="semibold"
                style={{ marginRight: 6 }}
              >
                {isFriday ? "ذكر يوم الجمعة" : "ذكر اليوم"}
              </ThemedText>
            </View>
            {isFriday ? (
              <FridayPulseButton onPress={() => setFridayOpen(true)} />
            ) : (
              <ThemedText
                align="center"
                color="#FFFFFF"
                weight="semibold"
                style={{ fontSize: 18, marginTop: 8, lineHeight: 30 }}
              >
                {DHIKR[today]}
              </ThemedText>
            )}
          </Card>
        </AnimatedEntrance>

        <AnimatedEntrance delay={240} style={{ marginTop: 22 }}>
          <View style={styles.sectionHead}>
            <View style={[styles.sectionDot, { backgroundColor: colors.accent }]} />
            <ThemedText variant="title" align="right" weight="bold" style={{ marginRight: 8 }}>
              الأدوات
            </ThemedText>
          </View>
          <ThemedText variant="muted" align="right" color={colors.mutedForeground} style={{ marginTop: 4 }}>
            كل ما تحتاجه لتنظيم دراستك ووقتك
          </ThemedText>
        </AnimatedEntrance>

        <View style={styles.toolsGrid}>
          {[
            {
              title: "حاسبة المعدل",
              subtitle: "احسب نسبتك ومحاكي الأهداف",
              icon: "percent" as const,
              route: "/calculator" as const,
              accent: colors.secondary,
            },
            {
              title: "منظم المهام",
              subtitle: "رتّب مهامك حسب الأولوية",
              icon: "check-square" as const,
              route: "/tasks" as const,
              accent: colors.accent,
            },
            {
              title: "حاسبة علمية",
              subtitle: "جيوب، لوغاريتمات، جذور",
              icon: "cpu" as const,
              route: "/scientific" as const,
              accent: colors.success,
            },
            {
              title: "خطة تنظيم الوقت",
              subtitle: "جداول للأيام العادية والامتحانات",
              icon: "calendar" as const,
              route: "/plan" as const,
              accent: colors.warning,
            },
            {
              title: "مرجع القوانين",
              subtitle: "فيزياء، رياضيات، كيمياء",
              icon: "book-open" as const,
              route: "/formulas" as const,
              accent: colors.destructive,
            },
            {
              title: "المؤقت الدراسي",
              subtitle: "جلسات دراسة مع فترات راحة",
              icon: "clock" as const,
              route: "/timer" as const,
              accent: colors.primary,
            },
          ].map((t, idx) => (
            <AnimatedEntrance key={t.route} delay={300 + idx * 60} style={styles.toolCell}>
              <ToolCard {...t} />
            </AnimatedEntrance>
          ))}
        </View>

        <View style={{ height: 24 }} />
      </ScrollView>

      <FridayModal visible={fridayOpen} onClose={() => setFridayOpen(false)} />
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  fridayBtn: {
    flexDirection: "row-reverse",
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 22,
    paddingVertical: 14,
    borderRadius: 30,
  },
  toolsGrid: {
    marginTop: 14,
    flexDirection: "row-reverse",
    flexWrap: "wrap",
    gap: 12,
  },
  toolCell: { flexBasis: "48%", flexGrow: 1 },
  sectionHead: { flexDirection: "row-reverse", alignItems: "center" },
  sectionDot: { width: 8, height: 8, borderRadius: 4 },
  dhikrHeader: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "center" },
});
