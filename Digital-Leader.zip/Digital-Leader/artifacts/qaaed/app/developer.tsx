import { Feather, FontAwesome } from "@expo/vector-icons";
import { Image } from "expo-image";
import React, { useState } from "react";
import {
  KeyboardAvoidingView,
  Linking,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { AppHeader } from "@/components/AppHeader";
import { PrimaryButton } from "@/components/PrimaryButton";
import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { useUser } from "@/contexts/UserContext";
import { useColors } from "@/hooks/useColors";

const WHATSAPP_NUMBER = "967781453408";

export default function DeveloperScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { name } = useUser();
  const [contactOpen, setContactOpen] = useState(false);
  const [message, setMessage] = useState("");

  const handleSend = async () => {
    if (!message.trim()) return;
    const userName = name ?? "زائر";
    const text = `مرحباً، أنا ${userName}، رسالتي: ${message.trim()}`;
    const url = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(text)}`;
    try {
      await Linking.openURL(url);
      setContactOpen(false);
      setMessage("");
    } catch {}
  };

  return (
    <ThemedView style={{ flex: 1, paddingTop: insets.top }}>
      <AppHeader title="عن المطور" showBack showMenu={false} showNotification={false} />

      <ScrollView
        contentContainerStyle={{ padding: 18, paddingBottom: insets.bottom + 32 }}
        showsVerticalScrollIndicator={false}
      >
        {/* Top corner app logo */}
        <View style={styles.topLogoRow}>
          <View style={[styles.topLogoWrap, { backgroundColor: colors.muted }]}>
            <Image
              source={require("@/assets/images/app_logo.png")}
              style={styles.topLogo}
              contentFit="contain"
            />
          </View>
        </View>

        {/* Developer card */}
        <View style={{ alignItems: "center", marginTop: 8 }}>
          <View style={[styles.devLogoRing, { borderColor: colors.secondary, backgroundColor: colors.card }]}>
            <Image
              source={require("@/assets/images/developer_logo.png")}
              style={styles.devLogo}
              contentFit="cover"
            />
          </View>

          <ThemedText
            align="center"
            color={colors.foreground}
            weight="bold"
            style={{ fontSize: 22, marginTop: 16 }}
          >
            سالم نبيل سالم عمر بافريج
          </ThemedText>
          <ThemedText
            align="center"
            color={colors.foreground}
            weight="semibold"
            style={{ fontSize: 16, marginTop: 4, letterSpacing: 0.4 }}
          >
            Salem Nabeel Salem Omar Bafarij
          </ThemedText>

          <ThemedText
            align="center"
            color={colors.mutedForeground}
            style={{ fontSize: 12.5, marginTop: 14, opacity: 0.65 }}
          >
            و بمساعده من جميع طلاب الصف &apos;اولى ثلاثه&apos;
          </ThemedText>
          <ThemedText
            align="center"
            color={colors.mutedForeground}
            style={{ fontSize: 11, marginTop: 4, opacity: 0.45 }}
          >
            و خاصة من الطالب محمد أحمد حسان
          </ThemedText>
        </View>

        {/* Contact button */}
        <View style={{ marginTop: 28 }}>
          <PrimaryButton
            label="إرسال رسالة للمطور"
            icon="message-circle"
            variant="success"
            onPress={() => setContactOpen(true)}
            size="lg"
            fullWidth
          />
        </View>

        {/* Quote */}
        <View style={[styles.quoteWrap, { backgroundColor: colors.secondary, marginTop: 36 }]}>
          <View style={[styles.quoteHalo, { backgroundColor: colors.accent + "33" }]} />
          <View style={[styles.quoteHalo2, { backgroundColor: colors.accent + "22" }]} />
          <Feather name="award" size={26} color="#FFFFFF" style={{ alignSelf: "center" }} />
          <ThemedText
            align="center"
            color="#FFFFFF"
            weight="bold"
            style={{
              fontSize: 22,
              marginTop: 14,
              lineHeight: 36,
              letterSpacing: 0.4,
              textShadowColor: "rgba(255,255,255,0.4)",
              textShadowOffset: { width: 0, height: 0 },
              textShadowRadius: 12,
            }}
          >
            القيادة ليست حُلماً يُحلم .. بل عَملٌ يُعمل
          </ThemedText>
        </View>
      </ScrollView>

      {/* Contact modal */}
      <Modal
        visible={contactOpen}
        transparent
        animationType="fade"
        onRequestClose={() => setContactOpen(false)}
      >
        <View style={[styles.overlay, { backgroundColor: colors.overlay }]}>
          <KeyboardAvoidingView
            behavior={Platform.OS === "ios" ? "padding" : undefined}
            style={styles.modalCenter}
          >
            <View style={[styles.modalCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <View style={styles.modalHeader}>
                <Pressable onPress={() => setContactOpen(false)} hitSlop={10}>
                  <Feather name="x" size={20} color={colors.foreground} />
                </Pressable>
                <ThemedText variant="heading" align="right" weight="bold">
                  مراسلة المطور
                </ThemedText>
              </View>

              <View style={[styles.fieldGroup, { backgroundColor: colors.muted }]}>
                <ThemedText variant="caption" color={colors.mutedForeground} align="right">
                  الاسم
                </ThemedText>
                <ThemedText weight="semibold" align="right" style={{ marginTop: 4 }}>
                  {name ?? "زائر"}
                </ThemedText>
              </View>

              <ThemedText
                variant="subtitle"
                weight="semibold"
                align="right"
                style={{ marginTop: 14 }}
              >
                رسالتك
              </ThemedText>
              <TextInput
                value={message}
                onChangeText={setMessage}
                placeholder="اكتب رسالتك هنا..."
                placeholderTextColor={colors.mutedForeground}
                style={[
                  styles.messageInput,
                  {
                    backgroundColor: colors.input,
                    borderColor: colors.border,
                    color: colors.foreground,
                  },
                ]}
                textAlign="right"
                writingDirection="rtl"
                multiline
                numberOfLines={5}
              />

              <Pressable
                onPress={handleSend}
                disabled={!message.trim()}
                style={({ pressed }) => [
                  styles.sendBtn,
                  {
                    backgroundColor: message.trim() ? colors.success : colors.muted,
                    opacity: pressed ? 0.85 : 1,
                  },
                ]}
              >
                <FontAwesome name="whatsapp" size={20} color="#FFFFFF" />
                <ThemedText color="#FFFFFF" weight="bold" style={{ fontSize: 16, marginHorizontal: 10 }}>
                  إرسال الآن
                </ThemedText>
              </Pressable>
            </View>
          </KeyboardAvoidingView>
        </View>
      </Modal>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  topLogoRow: { flexDirection: "row-reverse", alignItems: "center" },
  topLogoWrap: {
    width: 60,
    height: 60,
    borderRadius: 18,
    alignItems: "center",
    justifyContent: "center",
  },
  topLogo: { width: 44, height: 44 },
  devLogoRing: {
    width: 150,
    height: 150,
    borderRadius: 75,
    borderWidth: 3,
    alignItems: "center",
    justifyContent: "center",
    overflow: "hidden",
  },
  devLogo: { width: 144, height: 144, borderRadius: 72 },
  quoteWrap: {
    padding: 28,
    borderRadius: 22,
    overflow: "hidden",
  },
  quoteHalo: {
    position: "absolute",
    top: -40,
    right: -40,
    width: 160,
    height: 160,
    borderRadius: 80,
  },
  quoteHalo2: {
    position: "absolute",
    bottom: -50,
    left: -50,
    width: 200,
    height: 200,
    borderRadius: 100,
  },
  overlay: { flex: 1, padding: 18 },
  modalCenter: { flex: 1, justifyContent: "center" },
  modalCard: {
    borderRadius: 22,
    borderWidth: 1,
    padding: 18,
  },
  modalHeader: {
    flexDirection: "row-reverse",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 14,
  },
  fieldGroup: { padding: 12, borderRadius: 12 },
  messageInput: {
    marginTop: 8,
    minHeight: 120,
    borderRadius: 14,
    borderWidth: 1,
    padding: 14,
    fontSize: 15,
    textAlignVertical: "top",
  },
  sendBtn: {
    marginTop: 18,
    height: 54,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row-reverse",
  },
});
