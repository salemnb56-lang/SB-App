import { Feather } from "@expo/vector-icons";
import React, { useState } from "react";
import {
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { AppHeader } from "@/components/AppHeader";
import { Card } from "@/components/Card";
import { PrimaryButton } from "@/components/PrimaryButton";
import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { Importance, Task, Urgency, useTasks } from "@/contexts/TasksContext";
import { useColors } from "@/hooks/useColors";

const URGENCY_LABEL: Record<Urgency, string> = {
  high: "عاجلة",
  medium: "متوسطة",
  low: "غير عاجلة",
};

const IMPORTANCE_LABEL: Record<Importance, string> = {
  high: "مهمة جداً",
  medium: "مهمة",
  low: "أقل أهمية",
};

function priorityLabel(t: Task): { label: string; color: "success" | "warning" | "destructive" | "secondary" } {
  if (t.importance === "high" && t.urgency === "high")
    return { label: "أولوية قصوى", color: "destructive" };
  if (t.importance === "high") return { label: "مهمة استراتيجية", color: "secondary" };
  if (t.urgency === "high") return { label: "تحتاج إنجازاً سريعاً", color: "warning" };
  return { label: "عادية", color: "success" };
}

export default function TasksScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { tasks, add, remove, toggle, organize, organized, clearCompleted } = useTasks();

  const [title, setTitle] = useState("");
  const [urgency, setUrgency] = useState<Urgency>("medium");
  const [importance, setImportance] = useState<Importance>("medium");

  const handleAdd = () => {
    if (!title.trim()) return;
    add({ title, urgency, importance });
    setTitle("");
    setUrgency("medium");
    setImportance("medium");
  };

  const pending = tasks.filter((t) => !t.done);
  const done = tasks.filter((t) => t.done);

  return (
    <ThemedView style={{ flex: 1, paddingTop: insets.top }}>
      <AppHeader title="منظم المهام" showBack showMenu={false} showNotification={false} />
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        <ScrollView
          contentContainerStyle={{ padding: 18, paddingBottom: insets.bottom + 32 }}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          {/* Add task */}
          <Card>
            <ThemedText variant="heading" align="right" weight="semibold">
              إضافة مهمة جديدة
            </ThemedText>

            <TextInput
              value={title}
              onChangeText={setTitle}
              placeholder="عنوان المهمة..."
              placeholderTextColor={colors.mutedForeground}
              style={[
                styles.titleInput,
                {
                  backgroundColor: colors.input,
                  borderColor: colors.border,
                  color: colors.foreground,
                },
              ]}
              textAlign="right"
              writingDirection="rtl"
              returnKeyType="done"
              onSubmitEditing={handleAdd}
            />

            <ThemedText variant="subtitle" align="right" weight="semibold" style={{ marginTop: 14 }}>
              مستوى الإلحاح
            </ThemedText>
            <Selector
              value={urgency}
              onChange={(v) => setUrgency(v as Urgency)}
              options={[
                { value: "high", label: URGENCY_LABEL.high, color: colors.destructive },
                { value: "medium", label: URGENCY_LABEL.medium, color: colors.warning },
                { value: "low", label: URGENCY_LABEL.low, color: colors.success },
              ]}
            />

            <ThemedText variant="subtitle" align="right" weight="semibold" style={{ marginTop: 14 }}>
              مستوى الأهمية
            </ThemedText>
            <Selector
              value={importance}
              onChange={(v) => setImportance(v as Importance)}
              options={[
                { value: "high", label: IMPORTANCE_LABEL.high, color: colors.destructive },
                { value: "medium", label: IMPORTANCE_LABEL.medium, color: colors.warning },
                { value: "low", label: IMPORTANCE_LABEL.low, color: colors.success },
              ]}
            />

            <View style={{ marginTop: 14 }}>
              <PrimaryButton
                label="إضافة المهمة"
                icon="plus"
                onPress={handleAdd}
                disabled={!title.trim()}
                fullWidth
              />
            </View>
          </Card>

          {/* Organize */}
          <View style={styles.actionsRow}>
            <PrimaryButton
              label="تنظيم"
              variant="primary"
              icon="layers"
              onPress={organize}
              size="md"
              fullWidth
            />
            {done.length > 0 && (
              <PrimaryButton
                label={`حذف المكتمل (${done.length})`}
                variant="secondary"
                icon="trash-2"
                onPress={clearCompleted}
                size="md"
                fullWidth
              />
            )}
          </View>

          {organized && pending.length > 0 && (
            <View
              style={[
                styles.organizedNotice,
                { backgroundColor: colors.success + "1A" },
              ]}
            >
              <Feather name="check-circle" size={16} color={colors.success} />
              <ThemedText color={colors.success} align="right" weight="semibold" style={{ marginRight: 8 }}>
                تم ترتيب المهام حسب الأولوية
              </ThemedText>
            </View>
          )}

          {/* Pending list */}
          <View style={{ marginTop: 18 }}>
            <ThemedText variant="title" align="right" weight="bold">
              المهام المعلقة ({pending.length})
            </ThemedText>
            {pending.length === 0 ? (
              <Card style={{ marginTop: 10, alignItems: "center", paddingVertical: 28 }}>
                <Feather name="inbox" size={28} color={colors.mutedForeground} />
                <ThemedText
                  variant="muted"
                  align="center"
                  color={colors.mutedForeground}
                  style={{ marginTop: 8 }}
                >
                  لا توجد مهام معلقة حالياً
                </ThemedText>
              </Card>
            ) : (
              <View style={{ marginTop: 10, gap: 10 }}>
                {pending.map((t) => {
                  const p = priorityLabel(t);
                  const accent = colors[p.color];
                  return (
                    <Card
                      key={t.id}
                      style={{
                        borderRightWidth: 4,
                        borderRightColor: accent,
                      }}
                    >
                      <View style={styles.taskRow}>
                        <Pressable
                          onPress={() => toggle(t.id)}
                          style={[
                            styles.checkbox,
                            { borderColor: colors.border, backgroundColor: colors.background },
                          ]}
                        />
                        <View style={{ flex: 1, marginHorizontal: 10 }}>
                          <ThemedText weight="semibold" align="right">
                            {t.title}
                          </ThemedText>
                          <View style={styles.metaRow}>
                            <View style={[styles.tag, { backgroundColor: accent + "22" }]}>
                              <ThemedText
                                style={{ fontSize: 11 }}
                                color={accent}
                                weight="semibold"
                                align="center"
                              >
                                {p.label}
                              </ThemedText>
                            </View>
                            <ThemedText
                              variant="caption"
                              color={colors.mutedForeground}
                              style={{ marginRight: 8 }}
                            >
                              {URGENCY_LABEL[t.urgency]} · {IMPORTANCE_LABEL[t.importance]}
                            </ThemedText>
                          </View>
                        </View>
                        <Pressable
                          onPress={() => remove(t.id)}
                          style={({ pressed }) => [
                            styles.delBtn,
                            { backgroundColor: colors.muted, opacity: pressed ? 0.7 : 1 },
                          ]}
                        >
                          <Feather name="trash-2" size={15} color={colors.destructive} />
                        </Pressable>
                      </View>
                    </Card>
                  );
                })}
              </View>
            )}
          </View>

          {done.length > 0 && (
            <View style={{ marginTop: 22 }}>
              <ThemedText
                variant="heading"
                align="right"
                color={colors.mutedForeground}
                weight="semibold"
              >
                المكتملة ({done.length})
              </ThemedText>
              <View style={{ marginTop: 10, gap: 8 }}>
                {done.map((t) => (
                  <Card key={t.id} style={{ opacity: 0.6 }}>
                    <View style={styles.taskRow}>
                      <Pressable
                        onPress={() => toggle(t.id)}
                        style={[
                          styles.checkbox,
                          {
                            borderColor: colors.success,
                            backgroundColor: colors.success,
                          },
                        ]}
                      >
                        <Feather name="check" size={14} color="#FFFFFF" />
                      </Pressable>
                      <View style={{ flex: 1, marginHorizontal: 10 }}>
                        <ThemedText
                          weight="semibold"
                          align="right"
                          style={{ textDecorationLine: "line-through" }}
                        >
                          {t.title}
                        </ThemedText>
                      </View>
                      <Pressable
                        onPress={() => remove(t.id)}
                        style={({ pressed }) => [
                          styles.delBtn,
                          { backgroundColor: colors.muted, opacity: pressed ? 0.7 : 1 },
                        ]}
                      >
                        <Feather name="trash-2" size={15} color={colors.destructive} />
                      </Pressable>
                    </View>
                  </Card>
                ))}
              </View>
            </View>
          )}
        </ScrollView>
      </KeyboardAvoidingView>
    </ThemedView>
  );
}

function Selector({
  value,
  onChange,
  options,
}: {
  value: string;
  onChange: (v: string) => void;
  options: { value: string; label: string; color: string }[];
}) {
  const colors = useColors();
  return (
    <View style={styles.selectorRow}>
      {options.map((opt) => {
        const active = value === opt.value;
        return (
          <Pressable
            key={opt.value}
            onPress={() => onChange(opt.value)}
            style={({ pressed }) => [
              styles.selectorChip,
              {
                backgroundColor: active ? opt.color : colors.muted,
                opacity: pressed ? 0.85 : 1,
              },
            ]}
          >
            <ThemedText
              align="center"
              color={active ? "#FFFFFF" : colors.foreground}
              weight="semibold"
              style={{ fontSize: 13 }}
            >
              {opt.label}
            </ThemedText>
          </Pressable>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  titleInput: {
    marginTop: 12,
    height: 50,
    borderRadius: 12,
    borderWidth: 1,
    paddingHorizontal: 14,
    fontSize: 15,
  },
  selectorRow: { flexDirection: "row-reverse", gap: 8, marginTop: 8 },
  selectorChip: {
    flex: 1,
    paddingVertical: 11,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  actionsRow: { marginTop: 14, flexDirection: "row-reverse", gap: 10 },
  organizedNotice: {
    marginTop: 12,
    padding: 12,
    borderRadius: 12,
    flexDirection: "row-reverse",
    alignItems: "center",
  },
  taskRow: { flexDirection: "row-reverse", alignItems: "center" },
  checkbox: {
    width: 24,
    height: 24,
    borderRadius: 8,
    borderWidth: 2,
    alignItems: "center",
    justifyContent: "center",
  },
  metaRow: { flexDirection: "row-reverse", alignItems: "center", marginTop: 6 },
  tag: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 8 },
  delBtn: {
    width: 36,
    height: 36,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
  },
});
