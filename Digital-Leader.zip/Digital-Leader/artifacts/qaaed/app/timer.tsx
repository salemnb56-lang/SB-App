import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  Animated,
  Easing,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { AppHeader } from "@/components/AppHeader";
import { Card } from "@/components/Card";
import { PrimaryButton } from "@/components/PrimaryButton";
import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { useColors } from "@/hooks/useColors";

type Phase = "study" | "break" | "idle";

const SUBJECTS = [
  "الرياضيات",
  "الفيزياء",
  "الكيمياء",
  "الأحياء",
  "العربية",
  "الإنجليزية",
  "أخرى",
];

function pad(n: number) {
  return n < 10 ? `0${n}` : String(n);
}

export default function TimerScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();

  const [subject, setSubject] = useState(SUBJECTS[0]);
  const [studyMin, setStudyMin] = useState("45");
  const [breakMin, setBreakMin] = useState("10");
  const [phase, setPhase] = useState<Phase>("idle");
  const [running, setRunning] = useState(false);
  const [remaining, setRemaining] = useState(0);
  const [completedSessions, setCompletedSessions] = useState(0);

  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const ringAnim = useRef(new Animated.Value(0)).current;

  const totalSec = useMemo(() => {
    const mins = parseInt(phase === "break" ? breakMin : studyMin, 10);
    return Math.max(1, mins) * 60;
  }, [phase, studyMin, breakMin]);

  const progress = phase === "idle" ? 0 : 1 - remaining / totalSec;

  useEffect(() => {
    Animated.timing(ringAnim, {
      toValue: progress,
      duration: 280,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: false,
    }).start();
  }, [progress, ringAnim]);

  useEffect(() => {
    if (running && remaining > 0) {
      intervalRef.current = setInterval(() => {
        setRemaining((r) => {
          if (r <= 1) {
            if (intervalRef.current) clearInterval(intervalRef.current);
            handlePhaseEnd();
            return 0;
          }
          return r - 1;
        });
      }, 1000);
      return () => {
        if (intervalRef.current) clearInterval(intervalRef.current);
      };
    }
    return undefined;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [running]);

  const handlePhaseEnd = () => {
    if (Platform.OS !== "web") {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => {});
    }
    if (phase === "study") {
      setCompletedSessions((c) => c + 1);
      setPhase("break");
      const breakSec = Math.max(1, parseInt(breakMin, 10)) * 60;
      setRemaining(breakSec);
      setRunning(true);
    } else {
      setPhase("idle");
      setRunning(false);
      setRemaining(0);
    }
  };

  const start = () => {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium).catch(() => {});
    }
    if (phase === "idle") {
      setPhase("study");
      const studySec = Math.max(1, parseInt(studyMin, 10)) * 60;
      setRemaining(studySec);
    }
    setRunning(true);
  };

  const pause = () => setRunning(false);
  const reset = () => {
    if (intervalRef.current) clearInterval(intervalRef.current);
    setRunning(false);
    setPhase("idle");
    setRemaining(0);
  };

  const min = Math.floor(remaining / 60);
  const sec = remaining % 60;

  const SIZE = 260;
  const STROKE = 14;

  return (
    <ThemedView style={{ flex: 1, paddingTop: insets.top }}>
      <AppHeader title="المؤقت الدراسي" showBack showMenu={false} showNotification={false} />

      <ScrollView
        contentContainerStyle={{ padding: 18, paddingBottom: insets.bottom + 32 }}
        showsVerticalScrollIndicator={false}
      >
        {/* Circle progress */}
        <View style={styles.circleWrap}>
          <View
            style={{
              width: SIZE,
              height: SIZE,
              borderRadius: SIZE / 2,
              borderWidth: STROKE,
              borderColor: colors.muted,
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <ProgressDots
              size={SIZE}
              stroke={STROKE}
              progress={progress}
              color={phase === "break" ? colors.success : colors.secondary}
              total={60}
            />

            <ThemedText
              variant="caption"
              color={colors.mutedForeground}
              align="center"
              weight="semibold"
            >
              {phase === "break" ? "وقت الراحة" : phase === "study" ? "وقت الدراسة" : "جاهز للبدء"}
            </ThemedText>
            <ThemedText
              align="center"
              color={colors.foreground}
              weight="bold"
              style={{ fontSize: 56, marginTop: 4, fontVariant: ["tabular-nums"] }}
            >
              {pad(min)}:{pad(sec)}
            </ThemedText>
            <ThemedText variant="caption" color={colors.mutedForeground} align="center">
              {subject}
            </ThemedText>
          </View>
        </View>

        {/* Controls */}
        <View style={styles.controls}>
          {!running ? (
            <PrimaryButton
              label={phase === "idle" ? "ابدأ الجلسة" : "متابعة"}
              icon="play"
              onPress={start}
              size="lg"
              fullWidth
            />
          ) : (
            <PrimaryButton
              label="إيقاف مؤقت"
              icon="pause"
              variant="secondary"
              onPress={pause}
              size="lg"
              fullWidth
            />
          )}
          <PrimaryButton
            label="إعادة"
            variant="outline"
            icon="refresh-cw"
            onPress={reset}
            size="lg"
          />
        </View>

        {/* Stats */}
        <View style={styles.stats}>
          <Card style={{ flex: 1, alignItems: "center" }}>
            <ThemedText variant="caption" color={colors.mutedForeground}>
              الجلسات المكتملة
            </ThemedText>
            <ThemedText
              align="center"
              weight="bold"
              color={colors.secondary}
              style={{ fontSize: 28, marginTop: 6 }}
            >
              {completedSessions}
            </ThemedText>
          </Card>
          <Card style={{ flex: 1, alignItems: "center" }}>
            <ThemedText variant="caption" color={colors.mutedForeground}>
              مجموع الدراسة
            </ThemedText>
            <ThemedText
              align="center"
              weight="bold"
              color={colors.success}
              style={{ fontSize: 28, marginTop: 6 }}
            >
              {completedSessions * parseInt(studyMin, 10)} د
            </ThemedText>
          </Card>
        </View>

        {/* Subject */}
        <Card style={{ marginTop: 14 }}>
          <ThemedText variant="heading" align="right" weight="semibold">
            المادة
          </ThemedText>
          <View style={styles.subjects}>
            {SUBJECTS.map((s) => {
              const active = subject === s;
              return (
                <Pressable
                  key={s}
                  onPress={() => setSubject(s)}
                  disabled={running}
                  style={({ pressed }) => [
                    styles.subjChip,
                    {
                      backgroundColor: active ? colors.secondary : colors.muted,
                      opacity: pressed ? 0.85 : 1,
                    },
                  ]}
                >
                  <ThemedText
                    align="center"
                    color={active ? "#FFFFFF" : colors.foreground}
                    weight="semibold"
                    style={{ fontSize: 13 }}
                  >
                    {s}
                  </ThemedText>
                </Pressable>
              );
            })}
          </View>
        </Card>

        {/* Duration settings */}
        <Card style={{ marginTop: 14 }}>
          <ThemedText variant="heading" align="right" weight="semibold">
            مدة الجلسة
          </ThemedText>
          <View style={styles.durationRow}>
            <View style={{ flex: 1 }}>
              <ThemedText variant="caption" color={colors.mutedForeground} align="right">
                دراسة (دقائق)
              </ThemedText>
              <View style={[styles.numStepper, { borderColor: colors.border }]}>
                <Pressable
                  onPress={() => setStudyMin((v) => String(Math.max(1, parseInt(v, 10) - 5)))}
                  style={[styles.stepBtn, { backgroundColor: colors.muted }]}
                  disabled={running}
                >
                  <Feather name="minus" size={16} color={colors.foreground} />
                </Pressable>
                <TextInput
                  value={studyMin}
                  onChangeText={(v) => setStudyMin(v.replace(/[^0-9]/g, ""))}
                  keyboardType="number-pad"
                  editable={!running}
                  style={[styles.stepValue, { color: colors.foreground }]}
                  textAlign="center"
                />
                <Pressable
                  onPress={() => setStudyMin((v) => String(parseInt(v, 10) + 5))}
                  style={[styles.stepBtn, { backgroundColor: colors.muted }]}
                  disabled={running}
                >
                  <Feather name="plus" size={16} color={colors.foreground} />
                </Pressable>
              </View>
            </View>

            <View style={{ flex: 1 }}>
              <ThemedText variant="caption" color={colors.mutedForeground} align="right">
                راحة (دقائق)
              </ThemedText>
              <View style={[styles.numStepper, { borderColor: colors.border }]}>
                <Pressable
                  onPress={() => setBreakMin((v) => String(Math.max(1, parseInt(v, 10) - 1)))}
                  style={[styles.stepBtn, { backgroundColor: colors.muted }]}
                  disabled={running}
                >
                  <Feather name="minus" size={16} color={colors.foreground} />
                </Pressable>
                <TextInput
                  value={breakMin}
                  onChangeText={(v) => setBreakMin(v.replace(/[^0-9]/g, ""))}
                  keyboardType="number-pad"
                  editable={!running}
                  style={[styles.stepValue, { color: colors.foreground }]}
                  textAlign="center"
                />
                <Pressable
                  onPress={() => setBreakMin((v) => String(parseInt(v, 10) + 1))}
                  style={[styles.stepBtn, { backgroundColor: colors.muted }]}
                  disabled={running}
                >
                  <Feather name="plus" size={16} color={colors.foreground} />
                </Pressable>
              </View>
            </View>
          </View>
        </Card>
      </ScrollView>
    </ThemedView>
  );
}

function ProgressDots({
  size,
  stroke,
  progress,
  color,
  total,
}: {
  size: number;
  stroke: number;
  progress: number;
  color: string;
  total: number;
}) {
  const filled = Math.round(progress * total);
  return (
    <View
      style={{
        position: "absolute",
        width: size,
        height: size,
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      {Array.from({ length: total }).map((_, i) => {
        const angle = (i / total) * 2 * Math.PI - Math.PI / 2;
        const r = size / 2 - stroke / 2;
        const x = Math.cos(angle) * r;
        const y = Math.sin(angle) * r;
        const dotSize = i < filled ? 6 : 3;
        return (
          <View
            key={i}
            style={{
              position: "absolute",
              left: size / 2 + x - dotSize / 2,
              top: size / 2 + y - dotSize / 2,
              width: dotSize,
              height: dotSize,
              borderRadius: dotSize / 2,
              backgroundColor: i < filled ? color : "transparent",
              borderWidth: i < filled ? 0 : 1,
              borderColor: color + "55",
            }}
          />
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  circleWrap: { alignItems: "center", justifyContent: "center", paddingVertical: 12 },
  controls: { flexDirection: "row-reverse", gap: 10, marginTop: 14 },
  stats: { flexDirection: "row-reverse", gap: 10, marginTop: 14 },
  subjects: { flexDirection: "row-reverse", flexWrap: "wrap", gap: 8, marginTop: 12 },
  subjChip: { paddingHorizontal: 14, paddingVertical: 10, borderRadius: 12 },
  durationRow: { flexDirection: "row-reverse", gap: 12, marginTop: 12 },
  numStepper: {
    marginTop: 6,
    flexDirection: "row-reverse",
    alignItems: "center",
    borderWidth: 1,
    borderRadius: 12,
    overflow: "hidden",
    height: 50,
  },
  stepBtn: {
    width: 42,
    height: 50,
    alignItems: "center",
    justifyContent: "center",
  },
  stepValue: { flex: 1, fontSize: 18, fontWeight: "700" },
});
