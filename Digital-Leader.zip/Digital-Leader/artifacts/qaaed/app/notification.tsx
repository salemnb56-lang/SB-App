import { Feather } from "@expo/vector-icons";
import { BlurView } from "expo-blur";
import { Image } from "expo-image";
import * as WebBrowser from "expo-web-browser";
import React, { useEffect, useRef, useState } from "react";
import { Animated, Easing, Linking, Platform, ScrollView, StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { AppHeader } from "@/components/AppHeader";
import { Card } from "@/components/Card";
import { PrimaryButton } from "@/components/PrimaryButton";
import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { useTasks } from "@/contexts/TasksContext";
import { useTip } from "@/contexts/TipContext";
import { useColors } from "@/hooks/useColors";

const TIP = {
  name: "ChatGPT",
  category: "أداة ذكاء اصطناعي",
  description:
    "ChatGPT هي أداة ذكاء اصطناعي قوية تساعدك في فهم الدروس، تلخيص المواد، حل المسائل، وكتابة المقالات. يمكنك استخدامها كمساعد دراسي شخصي يجيب على أسئلتك في أي وقت ويوفر شرحاً مبسطاً للمفاهيم الصعبة في جميع المواد.",
  tips: [
    "اطلب منه شرح موضوع معقد بطريقة مبسطة",
    "استخدمه لتلخيص فصول الكتب الدراسية",
    "اطلب أمثلة وتمارين إضافية للتدريب",
  ],
  url: "https://chat.openai.com",
};

const BLURRED_TEXT = `
المعلومة المفيدة الكاملة ستظهر بمجرد إنجازك لجميع المهام أو انتهاء المؤقت. تحدث الأداة عن الذكاء الاصطناعي الجديد الذي سيغير طريقة دراستك ويوفر عليك ساعات من البحث. تابع المهام الحالية أو انتظر حتى تنتهي العداد لتحصل على المحتوى كاملاً.
`.trim();

function pad2(n: number) {
  return n < 10 ? `0${n}` : String(n);
}

function formatRemaining(ms: number) {
  const total = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  return `${pad2(h)}:${pad2(m)}:${pad2(s)}`;
}

export default function NotificationScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { pendingTasks, topPriority } = useTasks();
  const { remainingMs, isReady } = useTip();
  const [revealed, setRevealed] = useState(false);
  const blur = useRef(new Animated.Value(1)).current;

  const hasPending = pendingTasks.length > 0;
  const showRevealed = isReady && !hasPending && revealed;

  useEffect(() => {
    if (isReady && !hasPending) {
      // Start unblur animation
      Animated.timing(blur, {
        toValue: 0,
        duration: 1100,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: false,
      }).start(() => setRevealed(true));
    } else {
      blur.setValue(1);
      setRevealed(false);
    }
  }, [isReady, hasPending, blur]);

  const blurIntensity = blur.interpolate({
    inputRange: [0, 1],
    outputRange: [0, 60],
  });

  const handleOpen = async () => {
    try {
      if (Platform.OS === "web") {
        await Linking.openURL(TIP.url);
      } else {
        await WebBrowser.openBrowserAsync(TIP.url);
      }
    } catch {}
  };

  return (
    <ThemedView style={{ flex: 1, paddingTop: insets.top }}>
      <AppHeader title="الإشعارات" showBack showMenu={false} showNotification={false} />

      <ScrollView
        contentContainerStyle={{ padding: 18, paddingBottom: insets.bottom + 32 }}
        showsVerticalScrollIndicator={false}
      >
        {/* State indicator */}
        <Card
          style={{
            backgroundColor: hasPending
              ? colors.destructive + "1A"
              : isReady
              ? colors.success + "1A"
              : colors.warning + "1A",
            borderColor: hasPending
              ? colors.destructive + "55"
              : isReady
              ? colors.success + "55"
              : colors.warning + "55",
          }}
        >
          <View style={styles.stateRow}>
            <View
              style={[
                styles.stateIcon,
                {
                  backgroundColor: hasPending
                    ? colors.destructive
                    : isReady
                    ? colors.success
                    : colors.warning,
                },
              ]}
            >
              <Feather
                name={hasPending ? "alert-circle" : isReady ? "gift" : "clock"}
                size={20}
                color="#FFFFFF"
              />
            </View>
            <View style={{ flex: 1, marginRight: 12 }}>
              <ThemedText weight="bold" align="right">
                {hasPending
                  ? "لديك مهام معلقة"
                  : isReady
                  ? "هناك معلومة مفيدة بانتظارك"
                  : "العداد يعمل في الخلفية"}
              </ThemedText>
              <ThemedText
                variant="caption"
                color={colors.mutedForeground}
                align="right"
                style={{ marginTop: 4 }}
              >
                {hasPending
                  ? "أنجز المهام أولاً للوصول للمحتوى"
                  : isReady
                  ? "تم فتح المحتوى الكامل"
                  : "انتظر حتى ينتهي العد التنازلي"}
              </ThemedText>
            </View>
          </View>
        </Card>

        {/* State 1: pending tasks */}
        {hasPending && topPriority && (
          <Card style={{ marginTop: 14, backgroundColor: colors.secondary }}>
            <ThemedText variant="caption" color="rgba(255,255,255,0.75)" align="right" weight="semibold">
              المهمة ذات الأولوية الأعلى
            </ThemedText>
            <ThemedText
              color="#FFFFFF"
              align="right"
              weight="bold"
              style={{ fontSize: 18, marginTop: 6 }}
            >
              {topPriority.title}
            </ThemedText>
            <View
              style={[styles.questionBox, { backgroundColor: "rgba(255,255,255,0.15)" }]}
            >
              <Feather name="help-circle" size={18} color="#FFFFFF" />
              <ThemedText color="#FFFFFF" align="right" style={{ marginRight: 10, flex: 1 }}>
                هل أنجزت المهمة في أداة تنظيم المهام؟
              </ThemedText>
            </View>
          </Card>
        )}

        {/* State 2: timer running */}
        {!hasPending && !isReady && (
          <Card style={{ marginTop: 14, backgroundColor: colors.primary }}>
            <ThemedText variant="caption" color="rgba(255,255,255,0.75)" align="right" weight="semibold">
              الوقت المتبقي حتى المعلومة التالية
            </ThemedText>
            <ThemedText
              color="#FFFFFF"
              align="center"
              weight="bold"
              style={{ fontSize: 44, marginTop: 8, fontVariant: ["tabular-nums"], letterSpacing: 1 }}
            >
              {formatRemaining(remainingMs)}
            </ThemedText>
            <ThemedText
              variant="caption"
              color="rgba(255,255,255,0.7)"
              align="center"
              style={{ marginTop: 4 }}
            >
              العداد يعمل في الخلفية
            </ThemedText>
          </Card>
        )}

        {/* Content area */}
        <View style={{ marginTop: 18, position: "relative" }}>
          {showRevealed ? (
            <RevealedTip onOpen={handleOpen} />
          ) : (
            <View>
              <Card>
                <ThemedText variant="title" align="right" weight="bold" style={{ opacity: 0.4 }}>
                  أداة الذكاء الاصطناعي للدراسة
                </ThemedText>
                <ThemedText
                  align="right"
                  style={{ marginTop: 12, lineHeight: 26, opacity: 0.4 }}
                >
                  {BLURRED_TEXT}
                </ThemedText>
                <View
                  style={[
                    styles.placeholderImg,
                    { backgroundColor: colors.muted, opacity: 0.5 },
                  ]}
                />
                <ThemedText
                  align="right"
                  style={{ marginTop: 12, lineHeight: 26, opacity: 0.4 }}
                >
                  {BLURRED_TEXT}
                </ThemedText>
              </Card>

              {/* Blur overlay */}
              {Platform.OS !== "web" ? (
                <Animated.View
                  pointerEvents="none"
                  style={[StyleSheet.absoluteFill, { borderRadius: 18, overflow: "hidden" }]}
                >
                  <AnimatedBlur intensity={blurIntensity} tint={colors.scheme === "dark" ? "dark" : "light"} />
                </Animated.View>
              ) : (
                <Animated.View
                  pointerEvents="none"
                  style={[
                    StyleSheet.absoluteFill,
                    {
                      borderRadius: 18,
                      backgroundColor: colors.background,
                      opacity: blur.interpolate({ inputRange: [0, 1], outputRange: [0, 0.85] }),
                    },
                  ]}
                />
              )}
            </View>
          )}
        </View>
      </ScrollView>
    </ThemedView>
  );
}

const AnimatedBlur = Animated.createAnimatedComponent(BlurView as any);

function RevealedTip({ onOpen }: { onOpen: () => void }) {
  const colors = useColors();
  return (
    <Card>
      <View style={[styles.tagRow]}>
        <View style={[styles.tag, { backgroundColor: colors.success + "22" }]}>
          <ThemedText color={colors.success} weight="bold" style={{ fontSize: 11 }} align="center">
            ✓ {TIP.category}
          </ThemedText>
        </View>
      </View>
      <ThemedText variant="title" align="right" weight="bold" style={{ marginTop: 8 }}>
        {TIP.name}
      </ThemedText>

      <Image
        source={require("@/assets/images/img_tip_full.png")}
        style={{
          width: "100%",
          aspectRatio: 16 / 10,
          borderRadius: 14,
          marginTop: 14,
          backgroundColor: "#000",
        }}
        contentFit="cover"
      />

      <ThemedText align="right" style={{ marginTop: 14, lineHeight: 26 }}>
        {TIP.description}
      </ThemedText>

      <View style={{ marginTop: 14, gap: 8 }}>
        {TIP.tips.map((t, i) => (
          <View
            key={i}
            style={[
              styles.tipRow,
              { backgroundColor: colors.muted },
            ]}
          >
            <Feather name="check-circle" size={16} color={colors.success} />
            <ThemedText align="right" style={{ flex: 1, marginRight: 10 }}>
              {t}
            </ThemedText>
          </View>
        ))}
      </View>

      <View style={{ marginTop: 16 }}>
        <PrimaryButton
          label="فتح الموقع الرسمي"
          icon="external-link"
          onPress={onOpen}
          fullWidth
        />
      </View>
    </Card>
  );
}

const styles = StyleSheet.create({
  stateRow: { flexDirection: "row-reverse", alignItems: "center" },
  stateIcon: {
    width: 42,
    height: 42,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
  },
  questionBox: {
    marginTop: 14,
    padding: 14,
    borderRadius: 14,
    flexDirection: "row-reverse",
    alignItems: "center",
  },
  placeholderImg: {
    width: "100%",
    aspectRatio: 16 / 10,
    borderRadius: 14,
    marginTop: 14,
  },
  tagRow: { flexDirection: "row-reverse" },
  tag: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8 },
  tipRow: {
    flexDirection: "row-reverse",
    alignItems: "center",
    padding: 12,
    borderRadius: 12,
  },
});
