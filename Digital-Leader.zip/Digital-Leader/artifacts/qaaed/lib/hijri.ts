// Tabular Islamic Calendar (Kuwaiti algorithm) — pure JS conversion.
// Accurate within ±1 day for civil purposes.

const HIJRI_MONTHS_AR = [
  "محرم",
  "صفر",
  "ربيع الأول",
  "ربيع الآخر",
  "جمادى الأولى",
  "جمادى الآخرة",
  "رجب",
  "شعبان",
  "رمضان",
  "شوال",
  "ذو القعدة",
  "ذو الحجة",
];

export interface HijriDate {
  year: number;
  month: number; // 1-12
  day: number; // 1-30
  monthName: string;
}

function toJulianDay(gy: number, gm: number, gd: number): number {
  if (gm < 3) {
    gy -= 1;
    gm += 12;
  }
  const a = Math.floor(gy / 100);
  const b = 2 - a + Math.floor(a / 4);
  return (
    Math.floor(365.25 * (gy + 4716)) +
    Math.floor(30.6001 * (gm + 1)) +
    gd +
    b -
    1524
  );
}

export function gregorianToHijri(d: Date): HijriDate {
  const gy = d.getFullYear();
  const gm = d.getMonth() + 1;
  const gd = d.getDate();

  const jd = toJulianDay(gy, gm, gd);
  const l = jd - 1948440 + 10632;
  const n = Math.floor((l - 1) / 10631);
  const l2 = l - 10631 * n + 354;
  const j =
    Math.floor((10985 - l2) / 5316) * Math.floor((50 * l2) / 17719) +
    Math.floor(l2 / 5670) * Math.floor((43 * l2) / 15238);
  const l3 =
    l2 -
    Math.floor((30 - j) / 15) * Math.floor((17719 * j) / 50) -
    Math.floor(j / 16) * Math.floor((15238 * j) / 43) +
    29;
  const month = Math.floor((24 * l3) / 709);
  const day = l3 - Math.floor((709 * month) / 24);
  const year = 30 * n + j - 30;

  return {
    year,
    month,
    day,
    monthName: HIJRI_MONTHS_AR[Math.max(0, month - 1)] ?? "",
  };
}

export function formatHijriShort(h: HijriDate): string {
  return `${h.day} ${h.monthName} ${h.year}هـ`;
}
