// Compact prayer-times calculator based on the standard astronomical algorithm
// (Muslim World League method). Pure JS, no external deps.
// Reference: PrayTimes.org open-source implementation simplified.

export interface PrayerTimes {
  fajr: Date;
  sunrise: Date;
  dhuhr: Date;
  asr: Date;
  maghrib: Date;
  isha: Date;
}

export interface City {
  id: string;
  name: string; // Arabic name
  latitude: number;
  longitude: number;
  timezone: number; // in hours from UTC
}

// Common Yemeni cities (timezone +3)
export const YEMENI_CITIES: City[] = [
  { id: "sanaa", name: "صنعاء", latitude: 15.3694, longitude: 44.191, timezone: 3 },
  { id: "aden", name: "عدن", latitude: 12.7855, longitude: 45.0187, timezone: 3 },
  { id: "taiz", name: "تعز", latitude: 13.5775, longitude: 44.0178, timezone: 3 },
  { id: "hodeidah", name: "الحديدة", latitude: 14.7979, longitude: 42.9545, timezone: 3 },
  { id: "ibb", name: "إب", latitude: 13.9667, longitude: 44.1833, timezone: 3 },
  { id: "mukalla", name: "المكلا", latitude: 14.5333, longitude: 49.1333, timezone: 3 },
  { id: "seiyun", name: "سيئون", latitude: 15.9667, longitude: 48.7833, timezone: 3 },
  { id: "marib", name: "مأرب", latitude: 15.4612, longitude: 45.3253, timezone: 3 },
  { id: "dhamar", name: "ذمار", latitude: 14.5429, longitude: 44.4053, timezone: 3 },
  { id: "hajjah", name: "حجة", latitude: 15.6943, longitude: 43.6055, timezone: 3 },
];

// Calculation parameters (Muslim World League)
const FAJR_ANGLE = 18.0;
const ISHA_ANGLE = 17.0;

const dtr = (d: number) => (d * Math.PI) / 180;
const rtd = (r: number) => (r * 180) / Math.PI;

function fixHour(h: number): number {
  let v = h - 24 * Math.floor(h / 24);
  if (v < 0) v += 24;
  return v;
}

interface SunPosition {
  declination: number; // degrees
  equation: number; // hours
}

function julianDate(year: number, month: number, day: number): number {
  if (month <= 2) {
    year -= 1;
    month += 12;
  }
  const A = Math.floor(year / 100);
  const B = 2 - A + Math.floor(A / 4);
  return (
    Math.floor(365.25 * (year + 4716)) +
    Math.floor(30.6001 * (month + 1)) +
    day +
    B -
    1524.5
  );
}

function sunPosition(jd: number): SunPosition {
  const D = jd - 2451545.0;
  const g = fix360(357.529 + 0.98560028 * D);
  const q = fix360(280.459 + 0.98564736 * D);
  const L = fix360(q + 1.915 * Math.sin(dtr(g)) + 0.02 * Math.sin(dtr(2 * g)));
  const e = 23.439 - 0.00000036 * D;
  const RA = rtd(Math.atan2(Math.cos(dtr(e)) * Math.sin(dtr(L)), Math.cos(dtr(L)))) / 15;
  const eqt = q / 15 - fixHour(RA);
  const decl = rtd(Math.asin(Math.sin(dtr(e)) * Math.sin(dtr(L))));
  return { declination: decl, equation: eqt };
}

function fix360(a: number): number {
  let v = a - 360 * Math.floor(a / 360);
  if (v < 0) v += 360;
  return v;
}

// Compute the solar time T (in hours from solar noon) when the sun is at
// a given altitude angle (negative = below horizon).
function timeAtAngle(angle: number, decl: number, lat: number): number | null {
  const cosT =
    (-Math.sin(dtr(angle)) - Math.sin(dtr(lat)) * Math.sin(dtr(decl))) /
    (Math.cos(dtr(lat)) * Math.cos(dtr(decl)));
  if (cosT > 1 || cosT < -1) return null;
  return rtd(Math.acos(cosT)) / 15;
}

// Asr time: sun at a particular altitude based on shadow factor (1 = Standard, 2 = Hanafi)
function asrTime(decl: number, lat: number, factor = 1): number | null {
  const angle = -rtd(Math.atan(1 / (factor + Math.tan(dtr(Math.abs(lat - decl))))));
  return timeAtAngle(angle, decl, lat);
}

function makeDate(base: Date, hour: number, tz: number): Date {
  // hour is local time-of-day in decimal hours; create a Date in local (tz) timezone
  const totalMs = (hour - tz) * 3600 * 1000; // convert local→UTC offset
  const utcMidnight = Date.UTC(base.getFullYear(), base.getMonth(), base.getDate());
  return new Date(utcMidnight + totalMs);
}

export function computePrayerTimes(date: Date, city: City): PrayerTimes {
  const jd = julianDate(date.getFullYear(), date.getMonth() + 1, date.getDate());
  const { declination, equation } = sunPosition(jd + 0.5 - city.longitude / (15 * 24));

  const noon = fixHour(12 - equation - city.longitude / 15 + city.timezone);

  const sunriseT = timeAtAngle(0.833, declination, city.latitude) ?? 6;
  const sunsetT = sunriseT;

  const fajrT = timeAtAngle(FAJR_ANGLE, declination, city.latitude) ?? 1.5;
  const ishaT = timeAtAngle(ISHA_ANGLE, declination, city.latitude) ?? 1.5;

  const asrT = asrTime(declination, city.latitude, 1) ?? 3;

  const sunrise = noon - sunriseT;
  const sunset = noon + sunsetT;
  const fajr = noon - fajrT;
  const dhuhr = noon;
  const asr = noon + asrT;
  const maghrib = sunset;
  const isha = noon + ishaT;

  return {
    fajr: makeDate(date, fajr, city.timezone),
    sunrise: makeDate(date, sunrise, city.timezone),
    dhuhr: makeDate(date, dhuhr, city.timezone),
    asr: makeDate(date, asr, city.timezone),
    maghrib: makeDate(date, maghrib, city.timezone),
    isha: makeDate(date, isha, city.timezone),
  };
}

export type PrayerKey = keyof PrayerTimes;

export const PRAYER_LABELS: Record<PrayerKey, string> = {
  fajr: "الفجر",
  sunrise: "الشروق",
  dhuhr: "الظهر",
  asr: "العصر",
  maghrib: "المغرب",
  isha: "العشاء",
};

export const PRAYER_ORDER: PrayerKey[] = [
  "fajr",
  "sunrise",
  "dhuhr",
  "asr",
  "maghrib",
  "isha",
];

export function getNextPrayer(
  times: PrayerTimes,
  now: Date,
): { key: PrayerKey; at: Date; remainingMs: number; isTomorrow: boolean } {
  for (const key of PRAYER_ORDER) {
    const at = times[key];
    if (at.getTime() > now.getTime()) {
      return { key, at, remainingMs: at.getTime() - now.getTime(), isTomorrow: false };
    }
  }
  // Past Isha — next prayer is tomorrow's Fajr (approximate by adding 24h)
  const tomorrowFajr = new Date(times.fajr.getTime() + 24 * 60 * 60 * 1000);
  return {
    key: "fajr",
    at: tomorrowFajr,
    remainingMs: tomorrowFajr.getTime() - now.getTime(),
    isTomorrow: true,
  };
}

export function formatPrayerTime(d: Date): string {
  let h = d.getHours();
  const m = d.getMinutes();
  const ampm = h >= 12 ? "م" : "ص";
  h = h % 12;
  if (h === 0) h = 12;
  return `${h}:${m < 10 ? "0" + m : m} ${ampm}`;
}
