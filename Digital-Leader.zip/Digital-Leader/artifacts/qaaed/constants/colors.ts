const colors = {
  light: {
    text: "#0B1B33",
    tint: "#1E5BBA",

    background: "#F4F7FB",
    foreground: "#0B1B33",

    card: "#FFFFFF",
    cardForeground: "#0B1B33",

    primary: "#0B1B33",
    primaryForeground: "#FFFFFF",

    secondary: "#1E5BBA",
    secondaryForeground: "#FFFFFF",

    accent: "#3F8CFF",
    accentForeground: "#FFFFFF",

    muted: "#E4ECF7",
    mutedForeground: "#5A6B82",

    destructive: "#D64545",
    destructiveForeground: "#FFFFFF",

    success: "#1E9E5C",
    warning: "#E0A92E",

    border: "#D6E0EE",
    input: "#FFFFFF",

    surface: "#FFFFFF",
    overlay: "rgba(11, 27, 51, 0.55)",

    gradientFrom: "#0B1B33",
    gradientTo: "#1E5BBA",
  },
  dark: {
    text: "#E9F0FA",
    tint: "#5DA0FF",

    background: "#070E1C",
    foreground: "#E9F0FA",

    card: "#0F1B30",
    cardForeground: "#E9F0FA",

    primary: "#3F8CFF",
    primaryForeground: "#0B1B33",

    secondary: "#1E5BBA",
    secondaryForeground: "#FFFFFF",

    accent: "#5DA0FF",
    accentForeground: "#0B1B33",

    muted: "#13223C",
    mutedForeground: "#7E92AE",

    destructive: "#E66767",
    destructiveForeground: "#FFFFFF",

    success: "#3DC183",
    warning: "#F2C661",

    border: "#1A2A45",
    input: "#0F1B30",

    surface: "#0F1B30",
    overlay: "rgba(0, 0, 0, 0.7)",

    gradientFrom: "#070E1C",
    gradientTo: "#13315C",
  },
  radius: 16,
};

export default colors;
