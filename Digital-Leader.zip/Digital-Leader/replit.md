# القائد الرقمي (Al-Qa'id Al-Raqami)

A professional Arabic-language (RTL) student utility mobile app for 1st-grade secondary students, built with Expo + React Native.

## Tech Stack

- **Framework**: Expo Router (file-based routing) on React Native
- **Language**: TypeScript
- **Persistence**: AsyncStorage (no backend, fully offline)
- **State**: React Context (Theme, User, Tasks, Tip, Drawer)
- **UI**: Custom themed components with dark/light dark-blue palette

## Project Structure

```
artifacts/qaaed/
├── app/                # Screens (Expo Router)
│   ├── _layout.tsx     # Root providers + Stack
│   ├── index.tsx       # Dashboard (greeting, clock, dhikr, tools grid)
│   ├── calculator.tsx  # GPA calculator with goal simulator
│   ├── tasks.tsx       # Task organizer with priority sorting
│   ├── scientific.tsx  # fx-991ES style scientific calculator
│   ├── plan.tsx        # Time management plan (3 image plans)
│   ├── formulas.tsx    # Physics/Math/Chemistry reference
│   ├── timer.tsx       # Study sessions timer with breaks
│   ├── notification.tsx# 3-state notification (pending/timer/revealed tip)
│   ├── cultural.tsx    # About cultural week
│   └── developer.tsx   # About developer + WhatsApp contact
├── components/         # Reusable UI components
│   ├── AppHeader.tsx   # Header with bell + menu (notification dot)
│   ├── AppDrawer.tsx   # Custom RTL slide-in drawer
│   ├── OnboardingModal.tsx
│   ├── FridayModal.tsx # Friday dhikr counter (0→10)
│   ├── ToolCard.tsx    # Tool tile on dashboard
│   ├── Card.tsx
│   ├── PrimaryButton.tsx
│   ├── ThemedView.tsx
│   └── ThemedText.tsx
├── contexts/
│   ├── ThemeContext.tsx# light/dark/system/auto-time (06:00-17:59 light)
│   ├── UserContext.tsx # name + first launch timestamp
│   ├── TasksContext.tsx# Eisenhower-style priority sort
│   ├── TipContext.tsx  # 24h timer until tip is ready
│   └── DrawerContext.tsx
├── constants/colors.ts # Dark blue / light blue / white palette
├── hooks/useColors.ts  # Theme-aware palette hook
└── assets/images/      # App icon, logo, plan images, dev photo
```

## Key Features

- **Premium typography**: Cairo Arabic font (400/500/600/700) loaded across the entire app for an elegant, modern Arabic look.
- **Gradient hero card**: live greeting + animated decorative orbs, time of day, Hijri date (e.g. ٧ ذو القعدة ١٤٤٧هـ) and Gregorian date side by side.
- **Hijri calendar**: pure-JS Tabular Islamic Calendar conversion with Arabic month names — no API needed.
- **Prayer-times widget**: computes Fajr/Sunrise/Dhuhr/Asr/Maghrib/Isha locally using the Muslim World League algorithm, shows the next prayer with a live countdown, highlights the upcoming prayer in a horizontal strip, and lets the student pick from 10 Yemeni cities (Sana'a, Aden, Taiz, Hodeidah, Ibb, Mukalla, Seiyun, Marib, Dhamar, Hajjah).
- **Theme engine**: 4 modes — light, dark, follow system, auto by time of day.
- **First-launch onboarding**: prompts the student for their name once, then personalizes greetings.
- **Dynamic Arabic greeting**: changes by time (صباح الخير / طاب مساؤك / مساء النور).
- **Daily dhikr**: rotates per weekday; on Friday shows a pulsing breathing button with halo + glow → counter modal (0→10) for صلاة على النبي.
- **Smooth entrance animations**: dashboard cards stagger-fade-in for a polished first impression.
- **Haptic feedback**: subtle taps on tool cards and the Friday button (native only).
- **Polished drawer**: gradient brand header with logo + greeting, theme grid, full navigation, and a developer footer card.
- **Notification system**: red dot when tasks are pending, green dot when 24h tip is ready; the tip page reveals via blur→clear animation only after both conditions are met.
- **6 tools**: GPA calculator (with goal simulator), task organizer (Eisenhower priority), scientific calculator (sin/cos/tan/log/ln/√/x!/π/e), time-management plan (3 zoomable images), formula reference (physics/math/chemistry searchable), study timer (study + break phases with progress dots).
- **Developer page**: developer photo, name (Arabic + English), motivational glowing quote, WhatsApp contact modal that composes a message and opens wa.me/967781453408.

## Workflows

- `artifacts/qaaed: expo` — runs Expo dev server with React Native Web preview.

## Notes

- All UI uses `writingDirection: "rtl"`, `textAlign: "right"`, and `flexDirection: "row-reverse"` to render correctly without forcing global RTL (which would require an app reload on Expo Go).
- The Friday dhikr modal uses segmented progress dots and breathing halo animations.
- The scientific calculator evaluates expressions safely via a wrapped `Function` with replaced symbols (×÷−π) and helper functions for trig (DEG/RAD), log, ln, factorial.
- WhatsApp deep link format: `https://wa.me/967781453408?text=` + URL-encoded message including the user's stored name.
