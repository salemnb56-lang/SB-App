package com.agon.app.data.models

import kotlinx.serialization.Serializable

@Serializable
data class Task(
    val id: Long = System.currentTimeMillis(),
    val title: String,
    val description: String = "",
    val category: TaskCategory = TaskCategory.PERSONAL,
    val priority: TaskPriority = TaskPriority.MEDIUM,
    val isCompleted: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val dueDate: Long? = null
)

enum class TaskCategory(val displayName: String, val emoji: String) {
    PERSONAL("شخصي", "👤"),
    WORK("عمل", "💼"),
    SHOPPING("تسوق", "🛒"),
    HEALTH("صحة", "🏃"),
    STUDY("دراسة", "📚"),
    OTHER("أخرى", "📌")
}

enum class TaskPriority(val displayName: String) {
    LOW("منخفضة"),
    MEDIUM("متوسطة"),
    HIGH("عالية"),
    URGENT("عاجلة")
}