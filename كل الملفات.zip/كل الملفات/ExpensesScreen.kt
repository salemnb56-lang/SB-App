package com.agon.app.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.agon.app.data.models.*
import com.agon.app.ui.components.*
import com.agon.app.ui.theme.*
import com.agon.app.viewmodel.MainViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExpensesScreen(
    viewModel: MainViewModel
) {
    val expenses by viewModel.expenses.collectAsState()
    val totalExpenses by viewModel.totalMonthlyExpenses.collectAsState()
    val monthlyBudget by viewModel.monthlyBudget.collectAsState()
    
    var showAddDialog by remember { mutableStateOf(false) }
    var showBudgetDialog by remember { mutableStateOf(false) }
    
    val sortedExpenses = remember(expenses) {
        expenses.sortedByDescending { it.date }
    }
    
    // Group expenses by category
    val expensesByCategory = remember(sortedExpenses) {
        sortedExpenses.groupBy { it.category }
            .mapValues { entry -> entry.value.sumOf { it.amount } }
    }
    
    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(DarkBackground)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "💰 المصروفات",
                                style = MaterialTheme.typography.headlineMedium,
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "تتبع مصروفاتك بذكاء",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                        
                        IconButton(
                            onClick = { showBudgetDialog = true }
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "تحديد الميزانية",
                                tint = TextSecondary
                            )
                        }
                    }
                }
            }
            
            // Summary Card
            item {
                GlassCard(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "إجمالي الشهر",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary
                            )
                            Text(
                                text = "${String.format("%.0f", totalExpenses)} ر.ي",
                                style = MaterialTheme.typography.headlineMedium,
                                color = NeonPink,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                        
                        if (monthlyBudget > 0) {
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "الميزانية",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextSecondary
                                )
                                Text(
                                    text = "${String.format("%.0f", monthlyBudget)} ر.ي",
                                    style = MaterialTheme.typography.headlineSmall,
                                    color = if (totalExpenses > monthlyBudget) NeonPink else NeonGreen,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }
                        }
                    }
                }
            }
            
            // Category breakdown
            if (expensesByCategory.isNotEmpty()) {
                item {
                    Text(
                        text = "التوزيع حسب التصنيف",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
                
                item {
                    GlassCard(
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            expensesByCategory.entries.sortedByDescending { it.value }.forEach { (category, amount) ->
                                val percentage = if (totalExpenses > 0) (amount / totalExpenses) else 0.0
                                
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = category.emoji,
                                        style = MaterialTheme.typography.bodyLarge
                                    )
                                    
                                    Spacer(modifier = Modifier.width(8.dp))
                                    
                                    Text(
                                        text = category.displayName,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = TextPrimary,
                                        modifier = Modifier.width(80.dp)
                                    )
                                    
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(8.dp)
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(DarkSurfaceVariant)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxHeight()
                                                .fillMaxWidth(percentage.toFloat())
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(NeonBlue)
                                        )
                                    }
                                    
                                    Spacer(modifier = Modifier.width(8.dp))
                                    
                                    Text(
                                        text = String.format("%.0f", amount),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSecondary
                                    )
                                }
                            }
                        }
                    }
                }
            }
            
            // Recent expenses
            item {
                Text(
                    text = "المصروفات الأخيرة",
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
            
            if (sortedExpenses.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 48.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.Receipt,
                                contentDescription = null,
                                tint = TextMuted,
                                modifier = Modifier.size(64.dp)
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "لا توجد مصروفات مسجلة",
                                style = MaterialTheme.typography.bodyLarge,
                                color = TextSecondary
                            )
                        }
                    }
                }
            } else {
                items(sortedExpenses, key = { it.id }) { expense ->
                    ExpenseItem(
                        expense = expense,
                        onDelete = { viewModel.deleteExpense(expense.id) }
                    )
                }
            }
            
            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }
        
        // FAB
        FloatingActionButton(
            onClick = { showAddDialog = true },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp),
            containerColor = NeonPink,
            contentColor = Color.White
        ) {
            Icon(Icons.Default.Add, contentDescription = "إضافة مصروف")
        }
    }
    
    // Add Expense Dialog
    if (showAddDialog) {
        AddExpenseDialog(
            onDismiss = { showAddDialog = false },
            onAdd = { expense ->
                viewModel.addExpense(expense)
                showAddDialog = false
            },
            parseQuickInput = viewModel::parseQuickInput
        )
    }
    
    // Budget Dialog
    if (showBudgetDialog) {
        BudgetDialog(
            currentBudget = monthlyBudget,
            onDismiss = { showBudgetDialog = false },
            onSave = { budget ->
                viewModel.setBudget(budget)
                showBudgetDialog = false
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun AddExpenseDialog(
    onDismiss: () -> Unit,
    onAdd: (Expense) -> Unit,
    parseQuickInput: (String) -> Pair<String, Double>?
) {
    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf(ExpenseCategory.OTHER) }
    var note by remember { mutableStateOf("") }
    var quickInput by remember { mutableStateOf("") }
    var useQuickInput by remember { mutableStateOf(true) }
    
    // Parse quick input
    LaunchedEffect(quickInput) {
        if (quickInput.isNotBlank()) {
            val parsed = parseQuickInput(quickInput)
            if (parsed != null) {
                title = parsed.first
                amount = parsed.second.toString()
            }
        }
    }
    
    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
    ) {
        Column(
            modifier = Modifier
                .background(DarkSurface)
                .padding(24.dp)
        ) {
            Text(
                text = "إضافة مصروف",
                style = MaterialTheme.typography.headlineSmall,
                color = TextPrimary,
                fontWeight = FontWeight.Bold
            )
            
            Spacer(modifier = Modifier.height(20.dp))
            
            // Quick input toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = useQuickInput,
                    onClick = { useQuickInput = true },
                    label = { Text("إدخال سريع") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = NeonBlue.copy(alpha = 0.2f),
                        selectedLabelColor = NeonBlue
                    )
                )
                FilterChip(
                    selected = !useQuickInput,
                    onClick = { useQuickInput = false },
                    label = { Text("تفصيلي") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = NeonBlue.copy(alpha = 0.2f),
                        selectedLabelColor = NeonBlue
                    )
                )
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            if (useQuickInput) {
                // Quick input
                OutlinedTextField(
                    value = quickInput,
                    onValueChange = { quickInput = it },
                    label = { Text("اكتب مصروفك") },
                    placeholder = { Text("مثال: اشتريت خبز بـ 500") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonBlue,
                        unfocusedBorderColor = TextMuted,
                        focusedLabelColor = NeonBlue,
                        cursorColor = NeonBlue
                    ),
                    shape = RoundedCornerShape(12.dp)
                )
                
                if (title.isNotBlank() && amount.isNotBlank()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "✓ تم التعرف: $title - ${amount} ر.ي",
                        style = MaterialTheme.typography.bodySmall,
                        color = NeonGreen
                    )
                }
            } else {
                // Detailed input
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("عنوان المصروف") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonBlue,
                        unfocusedBorderColor = TextMuted,
                        focusedLabelColor = NeonBlue,
                        cursorColor = NeonBlue
                    ),
                    shape = RoundedCornerShape(12.dp)
                )
                
                Spacer(modifier = Modifier.height(12.dp))
                
                OutlinedTextField(
                    value = amount,
                    onValueChange = { amount = it.filter { c -> c.isDigit() || c == '.' } },
                    label = { Text("المبلغ (ر.ي)") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonBlue,
                        unfocusedBorderColor = TextMuted,
                        focusedLabelColor = NeonBlue,
                        cursorColor = NeonBlue
                    ),
                    shape = RoundedCornerShape(12.dp)
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Category
                Text(
                    text = "التصنيف",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                androidx.compose.foundation.layout.FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ExpenseCategory.values().forEach { category ->
                        FilterChip(
                            selected = selectedCategory == category,
                            onClick = { selectedCategory = category },
                            label = { Text("${category.emoji} ${category.displayName}") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = NeonPink.copy(alpha = 0.2f),
                                selectedLabelColor = NeonPink
                            )
                        )
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = onDismiss,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("إلغاء")
                }
                
                Button(
                    onClick = {
                        val amountValue = amount.toDoubleOrNull() ?: 0.0
                        if (title.isNotBlank() && amountValue > 0) {
                            onAdd(
                                Expense(
                                    title = title,
                                    amount = amountValue,
                                    category = selectedCategory,
                                    note = note
                                )
                            )
                        }
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = NeonPink
                    ),
                    enabled = title.isNotBlank() && amount.toDoubleOrNull() != null && amount.toDouble() > 0
                ) {
                    Text("إضافة")
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun BudgetDialog(
    currentBudget: Double,
    onDismiss: () -> Unit,
    onSave: (Double) -> Unit
) {
    var budget by remember { mutableStateOf(if (currentBudget > 0) currentBudget.toInt().toString() else "") }
    
    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
    ) {
        Column(
            modifier = Modifier
                .background(DarkSurface)
                .padding(24.dp)
        ) {
            Text(
                text = "تحديد الميزانية الشهرية",
                style = MaterialTheme.typography.headlineSmall,
                color = TextPrimary,
                fontWeight = FontWeight.Bold
            )
            
            Spacer(modifier = Modifier.height(20.dp))
            
            OutlinedTextField(
                value = budget,
                onValueChange = { budget = it.filter { c -> c.isDigit() } },
                label = { Text("الميزانية (ر.ي)") },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NeonBlue,
                    unfocusedBorderColor = TextMuted,
                    focusedLabelColor = NeonBlue,
                    cursorColor = NeonBlue
                ),
                shape = RoundedCornerShape(12.dp)
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = onDismiss,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("إلغاء")
                }
                
                Button(
                    onClick = {
                        val budgetValue = budget.toDoubleOrNull() ?: 0.0
                        if (budgetValue > 0) {
                            onSave(budgetValue)
                        }
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = NeonBlue
                    ),
                    enabled = budget.toDoubleOrNull() != null && budget.toDouble() > 0
                ) {
                    Text("حفظ")
                }
            }
        }
    }
}