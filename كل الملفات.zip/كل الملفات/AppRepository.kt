package com.agon.app.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.agon.app.data.models.*
import kotlinx.coroutines.flow.*
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "task_mint_data")

class AppRepository(private val context: Context) {
    
    private val json = Json { ignoreUnknownKeys = true }
    
    // Keys
    private object PreferencesKeys {
        val TASKS = stringSetPreferencesKey("tasks")
        val EXPENSES = stringSetPreferencesKey("expenses")
        val MONTHLY_BUDGET = doublePreferencesKey("monthly_budget")
        val USER_NAME = stringPreferencesKey("user_name")
    }
    
    // Tasks
    val tasks: Flow<List<Task>> = context.dataStore.data
        .map { preferences ->
            preferences[PreferencesKeys.TASKS]?.map { json.decodeFromString<Task>(it) } ?: emptyList()
        }
    
    suspend fun addTask(task: Task) {
        context.dataStore.edit { preferences ->
            val currentTasks = preferences[PreferencesKeys.TASKS]?.toMutableSet() ?: mutableSetOf()
            currentTasks.add(json.encodeToString(task))
            preferences[PreferencesKeys.TASKS] = currentTasks
        }
    }
    
    suspend fun updateTask(task: Task) {
        context.dataStore.edit { preferences ->
            val currentTasks = preferences[PreferencesKeys.TASKS]?.toMutableSet() ?: mutableSetOf()
            currentTasks.removeIf { json.decodeFromString<Task>(it).id == task.id }
            currentTasks.add(json.encodeToString(task))
            preferences[PreferencesKeys.TASKS] = currentTasks
        }
    }
    
    suspend fun deleteTask(taskId: Long) {
        context.dataStore.edit { preferences ->
            val currentTasks = preferences[PreferencesKeys.TASKS]?.toMutableSet() ?: mutableSetOf()
            currentTasks.removeIf { json.decodeFromString<Task>(it).id == taskId }
            preferences[PreferencesKeys.TASKS] = currentTasks
        }
    }
    
    // Expenses
    val expenses: Flow<List<Expense>> = context.dataStore.data
        .map { preferences ->
            preferences[PreferencesKeys.EXPENSES]?.map { json.decodeFromString<Expense>(it) } ?: emptyList()
        }
    
    suspend fun addExpense(expense: Expense) {
        context.dataStore.edit { preferences ->
            val currentExpenses = preferences[PreferencesKeys.EXPENSES]?.toMutableSet() ?: mutableSetOf()
            currentExpenses.add(json.encodeToString(expense))
            preferences[PreferencesKeys.EXPENSES] = currentExpenses
        }
    }
    
    suspend fun deleteExpense(expenseId: Long) {
        context.dataStore.edit { preferences ->
            val currentExpenses = preferences[PreferencesKeys.EXPENSES]?.toMutableSet() ?: mutableSetOf()
            currentExpenses.removeIf { json.decodeFromString<Expense>(it).id == expenseId }
            preferences[PreferencesKeys.EXPENSES] = currentExpenses
        }
    }
    
    // Budget
    val monthlyBudget: Flow<Double> = context.dataStore.data
        .map { preferences -> preferences[PreferencesKeys.MONTHLY_BUDGET] ?: 0.0 }
    
    suspend fun setMonthlyBudget(budget: Double) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.MONTHLY_BUDGET] = budget
        }
    }
    
    // User Name
    val userName: Flow<String> = context.dataStore.data
        .map { preferences -> preferences[PreferencesKeys.USER_NAME] ?: "مستخدم" }
    
    suspend fun setUserName(name: String) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.USER_NAME] = name
        }
    }
}