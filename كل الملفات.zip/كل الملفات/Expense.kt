package com.agon.app.data.models

import kotlinx.serialization.Serializable

@Serializable
data class Expense(
    val id: Long = System.currentTimeMillis(),
    val title: String,
    val amount: Double,
    val category: ExpenseCategory = ExpenseCategory.OTHER,
    val note: String = "",
    val date: Long = System.currentTimeMillis()
)

enum class ExpenseCategory(val displayName: String, val emoji: String) {
    FOOD("طعام", "🍔"),
    TRANSPORT("مواصلات", "🚗"),
    SHOPPING("تسوق", "🛍️"),
    BILLS("فواتير", "📄"),
    HEALTH("صحة", "💊"),
    ENTERTAINMENT("ترفيه", "🎮"),
    EDUCATION("تعليم", "📚"),
    OTHER("أخرى", "💰")
}