package com.agon.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.agon.app.data.models.*
import com.agon.app.data.repository.AppRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Calendar

class MainViewModel(application: Application) : AndroidViewModel(application) {
    
    private val repository = AppRepository(application)
    
    // Tasks
    val tasks = repository.tasks.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    
    val pendingTasks = tasks.map { list -> list.filter { !it.isCompleted } }
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    
    val completedTasks = tasks.map { list -> list.filter { it.isCompleted } }
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    
    // Expenses
    val expenses = repository.expenses.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    
    val monthlyExpenses = expenses.map { list ->
        val calendar = Calendar.getInstance()
        val currentMonth = calendar.get(Calendar.MONTH)
        val currentYear = calendar.get(Calendar.YEAR)
        list.filter { expense ->
            val expenseCalendar = Calendar.getInstance().apply { timeInMillis = expense.date }
            expenseCalendar.get(Calendar.MONTH) == currentMonth && 
            expenseCalendar.get(Calendar.YEAR) == currentYear
        }
    }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    
    val totalMonthlyExpenses = monthlyExpenses.map { list -> list.sumOf { it.amount } }
        .stateIn(viewModelScope, SharingStarted.Lazily, 0.0)
    
    val monthlyBudget = repository.monthlyBudget.stateIn(viewModelScope, SharingStarted.Lazily, 0.0)
    
    val userName = repository.userName.stateIn(viewModelScope, SharingStarted.Lazily, "مستخدم")
    
    // Dashboard Stats
    val todayTasksCount = pendingTasks.map { list ->
        val today = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        list.count { task ->
            task.dueDate?.let { it >= today && it < today + 86400000 } ?: false
        }
    }.stateIn(viewModelScope, SharingStarted.Lazily, 0)
    
    // Actions
    fun addTask(task: Task) {
        viewModelScope.launch {
            repository.addTask(task)
        }
    }
    
    fun toggleTask(task: Task) {
        viewModelScope.launch {
            repository.updateTask(task.copy(isCompleted = !task.isCompleted))
        }
    }
    
    fun deleteTask(taskId: Long) {
        viewModelScope.launch {
            repository.deleteTask(taskId)
        }
    }
    
    fun addExpense(expense: Expense) {
        viewModelScope.launch {
            repository.addExpense(expense)
        }
    }
    
    fun deleteExpense(expenseId: Long) {
        viewModelScope.launch {
            repository.deleteExpense(expenseId)
        }
    }
    
    fun setBudget(budget: Double) {
        viewModelScope.launch {
            repository.setMonthlyBudget(budget)
        }
    }
    
    fun setUserName(name: String) {
        viewModelScope.launch {
            repository.setUserName(name)
        }
    }
    
    // Parse quick input
    fun parseQuickInput(input: String): Pair<String, Double>? {
        val regex = Regex("(.+?)\\s+(?:بـ|ب|بمبلغ)?\\s*([\\d,.]+)")
        val match = regex.find(input)
        return match?.let {
            val title = it.groupValues[1].trim()
            val amount = it.groupValues[2].replace(",", "").toDoubleOrNull() ?: 0.0
            Pair(title, amount)
        }
    }
}