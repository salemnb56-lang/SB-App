package com.agon.app.ui.theme

import androidx.compose.ui.graphics.Color

// Dark Theme - Cyberpunk/Neon Style
val DarkBackground = Color(0xFF0A0A0F)
val DarkSurface = Color(0xFF12121A)
val DarkSurfaceVariant = Color(0xFF1A1A25)
val DarkCard = Color(0xFF1E1E2E)

val NeonBlue = Color(0xFF00D4FF)
val NeonPurple = Color(0xFFB24BF3)
val NeonPink = Color(0xFFFF2E97)
val NeonGreen = Color(0xFF00FF88)
val NeonOrange = Color(0xFFFF6B35)
val NeonYellow = Color(0xFFFFD600)

val TextPrimary = Color(0xFFF5F5F7)
val TextSecondary = Color(0xFF9E9E9E)
val TextMuted = Color(0xFF6B6B6B)

val GlassWhite = Color(0x1AFFFFFF)
val GlassBorder = Color(0x33FFFFFF)

// Light Theme
val LightBackground = Color(0xFFF8F9FA)
val LightSurface = Color(0xFFFFFFFF)
val LightCard = Color(0xFFF0F0F5)

val PrimaryBlue = Color(0xFF0066FF)
val PrimaryPurple = Color(0xFF7C3AED)
val PrimaryPink = Color(0xFFE91E63)
val PrimaryGreen = Color(0xFF00C853)
val PrimaryOrange = Color(0xFFFF5722)

val ErrorRed = Color(0xFFFF3B30)
val SuccessGreen = Color(0xFF34C759)
val WarningYellow = Color(0xFFFFCC00)