package com.agon.app.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.agon.app.data.models.*
import com.agon.app.ui.components.*
import com.agon.app.ui.theme.*
import com.agon.app.viewmodel.MainViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun DashboardScreen(
    viewModel: MainViewModel,
    onNavigateToTasks: () -> Unit,
    onNavigateToExpenses: () -> Unit
) {
    val userName by viewModel.userName.collectAsState()
    val pendingTasks by viewModel.pendingTasks.collectAsState()
    val completedTasks by viewModel.completedTasks.collectAsState()
    val totalExpenses by viewModel.totalMonthlyExpenses.collectAsState()
    val monthlyBudget by viewModel.monthlyBudget.collectAsState()
    val recentExpenses by viewModel.expenses.collectAsState()
    
    val greeting = remember {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        when {
            hour < 12 -> "صباح الخير"
            hour < 17 -> "مساء الخير"
            else -> "مساء النور"
        }
    }
    
    val todayDate = remember {
        SimpleDateFormat("EEEE، dd MMMM", Locale("ar")).format(Date())
    }
    
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 24.dp, bottom = 8.dp)
            ) {
                Text(
                    text = "$greeting، $userName 👋",
                    style = MaterialTheme.typography.headlineMedium,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = todayDate,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
        
        // Quick Stats
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                StatCard(
                    modifier = Modifier.weight(1f),
                    title = "مهام معلقة",
                    value = pendingTasks.size.toString(),
                    icon = Icons.Default.PendingActions,
                    color = NeonBlue,
                    onClick = onNavigateToTasks
                )
                StatCard(
                    modifier = Modifier.weight(1f),
                    title = "مكتملة",
                    value = completedTasks.size.toString(),
                    icon = Icons.Default.CheckCircle,
                    color = NeonGreen,
                    onClick = onNavigateToTasks
                )
            }
        }
        
        // Budget Card
        item {
            BudgetCard(
                totalExpenses = totalExpenses,
                budget = monthlyBudget,
                onNavigateToExpenses = onNavigateToExpenses
            )
        }
        
        // Recent Tasks
        item {
            SectionHeader(
                title = "المهام الأخيرة",
                actionText = "عرض الكل",
                onAction = onNavigateToTasks
            )
        }
        
        if (pendingTasks.isEmpty()) {
            item {
                EmptyState(
                    icon = Icons.Default.Checklist,
                    message = "لا توجد مهام حالياً",
                    actionText = "إضافة مهمة",
                    onAction = onNavigateToTasks
                )
            }
        } else {
            items(pendingTasks.take(3)) { task ->
                TaskItem(
                    task = task,
                    onToggle = { viewModel.toggleTask(task) },
                    onDelete = { viewModel.deleteTask(task.id) }
                )
            }
        }
        
        // Recent Expenses
        item {
            SectionHeader(
                title = "المصروفات الأخيرة",
                actionText = "عرض الكل",
                onAction = onNavigateToExpenses
            )
        }
        
        if (recentExpenses.isEmpty()) {
            item {
                EmptyState(
                    icon = Icons.Default.Receipt,
                    message = "لا توجد مصروفات مسجلة",
                    actionText = "إضافة مصروف",
                    onAction = onNavigateToExpenses
                )
            }
        } else {
            items(recentExpenses.sortedByDescending { it.date }.take(3)) { expense ->
                ExpenseItem(
                    expense = expense,
                    onDelete = { viewModel.deleteExpense(expense.id) }
                )
            }
        }
        
        // Bottom spacing
        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun StatCard(
    modifier: Modifier = Modifier,
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    onClick: () -> Unit
) {
    GlassCard(
        modifier = modifier,
        onClick = onClick
    ) {
        Column(
            horizontalAlignment = Alignment.Start,
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = color,
                    modifier = Modifier.size(20.dp)
                )
            }
            
            Spacer(modifier = Modifier.height(12.dp))
            
            Text(
                text = value,
                style = MaterialTheme.typography.headlineMedium,
                color = TextPrimary,
                fontWeight = FontWeight.Bold
            )
            
            Text(
                text = title,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
        }
    }
}

@Composable
private fun BudgetCard(
    totalExpenses: Double,
    budget: Double,
    onNavigateToExpenses: () -> Unit
) {
    val percentage = if (budget > 0) (totalExpenses / budget).coerceIn(0.0, 1.0) else 0.0
    val remaining = budget - totalExpenses
    
    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp)),
        onClick = onNavigateToExpenses
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "المصروفات الشهرية",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                    Text(
                        text = "${String.format("%.0f", totalExpenses)} ر.ي",
                        style = MaterialTheme.typography.headlineMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
                
                Box(
                    modifier = Modifier.size(64.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(
                        progress = { percentage.toFloat() },
                        modifier = Modifier.size(64.dp),
                        color = if (percentage > 0.8) NeonPink else NeonGreen,
                        strokeWidth = 6.dp,
                        trackColor = DarkSurfaceVariant
                    )
                    Text(
                        text = "${(percentage * 100).toInt()}%",
                        style = MaterialTheme.typography.labelMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            
            if (budget > 0) {
                Spacer(modifier = Modifier.height(12.dp))
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "الميزانية: ${String.format("%.0f", budget)} ر.ي",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMuted
                    )
                    Text(
                        text = "المتبقي: ${String.format("%.0f", remaining)} ر.ي",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (remaining >= 0) NeonGreen else NeonPink
                    )
                }
            }
        }
    }
}

@Composable
private fun SectionHeader(
    title: String,
    actionText: String,
    onAction: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            color = TextPrimary,
            fontWeight = FontWeight.SemiBold
        )
        
        TextButton(onClick = onAction) {
            Text(
                text = actionText,
                color = NeonBlue,
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@Composable
private fun EmptyState(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    message: String,
    actionText: String,
    onAction: () -> Unit
) {
    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        onClick = onAction
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = TextMuted,
                modifier = Modifier.size(48.dp)
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            Text(
                text = message,
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = actionText,
                style = MaterialTheme.typography.bodyMedium,
                color = NeonBlue
            )
        }
    }
}