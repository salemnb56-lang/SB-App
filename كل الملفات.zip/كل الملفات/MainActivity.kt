package com.agon.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.agon.app.ui.screens.DashboardScreen
import com.agon.app.ui.screens.ExpensesScreen
import com.agon.app.ui.screens.SettingsScreen
import com.agon.app.ui.screens.TasksScreen
import com.agon.app.ui.theme.AgonAppTheme
import com.agon.app.ui.theme.DarkBackground
import com.agon.app.ui.theme.NeonBlue
import com.agon.app.ui.theme.NeonPink
import com.agon.app.ui.theme.NeonPurple
import com.agon.app.ui.theme.TextPrimary
import com.agon.app.ui.theme.TextSecondary
import com.agon.app.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            AgonAppTheme(darkTheme = true) {
                MainApp()
            }
        }
    }
}

sealed class Screen(
    val route: String,
    val title: String,
    val icon: ImageVector,
    val selectedColor: androidx.compose.ui.graphics.Color
) {
    object Dashboard : Screen("dashboard", "الرئيسية", Icons.Default.Dashboard, NeonBlue)
    object Tasks : Screen("tasks", "المهام", Icons.Default.Checklist, NeonPurple)
    object Expenses : Screen("expenses", "المصروفات", Icons.Default.Receipt, NeonPink)
    object Settings : Screen("settings", "الإعدادات", Icons.Default.Settings, TextSecondary)
}

@Composable
fun MainApp() {
    val navController = rememberNavController()
    val viewModel: MainViewModel = viewModel()
    
    val screens = listOf(
        Screen.Dashboard,
        Screen.Tasks,
        Screen.Expenses,
        Screen.Settings
    )

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = DarkBackground,
        bottomBar = { BottomNav(navController, screens) },
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Dashboard.route,
            modifier = Modifier.padding(innerPadding),
        ) {
            composable(Screen.Dashboard.route) { 
                DashboardScreen(
                    viewModel = viewModel,
                    onNavigateToTasks = { navController.navigate(Screen.Tasks.route) },
                    onNavigateToExpenses = { navController.navigate(Screen.Expenses.route) }
                )
            }
            composable(Screen.Tasks.route) { 
                TasksScreen(viewModel = viewModel)
            }
            composable(Screen.Expenses.route) { 
                ExpensesScreen(viewModel = viewModel)
            }
            composable(Screen.Settings.route) { 
                SettingsScreen(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun BottomNav(
    navController: NavHostController,
    screens: List<Screen>
) {
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    NavigationBar(
        containerColor = DarkBackground.copy(alpha = 0.95f),
        contentColor = TextSecondary
    ) {
        screens.forEach { screen ->
            val selected = currentRoute == screen.route
            
            NavigationBarItem(
                icon = { 
                    Icon(
                        screen.icon, 
                        contentDescription = screen.title,
                        tint = if (selected) screen.selectedColor else TextSecondary
                    ) 
                },
                label = { 
                    Text(
                        screen.title,
                        color = if (selected) screen.selectedColor else TextSecondary
                    ) 
                },
                selected = selected,
                onClick = {
                    if (!selected) {
                        navController.navigate(screen.route) {
                            popUpTo(Screen.Dashboard.route) {
                                saveState = true
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = screen.selectedColor.copy(alpha = 0.15f)
                )
            )
        }
    }
}
