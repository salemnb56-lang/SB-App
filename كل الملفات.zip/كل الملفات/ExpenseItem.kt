package com.agon.app.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.agon.app.data.models.*
import com.agon.app.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun ExpenseItem(
    expense: Expense,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showDelete by remember { mutableStateOf(false) }
    
    val categoryColor = when (expense.category) {
        ExpenseCategory.FOOD -> NeonOrange
        ExpenseCategory.TRANSPORT -> NeonBlue
        ExpenseCategory.SHOPPING -> NeonPink
        ExpenseCategory.BILLS -> NeonPurple
        ExpenseCategory.HEALTH -> NeonGreen
        ExpenseCategory.ENTERTAINMENT -> NeonYellow
        ExpenseCategory.EDUCATION -> NeonBlue
        ExpenseCategory.OTHER -> TextSecondary
    }
    
    val dateFormat = SimpleDateFormat("dd MMM", Locale("ar"))
    val formattedDate = dateFormat.format(Date(expense.date))
    
    GlassCard(
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Category icon
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(categoryColor.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = expense.category.emoji,
                    style = MaterialTheme.typography.headlineMedium
                )
            }
            
            Spacer(modifier = Modifier.width(12.dp))
            
            // Content
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = expense.title,
                    style = MaterialTheme.typography.bodyLarge,
                    color = TextPrimary,
                    fontWeight = FontWeight.Medium
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(top = 4.dp)
                )
                {
                    Text(
                        text = expense.category.displayName,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "•",
                        color = TextMuted
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = formattedDate,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMuted
                    )
                }
            }
            
            // Amount
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "${String.format("%.0f", expense.amount)} ر.ي",
                    style = MaterialTheme.typography.titleMedium,
                    color = NeonPink,
                    fontWeight = FontWeight.Bold
                )
                
                IconButton(
                    onClick = { showDelete = true },
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "حذف",
                        tint = TextMuted,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
    
    // Delete confirmation
    if (showDelete) {
        AlertDialog(
            onDismissRequest = { showDelete = false },
            title = { Text("حذف المصروف") },
            text = { Text("هل أنت متأكد من حذف هذا المصروف؟") },
            confirmButton = {
                TextButton(
                    onClick = {
                        onDelete()
                        showDelete = false
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = NeonPink)
                ) {
                    Text("حذف")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDelete = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}