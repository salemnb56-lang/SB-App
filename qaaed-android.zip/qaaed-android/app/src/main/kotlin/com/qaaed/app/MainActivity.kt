package com.qaaed.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.remember
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.compose.currentBackStackEntryAsState
import com.qaaed.app.component.AppDrawerContent
import com.qaaed.app.component.OnboardingDialog
import com.qaaed.app.screen.*
import com.qaaed.app.theme.LocalAppPalette
import com.qaaed.app.theme.QaaedTheme
import com.qaaed.app.viewmodel.PrayerViewModel
import com.qaaed.app.viewmodel.TasksViewModel
import com.qaaed.app.viewmodel.ThemeViewModel
import com.qaaed.app.viewmodel.TipViewModel
import com.qaaed.app.viewmodel.UserViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val themeVm: ThemeViewModel = viewModel()
            val mode by themeVm.mode.collectAsState()
            QaaedTheme(mode = mode) {
                AppRoot(themeVm = themeVm)
            }
        }
    }
}

@Composable
private fun AppRoot(themeVm: ThemeViewModel) {
    val palette = LocalAppPalette.current
    val nav = rememberNavController()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    val userVm: UserViewModel = viewModel()
    val prayerVm: PrayerViewModel = viewModel()
    val tasksVm: TasksViewModel = viewModel()
    val tipVm: TipViewModel = viewModel()

    val onboardingDone by userVm.onboardingDone.collectAsState()
    val ready by userVm.ready.collectAsState()
    val userName by userVm.userName.collectAsState()
    val city by userVm.city.collectAsState()

    val backStackEntry by nav.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: "home"

    Box(
        Modifier
            .fillMaxSize()
            .background(palette.background)
            .padding(WindowInsets.systemBars.asPaddingValues())
    ) {
        ModalNavigationDrawer(
            drawerState = drawerState,
            drawerContent = {
                ModalDrawerSheet(drawerContainerColor = palette.card) {
                    AppDrawerContent(
                        currentRoute = currentRoute,
                        onNavigate = { route ->
                            nav.navigate(route) {
                                popUpTo("home") { inclusive = false }
                                launchSingleTop = true
                            }
                        },
                        onClose = { scope.launch { drawerState.close() } },
                        themeVm = themeVm,
                    )
                }
            },
        ) {
            NavHost(navController = nav, startDestination = "home", modifier = Modifier.fillMaxSize()) {
                composable("home") { HomeScreen(userVm, prayerVm, onMenu = { scope.launch { drawerState.open() } }, onNavigate = { nav.navigate(it) }) }
                composable("calculator") { CalculatorScreen(onMenu = { scope.launch { drawerState.open() } }) }
                composable("tasks") { TasksScreen(tasksVm, onMenu = { scope.launch { drawerState.open() } }) }
                composable("scientific") { ScientificScreen(onMenu = { scope.launch { drawerState.open() } }) }
                composable("plan") { PlanScreen(onMenu = { scope.launch { drawerState.open() } }) }
                composable("formulas") { FormulasScreen(onMenu = { scope.launch { drawerState.open() } }) }
                composable("timer") { TimerScreen(onMenu = { scope.launch { drawerState.open() } }) }
                composable("notification") { NotificationScreen(tipVm, onMenu = { scope.launch { drawerState.open() } }) }
                composable("cultural") { CulturalScreen(onMenu = { scope.launch { drawerState.open() } }) }
                composable("developer") { DeveloperScreen(onMenu = { scope.launch { drawerState.open() } }) }
            }
        }

        if (ready && !onboardingDone) {
            OnboardingDialog(
                initialName = userName,
                initialCity = city,
                onDone = { name, c -> userVm.completeOnboarding(name, c) },
            )
        }
    }
}
