package com.qaaed.app.screen

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.KeyboardOptions
import com.qaaed.app.component.*
import com.qaaed.app.data.AppData
import com.qaaed.app.data.GpaPoint
import com.qaaed.app.data.Subject
import com.qaaed.app.theme.LocalAppPalette
import java.util.UUID

@Composable
fun CalculatorScreen(onMenu: () -> Unit) {
    val palette = LocalAppPalette.current
    val subjects = remember { mutableStateListOf<Subject>() }
    var name by remember { mutableStateOf(TextFieldValue("")) }
    var credits by remember { mutableStateOf(TextFieldValue("3")) }
    var grade by remember { mutableStateOf("A") }
    var goalGpa by remember { mutableStateOf(TextFieldValue("3.5")) }
    var previousGpa by remember { mutableStateOf(TextFieldValue("")) }
    var previousCredits by remember { mutableStateOf(TextFieldValue("")) }

    val gpa = remember(subjects.toList()) {
        if (subjects.isEmpty()) 0f
        else {
            val totalCredits = subjects.sumOf { it.credits.toDouble() }
            val totalPoints = subjects.sumOf { (AppData.gradePoints.first { g -> g.grade == it.grade }.points * it.credits).toDouble() }
            if (totalCredits == 0.0) 0f else (totalPoints / totalCredits).toFloat()
        }
    }

    val cumulativeGpa = remember(subjects.toList(), previousGpa.text, previousCredits.text) {
        val pg = previousGpa.text.toFloatOrNull() ?: 0f
        val pc = previousCredits.text.toFloatOrNull() ?: 0f
        val currCredits = subjects.sumOf { it.credits.toDouble() }.toFloat()
        val currPoints = subjects.sumOf { (AppData.gradePoints.first { g -> g.grade == it.grade }.points * it.credits).toDouble() }.toFloat()
        val totalC = pc + currCredits
        if (totalC == 0f) 0f else (pg * pc + currPoints) / totalC
    }

    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        AppHeader(title = "حاسبة المعدل", onMenu = onMenu, subtitle = "GPA — فصلي وتراكمي")

        Column(modifier = Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            ThemedCard {
                Column {
                    Text("معدلك الفصلي", color = palette.mutedForeground, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "%.2f".format(gpa),
                        color = palette.foreground,
                        fontSize = 44.sp,
                        fontWeight = FontWeight.ExtraBold,
                    )
                    Spacer(Modifier.height(8.dp))
                    Text("التراكمي: %.2f".format(cumulativeGpa), color = palette.secondary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                }
            }

            ThemedCard {
                Column {
                    Text("إضافة مادة", color = palette.foreground, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    LabeledField("اسم المادة", name, { name = it })
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Box(Modifier.weight(1f)) { LabeledField("الساعات", credits, { credits = it }, numeric = true) }
                        Box(Modifier.weight(1.4f)) {
                            Column {
                                Text("التقدير", color = palette.foreground, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                Spacer(Modifier.height(8.dp))
                                GradePicker(grade, AppData.gradePoints) { grade = it }
                            }
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    PrimaryButton("إضافة المادة", {
                        val cr = credits.text.toFloatOrNull() ?: 0f
                        if (name.text.isNotBlank() && cr > 0) {
                            subjects.add(Subject(UUID.randomUUID().toString(), name.text.trim(), grade, cr))
                            name = TextFieldValue("")
                        }
                    }, leading = { Icon(Icons.Outlined.Add, contentDescription = null, tint = palette.onGradient) })
                }
            }

            if (subjects.isNotEmpty()) {
                ThemedCard {
                    Column {
                        Text("المواد (${subjects.size})", color = palette.foreground, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(10.dp))
                        subjects.forEach { s ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(palette.background)
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(s.name, color = palette.foreground, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                    Text("${s.credits.toInt()} ساعة • ${s.grade}", color = palette.mutedForeground, fontSize = 12.sp)
                                }
                                Icon(
                                    Icons.Outlined.Delete,
                                    contentDescription = "حذف",
                                    tint = palette.danger,
                                    modifier = Modifier.clickable { subjects.remove(s) }.padding(6.dp),
                                )
                            }
                        }
                    }
                }
            }

            ThemedCard {
                Column {
                    Text("محاكاة المعدل التراكمي", color = palette.foreground, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("أدخل معدلك السابق وعدد ساعاتك المعتمدة لحساب التراكمي.", color = palette.mutedForeground, fontSize = 12.sp, lineHeight = 18.sp)
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Box(Modifier.weight(1f)) { LabeledField("المعدل السابق", previousGpa, { previousGpa = it }, numeric = true) }
                        Box(Modifier.weight(1f)) { LabeledField("الساعات السابقة", previousCredits, { previousCredits = it }, numeric = true) }
                    }
                    Spacer(Modifier.height(12.dp))
                    LabeledField("هدفك (مثال: 3.5)", goalGpa, { goalGpa = it }, numeric = true)
                    val target = goalGpa.text.toFloatOrNull() ?: 0f
                    val gap = target - cumulativeGpa
                    Spacer(Modifier.height(10.dp))
                    Text(
                        when {
                            cumulativeGpa <= 0f -> "أضف مواد لتظهر التوصيات."
                            gap <= 0f -> "أنت متجاوز هدفك بـ ${"%.2f".format(-gap)} نقطة! استمر."
                            else -> "تحتاج إلى رفع تراكميك بـ ${"%.2f".format(gap)} نقطة للوصول إلى هدفك."
                        },
                        color = palette.foreground,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        lineHeight = 20.sp,
                    )
                }
            }

            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun LabeledField(label: String, value: TextFieldValue, onChange: (TextFieldValue) -> Unit, numeric: Boolean = false) {
    val palette = LocalAppPalette.current
    Column {
        Text(label, color = palette.foreground, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        Spacer(Modifier.height(6.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(palette.background)
                .border(1.dp, palette.border, RoundedCornerShape(12.dp))
                .padding(horizontal = 12.dp, vertical = 12.dp)
        ) {
            BasicTextField(
                value = value,
                onValueChange = onChange,
                singleLine = true,
                cursorBrush = SolidColor(palette.secondary),
                textStyle = TextStyle(color = palette.foreground, fontSize = 15.sp, fontWeight = FontWeight.SemiBold),
                keyboardOptions = if (numeric) KeyboardOptions(keyboardType = KeyboardType.Number) else KeyboardOptions.Default,
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

@Composable
private fun GradePicker(selected: String, options: List<GpaPoint>, onSelect: (String) -> Unit) {
    val palette = LocalAppPalette.current
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        options.chunked(4).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                row.forEach { g ->
                    val active = g.grade == selected
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (active) palette.secondary else palette.background)
                            .clickable { onSelect(g.grade) }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(g.grade, color = if (active) palette.onGradient else palette.foreground, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
                repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}
