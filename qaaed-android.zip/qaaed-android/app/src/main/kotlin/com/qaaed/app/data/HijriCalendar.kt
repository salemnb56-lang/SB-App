package com.qaaed.app.data

import java.util.Calendar
import java.util.TimeZone

/**
 * Tabular Islamic Calendar (Kuwaiti algorithm).
 * Ported from JS to match the React Native version exactly.
 */
object HijriCalendar {

    val months = arrayOf(
        "محرم", "صفر", "ربيع الأول", "ربيع الآخر",
        "جمادى الأولى", "جمادى الآخرة", "رجب", "شعبان",
        "رمضان", "شوال", "ذو القعدة", "ذو الحجة"
    )

    val arabicWeekdays = arrayOf(
        "الأحد", "الإثنين", "الثلاثاء", "الأربعاء",
        "الخميس", "الجمعة", "السبت"
    )

    private fun gregorianToJulianDay(year: Int, month: Int, day: Int): Long {
        val a = (14 - month) / 12
        val y = year + 4800 - a
        val m = month + 12 * a - 3
        return (day + (153 * m + 2) / 5 + 365L * y + y / 4 - y / 100 + y / 400 - 32045)
    }

    private fun julianDayToHijri(jd: Long): Triple<Int, Int, Int> {
        val l0 = jd - 1948440 + 10632
        val n = ((l0 - 1) / 10631).toInt()
        var l = l0 - 10631 * n + 354
        val j = (((10985 - l) / 5316) * ((50 * l) / 17719) +
                (l / 5670) * ((43 * l) / 15238)).toInt()
        l = l - ((30 - j) / 15) * ((17719 * j) / 50) -
                (j / 16) * ((15238 * j) / 43) + 29
        val month = ((24 * l) / 709).toInt()
        val day = (l - (709 * month) / 24).toInt()
        val year = 30 * n + j - 30
        return Triple(year, month, day)
    }

    data class HijriDate(
        val year: Int,
        val month: Int,
        val day: Int,
        val monthName: String,
        val weekday: String,
    )

    fun fromGregorian(cal: Calendar = Calendar.getInstance(TimeZone.getTimeZone("Asia/Aden"))): HijriDate {
        val y = cal.get(Calendar.YEAR)
        val m = cal.get(Calendar.MONTH) + 1
        val d = cal.get(Calendar.DAY_OF_MONTH)
        val jd = gregorianToJulianDay(y, m, d)
        val (hy, hm, hd) = julianDayToHijri(jd)
        val weekdayIdx = (cal.get(Calendar.DAY_OF_WEEK) - 1).coerceIn(0, 6)
        return HijriDate(
            year = hy,
            month = hm,
            day = hd,
            monthName = months[(hm - 1).coerceIn(0, 11)],
            weekday = arabicWeekdays[weekdayIdx],
        )
    }

    fun toArabicNumerals(input: Any): String {
        val arabic = arrayOf("٠","١","٢","٣","٤","٥","٦","٧","٨","٩")
        return input.toString().map { ch ->
            if (ch.isDigit()) arabic[ch.digitToInt()] else ch.toString()
        }.joinToString("")
    }

    fun isFriday(cal: Calendar = Calendar.getInstance()): Boolean =
        cal.get(Calendar.DAY_OF_WEEK) == Calendar.FRIDAY
}
