package com.qaaed.app.component

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.qaaed.app.theme.LocalAppPalette
import com.qaaed.app.viewmodel.ThemeMode
import com.qaaed.app.viewmodel.ThemeViewModel

data class DrawerItem(val key: String, val label: String, val icon: ImageVector, val route: String)

val drawerItems = listOf(
    DrawerItem("home", "الرئيسية", Icons.Outlined.Home, "home"),
    DrawerItem("calc", "حاسبة المعدل", Icons.Outlined.Calculate, "calculator"),
    DrawerItem("tasks", "المهام", Icons.Outlined.Checklist, "tasks"),
    DrawerItem("scientific", "آلة حاسبة علمية", Icons.Outlined.Functions, "scientific"),
    DrawerItem("plan", "الخطة الدراسية", Icons.Outlined.CalendarMonth, "plan"),
    DrawerItem("formulas", "القوانين والمعادلات", Icons.Outlined.Science, "formulas"),
    DrawerItem("timer", "مؤقت المذاكرة", Icons.Outlined.Timer, "timer"),
    DrawerItem("notification", "إشعار اليوم", Icons.Outlined.NotificationsActive, "notification"),
    DrawerItem("cultural", "زاوية ثقافية", Icons.Outlined.AutoStories, "cultural"),
    DrawerItem("dev", "المطوّر", Icons.Outlined.Person, "developer"),
)

@Composable
fun AppDrawerContent(
    currentRoute: String,
    onNavigate: (String) -> Unit,
    onClose: () -> Unit,
    themeVm: ThemeViewModel,
) {
    val palette = LocalAppPalette.current
    val haptic = LocalHapticFeedback.current
    val mode by themeVm.mode.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxHeight()
            .width(300.dp)
            .background(palette.card)
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(Brush.linearGradient(listOf(palette.gradientStart, palette.gradientEnd)))
                .padding(18.dp)
        ) {
            Column {
                Text("القائد الرقمي", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
                Spacer(Modifier.height(4.dp))
                Text("رفيق الطالب الذكي", color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
            }
        }

        Spacer(Modifier.height(20.dp))
        Text("التنقّل", color = palette.mutedForeground, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))

        drawerItems.forEach { item ->
            val active = item.route == currentRoute
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(if (active) palette.secondary.copy(alpha = 0.14f) else Color.Transparent)
                    .clickable {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onClose()
                        onNavigate(item.route)
                    }
                    .padding(horizontal = 12.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    item.icon,
                    contentDescription = null,
                    tint = if (active) palette.secondary else palette.foreground,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(Modifier.width(12.dp))
                Text(
                    item.label,
                    color = if (active) palette.secondary else palette.foreground,
                    fontSize = 15.sp,
                    fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
                )
            }
        }

        Spacer(Modifier.height(20.dp))
        Text("المظهر", color = palette.mutedForeground, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))

        val themeOptions = listOf(
            ThemeMode.LIGHT to ("فاتح" to Icons.Outlined.LightMode),
            ThemeMode.DARK to ("داكن" to Icons.Outlined.DarkMode),
            ThemeMode.SYSTEM to ("النظام" to Icons.Outlined.Smartphone),
            ThemeMode.AUTO_TIME to ("تلقائي" to Icons.Outlined.Schedule),
        )

        themeOptions.forEach { (m, lbl) ->
            val (label, icon) = lbl
            val active = m == mode
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (active) palette.accent.copy(alpha = 0.16f) else Color.Transparent)
                    .clickable {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        themeVm.setMode(m)
                    }
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(if (active) palette.accent else palette.background),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, contentDescription = null, tint = if (active) Color.White else palette.foreground, modifier = Modifier.size(16.dp))
                }
                Spacer(Modifier.width(10.dp))
                Text(label, color = palette.foreground, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}
