package com.qaaed.app.screen

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.qaaed.app.component.*
import com.qaaed.app.data.HijriCalendar
import com.qaaed.app.data.PrefKeys
import com.qaaed.app.data.dataStore
import com.qaaed.app.data.editPref
import com.qaaed.app.theme.LocalAppPalette
import com.qaaed.app.viewmodel.PrayerViewModel
import com.qaaed.app.viewmodel.UserViewModel
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.flow.first
import java.util.Calendar

@Composable
fun HomeScreen(
    userVm: UserViewModel,
    prayerVm: PrayerViewModel,
    onMenu: () -> Unit,
    onNavigate: (String) -> Unit,
) {
    val palette = LocalAppPalette.current
    val ctx = LocalContext.current
    val userName by userVm.userName.collectAsState()
    val city by userVm.city.collectAsState()
    val prayerTimes by prayerVm.times.collectAsState()
    var showFriday by remember { mutableStateOf(false) }

    LaunchedEffect(city) { prayerVm.update(city) }

    LaunchedEffect(Unit) {
        if (HijriCalendar.isFriday()) {
            val prefs = ctx.dataStore.data.first()
            val last = prefs[PrefKeys.FRIDAY_LAST_SHOWN] ?: 0L
            val cal = Calendar.getInstance()
            val today = cal.apply {
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }.timeInMillis
            if (last < today) {
                showFriday = true
                ctx.editPref { it[PrefKeys.FRIDAY_LAST_SHOWN] = System.currentTimeMillis() }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        AppHeader(title = "القائد الرقمي", onMenu = onMenu, subtitle = "رفيقك في رحلة التميّز")

        Column(modifier = Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            AnimatedEntrance(delayMs = 50) { mod ->
                HeroCard(userName = userName, city = city, modifier = mod)
            }
            AnimatedEntrance(delayMs = 150) { mod ->
                Box(modifier = mod) {
                    PrayerTimesCard(prayerTimes)
                }
            }

            AnimatedEntrance(delayMs = 250) { mod ->
                Column(modifier = mod) {
                    val tools = listOf(
                        Triple("حاسبة المعدل", "احسب معدلك الفصلي والتراكمي" to Icons.Outlined.Calculate, "calculator" to palette.secondary),
                        Triple("المهام", "نظّم يومك بمصفوفة آيزنهاور" to Icons.Outlined.Checklist, "tasks" to palette.accent),
                        Triple("الآلة العلمية", "حسابات علمية متقدمة" to Icons.Outlined.Functions, "scientific" to Color(0xFF8E5BFF)),
                        Triple("الخطة الدراسية", "خطّط لأسبوعك ومراجعاتك" to Icons.Outlined.CalendarMonth, "plan" to Color(0xFFFF9F43)),
                        Triple("القوانين والمعادلات", "فيزياء، كيمياء، رياضيات" to Icons.Outlined.Science, "formulas" to Color(0xFF1E9E6A)),
                        Triple("مؤقت المذاكرة", "بومودورو لتركيز عميق" to Icons.Outlined.Timer, "timer" to Color(0xFFD8413A)),
                        Triple("إشعار اليوم", "نصيحة دراسية يومية" to Icons.Outlined.NotificationsActive, "notification" to Color(0xFFE0A100)),
                        Triple("زاوية ثقافية", "علم، فكر، أخلاق" to Icons.Outlined.AutoStories, "cultural" to Color(0xFF1ABC9C)),
                    )
                    tools.chunked(2).forEach { row ->
                        Row(modifier = Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            row.forEach { entry ->
                                val title = entry.first
                                val (subtitle, icon) = entry.second
                                val (route, color) = entry.third
                                ToolCard(
                                    title = title,
                                    subtitle = subtitle,
                                    icon = icon,
                                    accent = color,
                                    onClick = { onNavigate(route) },
                                    modifier = Modifier.weight(1f).heightIn(min = 140.dp),
                                )
                            }
                            if (row.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }

            Spacer(Modifier.height(24.dp))
        }
    }

    if (showFriday) {
        FridayDhikrDialog(onClose = { showFriday = false })
    }
}
