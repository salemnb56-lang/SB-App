package com.qaaed.app.screen

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CheckBox
import androidx.compose.material.icons.outlined.CheckBoxOutlineBlank
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.qaaed.app.component.*
import com.qaaed.app.data.StudyTask
import com.qaaed.app.data.TaskPriority
import com.qaaed.app.theme.LocalAppPalette
import com.qaaed.app.viewmodel.TasksViewModel

@Composable
fun TasksScreen(tasksVm: TasksViewModel, onMenu: () -> Unit) {
    val palette = LocalAppPalette.current
    val tasks by tasksVm.tasks.collectAsState()
    var input by remember { mutableStateOf(TextFieldValue("")) }
    var priority by remember { mutableStateOf(TaskPriority.IMPORTANT) }

    val priorityMeta = mapOf(
        TaskPriority.URGENT_IMPORTANT to ("عاجل ومهم" to palette.danger),
        TaskPriority.IMPORTANT to ("مهم" to palette.warning),
        TaskPriority.URGENT to ("عاجل" to palette.accent),
        TaskPriority.NORMAL to ("عادي" to palette.success),
    )

    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        AppHeader(title = "المهام", onMenu = onMenu, subtitle = "مصفوفة آيزنهاور")

        Column(modifier = Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            ThemedCard {
                Column {
                    Text("مهمة جديدة", color = palette.foreground, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(10.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(palette.background)
                            .border(1.dp, palette.border, RoundedCornerShape(12.dp))
                            .padding(horizontal = 12.dp, vertical = 12.dp)
                    ) {
                        BasicTextField(
                            value = input,
                            onValueChange = { input = it },
                            singleLine = true,
                            cursorBrush = SolidColor(palette.secondary),
                            textStyle = TextStyle(color = palette.foreground, fontSize = 15.sp, fontWeight = FontWeight.SemiBold),
                            modifier = Modifier.fillMaxWidth(),
                            decorationBox = { inner ->
                                if (input.text.isEmpty()) Text("مثال: مراجعة الفصل الأول رياضيات", color = palette.mutedForeground, fontSize = 14.sp)
                                inner()
                            },
                        )
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("الأولوية", color = palette.foreground, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Spacer(Modifier.height(6.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        TaskPriority.entries.forEach { p ->
                            val (label, color) = priorityMeta.getValue(p)
                            val active = p == priority
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (active) color.copy(alpha = 0.18f) else palette.background)
                                    .clickable { priority = p }
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(Modifier.size(10.dp).clip(RoundedCornerShape(50)).background(color))
                                Spacer(Modifier.width(10.dp))
                                Text(label, color = palette.foreground, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                            }
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    PrimaryButton("إضافة المهمة", {
                        tasksVm.add(input.text, priority)
                        input = TextFieldValue("")
                    })
                }
            }

            if (tasks.isNotEmpty()) {
                val grouped = tasks.groupBy { it.priority }
                TaskPriority.entries.forEach { p ->
                    val list = grouped[p].orEmpty()
                    if (list.isNotEmpty()) {
                        val (label, color) = priorityMeta.getValue(p)
                        ThemedCard {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(Modifier.size(12.dp).clip(RoundedCornerShape(50)).background(color))
                                    Spacer(Modifier.width(8.dp))
                                    Text(label, color = palette.foreground, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                    Spacer(Modifier.weight(1f))
                                    Text("${list.count { !it.isDone }} / ${list.size}", color = palette.mutedForeground, fontSize = 12.sp)
                                }
                                Spacer(Modifier.height(8.dp))
                                list.forEach { TaskRow(it, color, tasksVm) }
                            }
                        }
                    }
                }
                if (tasks.any { it.isDone }) {
                    OutlinedActionButton("حذف المنجزة", onClick = { tasksVm.clearDone() })
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun TaskRow(task: StudyTask, accent: Color, vm: TasksViewModel) {
    val palette = LocalAppPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(palette.background)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            if (task.isDone) Icons.Outlined.CheckBox else Icons.Outlined.CheckBoxOutlineBlank,
            contentDescription = null,
            tint = if (task.isDone) accent else palette.mutedForeground,
            modifier = Modifier.clickable { vm.toggle(task.id) }.size(24.dp),
        )
        Spacer(Modifier.width(10.dp))
        Text(
            task.title,
            color = if (task.isDone) palette.mutedForeground else palette.foreground,
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.weight(1f),
        )
        Icon(
            Icons.Outlined.Delete,
            contentDescription = "حذف",
            tint = palette.danger,
            modifier = Modifier.clickable { vm.remove(task.id) }.padding(4.dp),
        )
    }
}
