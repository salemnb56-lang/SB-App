package com.qaaed.app.component

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.qaaed.app.data.AppData
import com.qaaed.app.data.CityData
import com.qaaed.app.theme.LocalAppPalette

@Composable
fun OnboardingDialog(
    initialName: String,
    initialCity: CityData,
    onDone: (name: String, city: CityData) -> Unit,
) {
    val palette = LocalAppPalette.current
    var step by remember { mutableIntStateOf(0) }
    var name by remember { mutableStateOf(TextFieldValue(initialName)) }
    var city by remember { mutableStateOf(initialCity) }

    Dialog(
        onDismissRequest = {},
        properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false, usePlatformDefaultWidth = false),
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.55f)),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .padding(20.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(28.dp))
                    .background(palette.card)
            ) {
                Column(modifier = Modifier.padding(22.dp)) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(Brush.linearGradient(listOf(palette.gradientStart, palette.gradientEnd)))
                            .padding(18.dp)
                    ) {
                        Column {
                            Text(if (step == 0) "أهلاً بك في القائد الرقمي" else "اختر مدينتك",
                                color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                            Spacer(Modifier.height(6.dp))
                            Text(
                                if (step == 0) "اكتب اسمك لنخصّص لك التجربة"
                                else "نحتاج موقعك لعرض مواقيت الصلاة بدقّة",
                                color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp,
                            )
                        }
                    }
                    Spacer(Modifier.height(18.dp))

                    if (step == 0) {
                        Text("اسمك", color = palette.foreground, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Spacer(Modifier.height(8.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(palette.background)
                                .border(1.dp, palette.border, RoundedCornerShape(14.dp))
                                .padding(horizontal = 14.dp, vertical = 12.dp)
                        ) {
                            BasicTextField(
                                value = name,
                                onValueChange = { name = it },
                                singleLine = true,
                                cursorBrush = SolidColor(palette.secondary),
                                textStyle = TextStyle(color = palette.foreground, fontSize = 16.sp, fontWeight = FontWeight.SemiBold),
                                modifier = Modifier.fillMaxWidth(),
                                decorationBox = { inner ->
                                    if (name.text.isEmpty()) {
                                        Text("مثال: محمد", color = palette.mutedForeground, fontSize = 15.sp)
                                    }
                                    inner()
                                }
                            )
                        }
                        Spacer(Modifier.height(20.dp))
                        PrimaryButton("التالي", { step = 1 }, enabled = name.text.isNotBlank())
                    } else {
                        Column(
                            modifier = Modifier
                                .heightIn(max = 320.dp)
                                .verticalScroll(rememberScrollState())
                        ) {
                            AppData.yemeniCities.forEach { c ->
                                val active = c.id == city.id
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(if (active) palette.secondary.copy(alpha = 0.16f) else palette.background)
                                        .clickable { city = c }
                                        .padding(horizontal = 14.dp, vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(c.nameAr, color = palette.foreground, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                                    if (active) Text("✓", color = palette.secondary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                }
                            }
                        }
                        Spacer(Modifier.height(16.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedActionButton("رجوع", { step = 0 }, modifier = Modifier.weight(1f))
                            PrimaryButton("ابدأ", { onDone(name.text.trim(), city) }, modifier = Modifier.weight(1.4f))
                        }
                    }
                }
            }
        }
    }
}
