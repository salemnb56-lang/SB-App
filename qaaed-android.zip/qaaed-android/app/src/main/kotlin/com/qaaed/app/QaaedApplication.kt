package com.qaaed.app

import android.app.Application

class QaaedApplication : Application()
