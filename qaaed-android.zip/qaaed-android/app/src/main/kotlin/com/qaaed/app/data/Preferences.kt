package com.qaaed.app.data

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore by preferencesDataStore(name = "qaaed_prefs")

object PrefKeys {
    val THEME_MODE = stringPreferencesKey("theme_mode")
    val USER_NAME = stringPreferencesKey("user_name")
    val SELECTED_CITY = stringPreferencesKey("selected_city")
    val ONBOARDING_DONE = booleanPreferencesKey("onboarding_done")
    val FRIDAY_LAST_SHOWN = longPreferencesKey("friday_last_shown")
    val TASKS_JSON = stringPreferencesKey("tasks_json")
    val LAST_TIP_TIME = longPreferencesKey("last_tip_time")
    val LAST_TIP_INDEX = stringPreferencesKey("last_tip_index")
}

fun Context.prefFlow(): Flow<Preferences> = dataStore.data

suspend fun Context.editPref(block: suspend (androidx.datastore.preferences.core.MutablePreferences) -> Unit) {
    dataStore.edit { block(it) }
}

fun <T> Flow<Preferences>.mapKey(getter: (Preferences) -> T): Flow<T> = map(getter)
