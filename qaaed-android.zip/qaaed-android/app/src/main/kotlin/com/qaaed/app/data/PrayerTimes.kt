package com.qaaed.app.data

import java.util.Calendar
import java.util.TimeZone
import kotlin.math.*

/**
 * Prayer Times calculation using the MWL (Muslim World League) method.
 * Ported from React Native version.
 */
object PrayerTimesCalculator {

    private const val FAJR_ANGLE = 18.0
    private const val ISHA_ANGLE = 17.0
    private const val MAGHRIB_ANGLE = 0.0
    private val timezone = 3.0 // Yemen UTC+3

    data class PrayerTimes(
        val fajr: String,
        val sunrise: String,
        val dhuhr: String,
        val asr: String,
        val maghrib: String,
        val isha: String,
        val nextPrayerKey: String,
        val nextPrayerLabel: String,
        val minutesUntilNext: Int,
    )

    private fun deg2rad(d: Double) = d * PI / 180.0
    private fun rad2deg(r: Double) = r * 180.0 / PI
    private fun fixHour(h: Double): Double {
        var v = h - 24.0 * floor(h / 24.0)
        if (v < 0) v += 24.0
        return v
    }

    private fun julianDate(y: Int, m: Int, d: Int): Double {
        var year = y; var month = m
        if (month <= 2) { year -= 1; month += 12 }
        val a = floor(year / 100.0)
        val b = 2 - a + floor(a / 4)
        return floor(365.25 * (year + 4716)) + floor(30.6001 * (month + 1)) + d + b - 1524.5
    }

    private fun sunPosition(jd: Double): Pair<Double, Double> {
        val d = jd - 2451545.0
        val g = (357.529 + 0.98560028 * d).let { fixDeg(it) }
        val q = (280.459 + 0.98564736 * d).let { fixDeg(it) }
        val l = (q + 1.915 * sin(deg2rad(g)) + 0.020 * sin(deg2rad(2 * g))).let { fixDeg(it) }
        val e = 23.439 - 0.00000036 * d
        val ra = rad2deg(atan2(cos(deg2rad(e)) * sin(deg2rad(l)), cos(deg2rad(l)))) / 15.0
        val decl = rad2deg(asin(sin(deg2rad(e)) * sin(deg2rad(l))))
        val eqt = q / 15.0 - fixHour(ra)
        return Pair(decl, eqt)
    }

    private fun fixDeg(d: Double): Double {
        var v = d - 360.0 * floor(d / 360.0)
        if (v < 0) v += 360.0
        return v
    }

    private fun computeTime(angle: Double, t: Double, lat: Double, decl: Double): Double {
        val a = deg2rad(angle)
        val cosT = (-sin(a) - sin(deg2rad(lat)) * sin(deg2rad(decl))) /
                (cos(deg2rad(lat)) * cos(deg2rad(decl)))
        if (cosT.isNaN() || cosT < -1 || cosT > 1) return Double.NaN
        return t + (if (t == 6.0 || t == 18.0) 1.0 else -1.0) * rad2deg(acos(cosT)) / 15.0
    }

    private fun computeAsr(t: Double, lat: Double, decl: Double): Double {
        val factor = 1.0
        val a = atan(1.0 / (factor + tan(abs(deg2rad(lat) - deg2rad(decl)))))
        val cosT = (sin(a) - sin(deg2rad(lat)) * sin(deg2rad(decl))) /
                (cos(deg2rad(lat)) * cos(deg2rad(decl)))
        if (cosT.isNaN()) return Double.NaN
        return t + rad2deg(acos(cosT)) / 15.0
    }

    private fun formatTime(time: Double): String {
        if (time.isNaN()) return "--:--"
        val t = fixHour(time + 0.5 / 60.0)
        val h = floor(t).toInt()
        val m = floor((t - h) * 60.0).toInt()
        return "%02d:%02d".format(h, m)
    }

    fun calculate(lat: Double, lng: Double, cal: Calendar = Calendar.getInstance(TimeZone.getTimeZone("Asia/Aden"))): PrayerTimes {
        val y = cal.get(Calendar.YEAR)
        val m = cal.get(Calendar.MONTH) + 1
        val d = cal.get(Calendar.DAY_OF_MONTH)
        val jd = julianDate(y, m, d) - lng / (15.0 * 24.0)
        val (decl, eqt) = sunPosition(jd)

        fun adjust(t: Double) = t + timezone - lng / 15.0 - eqt

        val dhuhrT = 12.0 + timezone - lng / 15.0 - eqt
        val sunriseT = adjust(computeTime(0.833, 6.0, lat, decl))
        val maghribT = adjust(computeTime(MAGHRIB_ANGLE + 0.833, 18.0, lat, decl))
        val fajrT = adjust(computeTime(FAJR_ANGLE, 5.0, lat, decl))
        val ishaT = adjust(computeTime(ISHA_ANGLE, 19.0, lat, decl))
        val asrT = adjust(computeAsr(13.0, lat, decl))

        val nowMinutes = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        val prayers = listOf(
            "fajr" to fajrT to "الفجر",
            "sunrise" to sunriseT to "الشروق",
            "dhuhr" to dhuhrT to "الظهر",
            "asr" to asrT to "العصر",
            "maghrib" to maghribT to "المغرب",
            "isha" to ishaT to "العشاء",
        )
        var nextKey = "fajr"; var nextLabel = "الفجر"; var minsUntil = 0
        for (p in prayers) {
            val mins = (fixHour(p.first.second) * 60).toInt()
            if (mins > nowMinutes) {
                nextKey = p.first.first; nextLabel = p.second; minsUntil = mins - nowMinutes; break
            }
        }
        if (minsUntil == 0) {
            val firstFajrMins = (fixHour(fajrT) * 60).toInt() + 24 * 60
            nextKey = "fajr"; nextLabel = "الفجر"; minsUntil = firstFajrMins - nowMinutes
        }

        return PrayerTimes(
            fajr = formatTime(fajrT),
            sunrise = formatTime(sunriseT),
            dhuhr = formatTime(dhuhrT),
            asr = formatTime(asrT),
            maghrib = formatTime(maghribT),
            isha = formatTime(ishaT),
            nextPrayerKey = nextKey,
            nextPrayerLabel = nextLabel,
            minutesUntilNext = minsUntil,
        )
    }
}
