package com.qaaed.app.component

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch

@Composable
fun AnimatedEntrance(
    delayMs: Int = 0,
    fromY: Dp = 12.dp,
    durationMs: Int = 420,
    content: @Composable (Modifier) -> Unit,
) {
    val opacity = remember { Animatable(0f) }
    val translation = remember { Animatable(fromY.value) }
    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(delayMs.toLong())
        coroutineScope {
            launch { opacity.animateTo(1f, tween(durationMs)) }
            launch { translation.animateTo(0f, tween(durationMs)) }
        }
    }
    content(
        Modifier
            .alpha(opacity.value)
            .graphicsLayer { translationY = translation.value }
    )
}
