package com.qaaed.app.data

enum class TaskPriority { URGENT_IMPORTANT, IMPORTANT, URGENT, NORMAL }

data class StudyTask(
    val id: String,
    val title: String,
    val priority: TaskPriority,
    val isDone: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
)

data class Subject(
    val id: String,
    val name: String,
    val grade: String,
    val credits: Float,
)

data class GpaPoint(val grade: String, val points: Float, val arabic: String)

data class CityData(
    val id: String,
    val name: String,
    val nameAr: String,
    val lat: Double,
    val lng: Double,
)

object AppData {
    val gradePoints = listOf(
        GpaPoint("A+", 4.0f, "ممتاز مرتفع"),
        GpaPoint("A", 4.0f, "ممتاز"),
        GpaPoint("A-", 3.7f, "ممتاز منخفض"),
        GpaPoint("B+", 3.3f, "جيد جداً مرتفع"),
        GpaPoint("B", 3.0f, "جيد جداً"),
        GpaPoint("B-", 2.7f, "جيد جداً منخفض"),
        GpaPoint("C+", 2.3f, "جيد مرتفع"),
        GpaPoint("C", 2.0f, "جيد"),
        GpaPoint("C-", 1.7f, "جيد منخفض"),
        GpaPoint("D+", 1.3f, "مقبول مرتفع"),
        GpaPoint("D", 1.0f, "مقبول"),
        GpaPoint("F", 0.0f, "راسب"),
    )

    val yemeniCities = listOf(
        CityData("sanaa", "Sana'a", "صنعاء", 15.3694, 44.1910),
        CityData("aden", "Aden", "عدن", 12.7855, 45.0187),
        CityData("taiz", "Taiz", "تعز", 13.5795, 44.0209),
        CityData("hodeidah", "Hodeidah", "الحديدة", 14.7978, 42.9545),
        CityData("ibb", "Ibb", "إب", 13.9667, 44.1833),
        CityData("dhamar", "Dhamar", "ذمار", 14.5500, 44.4011),
        CityData("hadramaut", "Mukalla", "المكلا", 14.5424, 49.1242),
        CityData("mareb", "Marib", "مأرب", 15.4602, 45.3260),
        CityData("hajjah", "Hajjah", "حجة", 15.6943, 43.6063),
        CityData("saada", "Saada", "صعدة", 16.9402, 43.7637),
    )
}
