package com.qaaed.app.component

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Mosque
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.qaaed.app.data.PrayerTimesCalculator
import com.qaaed.app.theme.LocalAppPalette

@Composable
fun PrayerTimesCard(times: PrayerTimesCalculator.PrayerTimes?) {
    val palette = LocalAppPalette.current
    if (times == null) return
    val items = listOf(
        "fajr" to ("الفجر" to times.fajr),
        "sunrise" to ("الشروق" to times.sunrise),
        "dhuhr" to ("الظهر" to times.dhuhr),
        "asr" to ("العصر" to times.asr),
        "maghrib" to ("المغرب" to times.maghrib),
        "isha" to ("العشاء" to times.isha),
    )
    val hours = times.minutesUntilNext / 60
    val mins = times.minutesUntilNext % 60
    ThemedCard {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(palette.secondary.copy(alpha = 0.14f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Outlined.Mosque, contentDescription = null, tint = palette.secondary)
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("مواقيت الصلاة", color = palette.foreground, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "${times.nextPrayerLabel} بعد ${if (hours > 0) "${hours}سا " else ""}${mins}د",
                        color = palette.mutedForeground,
                        fontSize = 12.sp,
                    )
                }
            }
            Spacer(Modifier.height(14.dp))
            FlowRowSimple(items, palette, times.nextPrayerKey)
        }
    }
}

@Composable
private fun FlowRowSimple(
    items: List<Pair<String, Pair<String, String>>>,
    palette: com.qaaed.app.theme.AppPalette,
    nextKey: String,
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items.chunked(3).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { (key, label) ->
                    val (name, time) = label
                    val isNext = key == nextKey
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (isNext) palette.secondary else palette.background)
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                name,
                                color = if (isNext) palette.onGradient else palette.foreground,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                time,
                                color = if (isNext) palette.onGradient else palette.mutedForeground,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                            )
                        }
                    }
                }
                repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}
