package com.qaaed.app.component

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.qaaed.app.theme.LocalAppPalette

@Composable
fun ThemedCard(
    modifier: Modifier = Modifier,
    paddingValues: PaddingValues = PaddingValues(18.dp),
    radius: Int = 22,
    elevated: Boolean = true,
    backgroundOverride: Color? = null,
    content: @Composable () -> Unit,
) {
    val palette = LocalAppPalette.current
    val bg = backgroundOverride ?: if (elevated) palette.cardElevated else palette.card
    androidx.compose.foundation.layout.Box(
        modifier = modifier
            .clip(RoundedCornerShape(radius.dp))
            .background(bg)
            .border(1.dp, palette.border, RoundedCornerShape(radius.dp))
            .padding(paddingValues)
    ) {
        content()
    }
}
