package com.qaaed.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.qaaed.app.data.PrefKeys
import com.qaaed.app.data.StudyTask
import com.qaaed.app.data.TaskPriority
import com.qaaed.app.data.dataStore
import com.qaaed.app.data.editPref
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.util.UUID

class TasksViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx = app.applicationContext
    private val _tasks = MutableStateFlow<List<StudyTask>>(emptyList())
    val tasks: StateFlow<List<StudyTask>> = _tasks

    init {
        viewModelScope.launch {
            val raw = ctx.dataStore.data.first()[PrefKeys.TASKS_JSON] ?: ""
            _tasks.value = decode(raw)
        }
    }

    private fun encode(list: List<StudyTask>): String =
        list.joinToString("\u001E") { t ->
            listOf(t.id, t.title.replace("|", "/"), t.priority.name, t.isDone.toString(), t.createdAt.toString())
                .joinToString("\u001F")
        }

    private fun decode(raw: String): List<StudyTask> {
        if (raw.isBlank()) return emptyList()
        return raw.split("\u001E").mapNotNull { row ->
            val parts = row.split("\u001F")
            if (parts.size < 5) return@mapNotNull null
            runCatching {
                StudyTask(
                    id = parts[0],
                    title = parts[1],
                    priority = TaskPriority.valueOf(parts[2]),
                    isDone = parts[3].toBooleanStrict(),
                    createdAt = parts[4].toLong(),
                )
            }.getOrNull()
        }
    }

    private fun persist(list: List<StudyTask>) {
        _tasks.value = list
        viewModelScope.launch { ctx.editPref { it[PrefKeys.TASKS_JSON] = encode(list) } }
    }

    fun add(title: String, priority: TaskPriority) {
        if (title.isBlank()) return
        persist(_tasks.value + StudyTask(UUID.randomUUID().toString(), title.trim(), priority))
    }

    fun toggle(id: String) {
        persist(_tasks.value.map { if (it.id == id) it.copy(isDone = !it.isDone) else it })
    }

    fun remove(id: String) { persist(_tasks.value.filter { it.id != id }) }

    fun clearDone() { persist(_tasks.value.filter { !it.isDone }) }
}
