package com.qaaed.app.screen

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.qaaed.app.component.AppHeader
import com.qaaed.app.component.ThemedCard
import com.qaaed.app.theme.LocalAppPalette

private data class Pillar(val title: String, val accent: Color, val icon: ImageVector, val items: List<Pair<String, String>>)

@Composable
fun CulturalScreen(onMenu: () -> Unit) {
    val palette = LocalAppPalette.current
    val pillars = remember {
        listOf(
            Pillar("في العلم", Color(0xFF3F8CFF), Icons.Outlined.Science, listOf(
                "اطلب العلم من المهد إلى اللحد." to "الإمام علي (ع)",
                "العلم نور والجهل ظلام." to "حكمة عربية",
                "من سار على الدرب وصل، ومن جدّ وجد." to "مثل عربي",
                "اقرأ باسم ربّك الذي خلق." to "القرآن الكريم",
            )),
            Pillar("في الفكر", Color(0xFF8E5BFF), Icons.Outlined.Lightbulb, listOf(
                "أكثر شيءٍ يميّز الإنسان عقله." to "ابن سينا",
                "تفكّر ساعة خير من عبادة سنة." to "أثر منسوب",
                "من جدّ وجد، ومن زرع حصد." to "حكمة عربية",
                "العقل زينة الإنسان." to "حكمة",
            )),
            Pillar("في الأخلاق", Color(0xFF1E9E6A), Icons.Outlined.Spa, listOf(
                "إنّما بُعثت لأتمّم مكارم الأخلاق." to "النبي محمد ﷺ",
                "أكمل المؤمنين إيماناً أحسنهم خلقاً." to "حديث شريف",
                "خير الناس أنفعهم للناس." to "حديث شريف",
                "الكلمة الطيبة صدقة." to "حديث شريف",
            )),
        )
    }

    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        AppHeader(title = "زاوية ثقافية", onMenu = onMenu, subtitle = "علم • فكر • أخلاق")
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            pillars.forEach { p ->
                ThemedCard {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(p.accent.copy(alpha = 0.16f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(p.icon, contentDescription = null, tint = p.accent)
                            }
                            Spacer(Modifier.width(12.dp))
                            Text(p.title, color = palette.foreground, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
                        }
                        Spacer(Modifier.height(12.dp))
                        p.items.forEach { (quote, source) ->
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(palette.background)
                                    .padding(14.dp)
                            ) {
                                Column {
                                    Text(quote, color = palette.foreground, fontSize = 14.sp, lineHeight = 22.sp, fontWeight = FontWeight.SemiBold)
                                    Spacer(Modifier.height(4.dp))
                                    Text("— $source", color = p.accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
