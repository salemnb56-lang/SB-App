package com.qaaed.app.screen

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.qaaed.app.component.AppHeader
import com.qaaed.app.component.OutlinedActionButton
import com.qaaed.app.component.PrimaryButton
import com.qaaed.app.component.ThemedCard
import com.qaaed.app.data.HijriCalendar
import com.qaaed.app.theme.LocalAppPalette
import kotlinx.coroutines.delay

@Composable
fun TimerScreen(onMenu: () -> Unit) {
    val palette = LocalAppPalette.current
    val studySeconds = 25 * 60
    val breakSeconds = 5 * 60
    val totalCycles = 4

    var isStudy by remember { mutableStateOf(true) }
    var running by remember { mutableStateOf(false) }
    var seconds by remember { mutableIntStateOf(studySeconds) }
    var cycle by remember { mutableIntStateOf(1) }

    LaunchedEffect(running) {
        while (running) {
            delay(1000)
            if (seconds > 0) {
                seconds -= 1
            } else {
                if (isStudy) {
                    isStudy = false; seconds = breakSeconds
                } else {
                    isStudy = true
                    cycle = if (cycle >= totalCycles) 1 else cycle + 1
                    seconds = studySeconds
                }
            }
        }
    }

    val total = if (isStudy) studySeconds else breakSeconds
    val progress = 1f - (seconds.toFloat() / total)
    val mins = seconds / 60
    val secs = seconds % 60

    Column(modifier = Modifier.fillMaxSize()) {
        AppHeader(title = "مؤقت المذاكرة", onMenu = onMenu, subtitle = "بومودورو 25/5")
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            ThemedCard(paddingValues = PaddingValues(24.dp)) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Text(
                        if (isStudy) "وقت التركيز" else "استراحة قصيرة",
                        color = if (isStudy) palette.danger else palette.success,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                    )
                    Spacer(Modifier.height(20.dp))
                    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(240.dp)) {
                        Box(
                            Modifier
                                .size(240.dp)
                                .clip(CircleShape)
                                .background(palette.background)
                        )
                        Box(
                            Modifier
                                .size(220.dp)
                                .clip(CircleShape)
                                .background(Brush.linearGradient(listOf(palette.gradientStart, palette.gradientEnd))),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    "%02d:%02d".format(mins, secs),
                                    color = Color.White,
                                    fontSize = 56.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                )
                                Text("${(progress * 100).toInt()}%", color = Color.White.copy(alpha = 0.85f), fontSize = 14.sp)
                            }
                        }
                    }
                    Spacer(Modifier.height(20.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        repeat(totalCycles) { i ->
                            val on = i < cycle
                            Box(
                                Modifier
                                    .size(14.dp)
                                    .clip(CircleShape)
                                    .background(if (on) palette.secondary else palette.border)
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("الجلسة ${HijriCalendar.toArabicNumerals(cycle)} من ${HijriCalendar.toArabicNumerals(totalCycles)}", color = palette.mutedForeground, fontSize = 13.sp)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedActionButton(
                    "إعادة",
                    onClick = {
                        running = false; isStudy = true; cycle = 1; seconds = studySeconds
                    },
                    modifier = Modifier.weight(1f),
                )
                PrimaryButton(if (running) "إيقاف" else "ابدأ", { running = !running }, modifier = Modifier.weight(1.4f))
            }
        }
    }
}
