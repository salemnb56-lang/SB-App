package com.qaaed.app.screen

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.qaaed.app.component.AppHeader
import com.qaaed.app.component.ThemedCard
import com.qaaed.app.theme.LocalAppPalette
import kotlin.math.*

@Composable
fun ScientificScreen(onMenu: () -> Unit) {
    val palette = LocalAppPalette.current
    val haptic = LocalHapticFeedback.current
    var expression by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }

    fun press(s: String) {
        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        expression += s
    }
    fun clear() { expression = ""; result = "" }
    fun back() { if (expression.isNotEmpty()) expression = expression.dropLast(1) }
    fun evaluate() {
        result = runCatching { evalExpr(expression).let {
            if (it == it.toLong().toDouble()) it.toLong().toString() else "%.6g".format(it).trimEnd('0').trimEnd('.')
        } }.getOrDefault("خطأ")
    }

    val rows: List<List<Pair<String, () -> Unit>>> = listOf(
        listOf("sin" to { press("sin(") }, "cos" to { press("cos(") }, "tan" to { press("tan(") }, "π" to { press("π") }),
        listOf("ln" to { press("ln(") }, "log" to { press("log(") }, "√" to { press("√(") }, "^" to { press("^") }),
        listOf("(" to { press("(") }, ")" to { press(")") }, "C" to { clear() }, "⌫" to { back() }),
        listOf("7" to { press("7") }, "8" to { press("8") }, "9" to { press("9") }, "÷" to { press("÷") }),
        listOf("4" to { press("4") }, "5" to { press("5") }, "6" to { press("6") }, "×" to { press("×") }),
        listOf("1" to { press("1") }, "2" to { press("2") }, "3" to { press("3") }, "-" to { press("-") }),
        listOf("0" to { press("0") }, "." to { press(".") }, "=" to { evaluate() }, "+" to { press("+") }),
    )

    Column(modifier = Modifier.fillMaxSize()) {
        AppHeader(title = "آلة حاسبة علمية", onMenu = onMenu)

        Column(modifier = Modifier.padding(horizontal = 16.dp).weight(1f)) {
            ThemedCard {
                Column(horizontalAlignment = Alignment.End, modifier = Modifier.fillMaxWidth()) {
                    Text(
                        if (expression.isBlank()) "0" else expression,
                        color = palette.foreground,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.End,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    if (result.isNotBlank()) {
                        Spacer(Modifier.height(6.dp))
                        Text("= $result", color = palette.secondary, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                rows.forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        row.forEach { (label, action) ->
                            val isAction = label in listOf("=", "C", "⌫")
                            val isOp = label in listOf("÷", "×", "-", "+", "^")
                            val bg = when {
                                label == "=" -> palette.secondary
                                label == "C" -> palette.danger.copy(alpha = 0.18f)
                                label == "⌫" -> palette.warning.copy(alpha = 0.18f)
                                isOp -> palette.accent.copy(alpha = 0.20f)
                                else -> palette.card
                            }
                            val fg = if (label == "=") palette.onGradient else palette.foreground
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(56.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(bg)
                                    .clickable { action() },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(label, color = fg, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(20.dp))
        }
    }
}

private fun evalExpr(raw: String): Double {
    val s = raw.replace("×", "*").replace("÷", "/").replace("π", PI.toString())
        .replace("√", "sqrt").replace("ln", "log_e").replace("^", "**")
    return Parser(s).parseExpression().also {
        // ensure no leftover
    }
}

private class Parser(private val text: String) {
    private var pos = 0
    private val ch get() = if (pos < text.length) text[pos] else '\u0000'
    private fun eat(c: Char): Boolean { while (ch == ' ') pos++; if (ch == c) { pos++; return true }; return false }
    fun parseExpression(): Double {
        var x = parseTerm()
        while (true) {
            if (eat('+')) x += parseTerm()
            else if (eat('-')) x -= parseTerm()
            else return x
        }
    }
    private fun parseTerm(): Double {
        var x = parseFactor()
        while (true) {
            if (eat('*')) x *= parseFactor()
            else if (eat('/')) x /= parseFactor()
            else return x
        }
    }
    private fun parseFactor(): Double {
        if (eat('+')) return parseFactor()
        if (eat('-')) return -parseFactor()
        var x: Double
        val startPos = pos
        if (eat('(')) {
            x = parseExpression(); eat(')')
        } else if (ch.isDigit() || ch == '.') {
            while (ch.isDigit() || ch == '.') pos++
            x = text.substring(startPos, pos).toDouble()
        } else if (ch.isLetter()) {
            while (ch.isLetter() || ch == '_') pos++
            val func = text.substring(startPos, pos)
            eat('(')
            val arg = parseExpression()
            eat(')')
            x = when (func) {
                "sqrt" -> sqrt(arg)
                "sin" -> sin(arg); "cos" -> cos(arg); "tan" -> tan(arg)
                "log" -> log10(arg); "log_e" -> ln(arg)
                else -> Double.NaN
            }
        } else x = 0.0
        if (pos + 1 < text.length && text[pos] == '*' && text[pos + 1] == '*') {
            pos += 2; x = x.pow(parseFactor())
        }
        return x
    }
}
