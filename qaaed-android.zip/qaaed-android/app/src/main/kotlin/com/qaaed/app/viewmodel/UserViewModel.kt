package com.qaaed.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.qaaed.app.data.AppData
import com.qaaed.app.data.CityData
import com.qaaed.app.data.PrefKeys
import com.qaaed.app.data.dataStore
import com.qaaed.app.data.editPref
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class UserViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx = app.applicationContext

    private val _userName = MutableStateFlow("")
    val userName: StateFlow<String> = _userName

    private val _city = MutableStateFlow(AppData.yemeniCities[0])
    val city: StateFlow<CityData> = _city

    private val _onboardingDone = MutableStateFlow(false)
    val onboardingDone: StateFlow<Boolean> = _onboardingDone

    private val _ready = MutableStateFlow(false)
    val ready: StateFlow<Boolean> = _ready

    init {
        viewModelScope.launch {
            val prefs = ctx.dataStore.data.first()
            _userName.value = prefs[PrefKeys.USER_NAME] ?: ""
            val cityId = prefs[PrefKeys.SELECTED_CITY] ?: "sanaa"
            _city.value = AppData.yemeniCities.firstOrNull { it.id == cityId } ?: AppData.yemeniCities[0]
            _onboardingDone.value = prefs[PrefKeys.ONBOARDING_DONE] ?: false
            _ready.value = true
        }
    }

    fun setUserName(v: String) {
        _userName.value = v
        viewModelScope.launch { ctx.editPref { it[PrefKeys.USER_NAME] = v } }
    }

    fun setCity(c: CityData) {
        _city.value = c
        viewModelScope.launch { ctx.editPref { it[PrefKeys.SELECTED_CITY] = c.id } }
    }

    fun completeOnboarding(name: String, c: CityData) {
        _userName.value = name; _city.value = c; _onboardingDone.value = true
        viewModelScope.launch {
            ctx.editPref {
                it[PrefKeys.USER_NAME] = name
                it[PrefKeys.SELECTED_CITY] = c.id
                it[PrefKeys.ONBOARDING_DONE] = true
            }
        }
    }
}
