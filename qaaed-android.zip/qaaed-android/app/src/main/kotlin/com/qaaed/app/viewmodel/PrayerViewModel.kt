package com.qaaed.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.qaaed.app.data.CityData
import com.qaaed.app.data.PrayerTimesCalculator
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.util.Calendar

class PrayerViewModel : ViewModel() {

    private val _times = MutableStateFlow<PrayerTimesCalculator.PrayerTimes?>(null)
    val times: StateFlow<PrayerTimesCalculator.PrayerTimes?> = _times

    private var lastCity: CityData? = null

    fun update(city: CityData) {
        lastCity = city
        _times.value = PrayerTimesCalculator.calculate(city.lat, city.lng, Calendar.getInstance())
    }

    init {
        viewModelScope.launch {
            while (true) {
                delay(60_000L)
                lastCity?.let { update(it) }
            }
        }
    }
}
