package com.qaaed.app.component

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.qaaed.app.data.Dhikr
import com.qaaed.app.data.HijriCalendar
import com.qaaed.app.theme.LocalAppPalette

@Composable
fun FridayDhikrDialog(onClose: () -> Unit) {
    val palette = LocalAppPalette.current
    val haptic = LocalHapticFeedback.current
    var count by remember { mutableIntStateOf(0) }
    val pulse = remember { Animatable(1f) }

    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.6f)),
            contentAlignment = Alignment.Center
        ) {
            Box(
                Modifier
                    .padding(20.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(28.dp))
                    .background(palette.card)
                    .padding(22.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(Brush.linearGradient(listOf(palette.gradientStart, palette.gradientEnd)))
                            .padding(20.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("جمعة مباركة", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                            Spacer(Modifier.height(6.dp))
                            Text("أكثر من الصلاة على النبي ﷺ", color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
                        }
                    }
                    Spacer(Modifier.height(20.dp))
                    Text(
                        Dhikr.fridaySalawat,
                        color = palette.foreground,
                        fontSize = 16.sp,
                        lineHeight = 28.sp,
                        textAlign = TextAlign.Center,
                        fontWeight = FontWeight.SemiBold,
                    )
                    Spacer(Modifier.height(24.dp))

                    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(180.dp)) {
                        // Halo circle
                        Box(
                            Modifier
                                .size(180.dp)
                                .scale(pulse.value)
                                .clip(CircleShape)
                                .background(palette.secondary.copy(alpha = 0.18f))
                        )
                        Box(
                            Modifier
                                .size(140.dp)
                                .clip(CircleShape)
                                .background(Brush.linearGradient(listOf(palette.gradientStart, palette.gradientEnd)))
                                .clickable {
                                    if (count < Dhikr.FRIDAY_TARGET) {
                                        count++
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    HijriCalendar.toArabicNumerals(count),
                                    color = Color.White,
                                    fontSize = 56.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                )
                                Text(
                                    "من ${HijriCalendar.toArabicNumerals(Dhikr.FRIDAY_TARGET)}",
                                    color = Color.White.copy(alpha = 0.85f),
                                    fontSize = 13.sp,
                                )
                            }
                        }
                    }

                    LaunchedEffect(count) {
                        if (count > 0 && count <= Dhikr.FRIDAY_TARGET) {
                            pulse.snapTo(1f)
                            pulse.animateTo(1.18f, tween(220))
                            pulse.animateTo(1f, tween(220))
                        }
                    }

                    Spacer(Modifier.height(24.dp))
                    if (count >= Dhikr.FRIDAY_TARGET) {
                        Text(
                            "تقبّل الله منك ✨",
                            color = palette.success,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                        )
                        Spacer(Modifier.height(12.dp))
                    }
                    PrimaryButton(if (count >= Dhikr.FRIDAY_TARGET) "إغلاق" else "متابعة لاحقاً", onClose)
                }
            }
        }
    }
}
