package com.qaaed.app.data

import java.util.Calendar

object Greeting {
    fun byHour(hour: Int = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)): String =
        when (hour) {
            in 5..11 -> "صباح الخير"
            in 12..16 -> "ظهيرة طيبة"
            in 17..20 -> "مساء الخير"
            else -> "ليلة سعيدة"
        }

    fun motivationalLine(hour: Int = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)): String =
        when (hour) {
            in 5..11 -> "ابدأ يومك بنية صادقة وخطوة ثابتة."
            in 12..16 -> "خذ نفساً عميقاً وأكمل بثقة."
            in 17..20 -> "راجع ما أنجزت وخطط لغدك."
            else -> "استرح بضمير مرتاح، فالغد فرصة جديدة."
        }
}
