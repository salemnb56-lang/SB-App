package com.qaaed.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.qaaed.app.data.PrefKeys
import com.qaaed.app.data.dataStore
import com.qaaed.app.data.editPref
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

data class StudyTip(val title: String, val body: String, val source: String)

class TipViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx = app.applicationContext
    private val cooldownMs = 24L * 60 * 60 * 1000

    val tips = listOf(
        StudyTip(
            "نصيحة دراسية يومية",
            "اعتمد تقنية بومودورو: 25 دقيقة تركيز عميق ثم 5 دقائق راحة. كرر 4 جلسات ثم خذ راحة أطول 15-30 دقيقة. هذا يحافظ على تركيزك ويمنع الإرهاق الذهني.",
            "بإلهام من ChatGPT"
        ),
        StudyTip(
            "نصيحة دراسية يومية",
            "راجع ملاحظاتك خلال 24 ساعة من تسجيلها، ثم بعد 7 أيام، ثم بعد 30 يوم. هذه طريقة التكرار المتباعد تساعد على ترسيخ المعلومات في الذاكرة طويلة المدى.",
            "بإلهام من ChatGPT"
        ),
        StudyTip(
            "نصيحة دراسية يومية",
            "علِّم ما تعلمته لشخص آخر — حتى لو كان وهمياً. شرح المفاهيم بكلماتك الخاصة يكشف الفجوات في فهمك ويعمّق المعرفة (تقنية فاينمان).",
            "بإلهام من ChatGPT"
        ),
        StudyTip(
            "نصيحة دراسية يومية",
            "ابدأ بأصعب مادة عندما يكون عقلك في أوج نشاطه (عادةً الصباح). اترك المهام الأسهل لوقت لاحق عندما يقل تركيزك.",
            "بإلهام من ChatGPT"
        ),
        StudyTip(
            "نصيحة دراسية يومية",
            "اشرب كوب ماء قبل كل جلسة مذاكرة. الجفاف الخفيف يقلل التركيز بنسبة تصل إلى 12%. اجعل قارورة الماء بجانبك دائماً.",
            "بإلهام من ChatGPT"
        ),
        StudyTip(
            "نصيحة دراسية يومية",
            "اكتب أهدافك اليومية على ورقة قبل النوم. صباحاً، ابدأ مباشرة بأهم مهمة (Eat the Frog) قبل فتح الهاتف أو وسائل التواصل.",
            "بإلهام من ChatGPT"
        ),
        StudyTip(
            "نصيحة دراسية يومية",
            "النوم 7-8 ساعات أهم من ساعة مذاكرة إضافية ليلاً. الدماغ يثبّت المعلومات أثناء النوم العميق. لا تضحِّ بنومك من أجل المذاكرة.",
            "بإلهام من ChatGPT"
        ),
    )

    private val _currentTipIndex = MutableStateFlow(0)
    val currentTipIndex: StateFlow<Int> = _currentTipIndex
    val currentTip: StudyTip get() = tips[_currentTipIndex.value % tips.size]

    private val _isUnlocked = MutableStateFlow(false)
    val isUnlocked: StateFlow<Boolean> = _isUnlocked

    private val _secondsRemaining = MutableStateFlow(0L)
    val secondsRemaining: StateFlow<Long> = _secondsRemaining

    init {
        viewModelScope.launch {
            val prefs = ctx.dataStore.data.first()
            val lastTime = prefs[PrefKeys.LAST_TIP_TIME] ?: 0L
            _currentTipIndex.value = (prefs[PrefKeys.LAST_TIP_INDEX]?.toIntOrNull() ?: 0)
            val elapsed = System.currentTimeMillis() - lastTime
            if (lastTime > 0 && elapsed < cooldownMs) {
                _isUnlocked.value = false
                tickLoop(cooldownMs - elapsed)
            } else {
                _isUnlocked.value = true
                _secondsRemaining.value = 0L
            }
        }
    }

    private suspend fun tickLoop(initialMs: Long) {
        var remaining = initialMs
        while (remaining > 0) {
            _secondsRemaining.value = remaining / 1000L
            delay(1000L)
            remaining -= 1000L
        }
        _isUnlocked.value = true
        _secondsRemaining.value = 0L
        _currentTipIndex.value = (_currentTipIndex.value + 1) % tips.size
        ctx.editPref { it[PrefKeys.LAST_TIP_INDEX] = _currentTipIndex.value.toString() }
    }

    fun reveal() {
        if (!_isUnlocked.value) return
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            ctx.editPref {
                it[PrefKeys.LAST_TIP_TIME] = now
                it[PrefKeys.LAST_TIP_INDEX] = _currentTipIndex.value.toString()
            }
            _isUnlocked.value = false
            tickLoop(cooldownMs)
        }
    }
}
