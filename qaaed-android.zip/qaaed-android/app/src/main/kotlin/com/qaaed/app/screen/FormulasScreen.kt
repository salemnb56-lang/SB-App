package com.qaaed.app.screen

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.qaaed.app.component.AppHeader
import com.qaaed.app.component.ThemedCard
import com.qaaed.app.theme.LocalAppPalette

private data class Formula(val title: String, val equation: String, val description: String)
private data class Subject(val key: String, val name: String, val color: Color, val items: List<Formula>)

@Composable
fun FormulasScreen(onMenu: () -> Unit) {
    val palette = LocalAppPalette.current

    val subjects = remember(palette) {
        listOf(
            Subject("physics", "الفيزياء", Color(0xFF3F8CFF), listOf(
                Formula("القانون الثاني لنيوتن", "F = m × a", "القوة تساوي الكتلة مضروبة في التسارع."),
                Formula("الطاقة الحركية", "Ek = ½ × m × v²", "الطاقة الناتجة عن حركة الجسم."),
                Formula("طاقة الوضع", "Ep = m × g × h", "الطاقة المخزّنة بسبب الارتفاع."),
                Formula("قانون أوم", "V = I × R", "العلاقة بين فرق الجهد والتيار والمقاومة."),
                Formula("الموجات", "v = f × λ", "سرعة الموجة = التردد × الطول الموجي."),
                Formula("السقوط الحر", "v = g × t", "سرعة الجسم بعد زمن t من السقوط."),
                Formula("الحركة المنتظمة", "x = v × t", "المسافة عند سرعة ثابتة."),
            )),
            Subject("math", "الرياضيات", Color(0xFF1E9E6A), listOf(
                Formula("المعادلة التربيعية", "x = (-b ± √(b²-4ac)) / 2a", "حل المعادلة من الدرجة الثانية."),
                Formula("نظرية فيثاغورس", "a² + b² = c²", "في المثلث القائم: مربع الوتر = مجموع مربعي الضلعين."),
                Formula("مساحة الدائرة", "A = π × r²", "بدلالة نصف القطر."),
                Formula("محيط الدائرة", "C = 2 × π × r", "بدلالة نصف القطر."),
                Formula("حجم الأسطوانة", "V = π × r² × h", "بدلالة نصف القطر والارتفاع."),
                Formula("المتتابعة الحسابية", "an = a1 + (n-1) × d", "الحدّ النوني للمتتابعة الحسابية."),
                Formula("اللوغاريتم", "log(a×b) = log(a) + log(b)", "خاصية الجداء."),
            )),
            Subject("chemistry", "الكيمياء", Color(0xFF8E5BFF), listOf(
                Formula("المول", "n = m / M", "عدد المولات = الكتلة ÷ الكتلة المولية."),
                Formula("التركيز المولي", "C = n / V", "عدد المولات ÷ الحجم باللتر."),
                Formula("قانون الغازات المثالية", "PV = nRT", "بين الضغط والحجم وعدد المولات."),
                Formula("درجة الحموضة", "pH = -log[H⁺]", "بدلالة تركيز أيونات الهيدروجين."),
                Formula("معادلة الاحتراق", "CnH₂ₙ₊₂ + O₂ → CO₂ + H₂O", "احتراق الألكانات."),
            )),
        )
    }
    var current by remember { mutableStateOf(subjects[0].key) }
    val active = subjects.first { it.key == current }

    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        AppHeader(title = "القوانين والمعادلات", onMenu = onMenu, subtitle = "فيزياء، رياضيات، كيمياء")
        Column(modifier = Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                subjects.forEach { s ->
                    val on = s.key == current
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (on) s.color else palette.card)
                            .clickable { current = s.key }
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(s.name, color = if (on) Color.White else palette.foreground, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }
            active.items.forEach { f ->
                ThemedCard {
                    Column {
                        Text(f.title, color = palette.foreground, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(active.color.copy(alpha = 0.12f))
                                .padding(14.dp)
                        ) {
                            Text(f.equation, color = active.color, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(f.description, color = palette.mutedForeground, fontSize = 13.sp, lineHeight = 21.sp)
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
