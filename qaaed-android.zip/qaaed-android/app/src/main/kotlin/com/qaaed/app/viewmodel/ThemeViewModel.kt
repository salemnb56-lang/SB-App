package com.qaaed.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.qaaed.app.data.PrefKeys
import com.qaaed.app.data.dataStore
import com.qaaed.app.data.editPref
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

enum class ThemeMode(val storageKey: String) {
    LIGHT("light"), DARK("dark"), SYSTEM("system"), AUTO_TIME("auto");
    companion object {
        fun fromKey(s: String?): ThemeMode = entries.firstOrNull { it.storageKey == s } ?: SYSTEM
    }
}

class ThemeViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx = app.applicationContext
    private val _mode = MutableStateFlow(ThemeMode.SYSTEM)
    val mode: StateFlow<ThemeMode> = _mode

    init {
        viewModelScope.launch {
            val prefs = ctx.dataStore.data.first()
            _mode.value = ThemeMode.fromKey(prefs[PrefKeys.THEME_MODE])
        }
    }

    fun setMode(m: ThemeMode) {
        _mode.value = m
        viewModelScope.launch {
            ctx.editPref { it[PrefKeys.THEME_MODE] = m.storageKey }
        }
    }
}
