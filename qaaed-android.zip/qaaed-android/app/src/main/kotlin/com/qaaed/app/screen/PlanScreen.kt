package com.qaaed.app.screen

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.qaaed.app.R
import com.qaaed.app.component.AppHeader
import com.qaaed.app.component.ThemedCard
import com.qaaed.app.theme.LocalAppPalette

private data class PlanInfo(val key: String, val title: String, val desc: String, val image: Int)

@Composable
fun PlanScreen(onMenu: () -> Unit) {
    val palette = LocalAppPalette.current
    val plans = remember {
        listOf(
            PlanInfo("normal", "أيام الدراسة العادية", "خطة متوازنة لمذاكرة المواد بشكل منتظم خلال الأسبوع.", R.drawable.img_plan_normal),
            PlanInfo("exams", "فترة الاختبارات", "تكثيف المراجعة وحلّ النماذج مع راحات قصيرة فعّالة.", R.drawable.img_plan_exams),
            PlanInfo("holidays", "العطلات", "خطة استدراك ومراجعة شاملة دون إرهاق.", R.drawable.img_plan_holidays),
        )
    }
    var selected by remember { mutableStateOf(plans[0].key) }
    val current = plans.first { it.key == selected }

    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        AppHeader(title = "الخطة الدراسية", onMenu = onMenu, subtitle = "خطط جاهزة لكل مرحلة")

        Column(modifier = Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                plans.forEach { p ->
                    val active = p.key == selected
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (active) palette.secondary else palette.card)
                            .clickable { selected = p.key }
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            when (p.key) { "normal" -> "عادي"; "exams" -> "اختبارات"; else -> "عطلات" },
                            color = if (active) palette.onGradient else palette.foreground,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                        )
                    }
                }
            }

            ThemedCard(paddingValues = PaddingValues(0.dp)) {
                Column {
                    Image(
                        painter = painterResource(id = current.image),
                        contentDescription = current.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxWidth().height(220.dp).clip(RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)),
                    )
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(current.title, color = palette.foreground, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Text(current.desc, color = palette.mutedForeground, fontSize = 14.sp, lineHeight = 22.sp)
                    }
                }
            }

            ThemedCard {
                Column {
                    Text("نصائح للالتزام بالخطة", color = palette.foreground, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Spacer(Modifier.height(8.dp))
                    listOf(
                        "ابدأ بأصعب مادة في فترة نشاطك الذهني.",
                        "اقسّم المذاكرة إلى جلسات بومودورو 25/5.",
                        "راجع ملاحظاتك خلال 24 ساعة من تسجيلها.",
                        "خصّص وقتاً للراحة والنشاط البدني يومياً.",
                    ).forEach {
                        Row(modifier = Modifier.padding(vertical = 4.dp)) {
                            Text("•  ", color = palette.secondary, fontWeight = FontWeight.Bold)
                            Text(it, color = palette.foreground, fontSize = 13.sp, lineHeight = 22.sp)
                        }
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
