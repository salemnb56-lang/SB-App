package com.qaaed.app.screen

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Chat
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.qaaed.app.R
import com.qaaed.app.component.AppHeader
import com.qaaed.app.component.PrimaryButton
import com.qaaed.app.component.ThemedCard
import com.qaaed.app.theme.LocalAppPalette

@Composable
fun DeveloperScreen(onMenu: () -> Unit) {
    val palette = LocalAppPalette.current
    val ctx = LocalContext.current
    val whatsappNumber = "967781453408"

    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        AppHeader(title = "المطوّر", onMenu = onMenu)
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(28.dp))
                    .background(Brush.linearGradient(listOf(palette.gradientStart, palette.gradientEnd)))
                    .padding(22.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Box(
                        Modifier
                            .size(110.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.developer_logo),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.size(96.dp).clip(CircleShape)
                        )
                    }
                    Spacer(Modifier.height(14.dp))
                    Text("سالم نبيل سالم عمر بافريج", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(6.dp))
                    Text("مطوّر تطبيق القائد الرقمي", color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
                }
            }

            ThemedCard {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Text(
                        "«القيادة ليست حُلماً يُحلم .. بل عَملٌ يُعمل.»",
                        color = palette.foreground,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        lineHeight = 26.sp,
                        textAlign = TextAlign.Center,
                    )
                }
            }

            ThemedCard {
                Column {
                    Text("للتواصل", color = palette.foreground, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(10.dp))
                    Text("واتساب: +$whatsappNumber", color = palette.mutedForeground, fontSize = 14.sp)
                    Spacer(Modifier.height(14.dp))
                    PrimaryButton(
                        "محادثة عبر واتساب",
                        leading = { Icon(Icons.Outlined.Chat, contentDescription = null, tint = palette.onGradient) },
                        onClick = {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$whatsappNumber"))
                            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                            runCatching { ctx.startActivity(intent) }
                        }
                    )
                }
            }

            Spacer(Modifier.height(24.dp))
        }
    }
}
