package com.qaaed.app.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.core.view.WindowCompat
import com.qaaed.app.viewmodel.ThemeMode
import java.util.Calendar

@Composable
fun resolveDarkMode(mode: ThemeMode): Boolean = when (mode) {
    ThemeMode.LIGHT -> false
    ThemeMode.DARK -> true
    ThemeMode.SYSTEM -> isSystemInDarkTheme()
    ThemeMode.AUTO_TIME -> {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        hour < 6 || hour >= 18
    }
}

@Composable
fun QaaedTheme(
    mode: ThemeMode = ThemeMode.SYSTEM,
    content: @Composable () -> Unit
) {
    val isDark = resolveDarkMode(mode)
    val palette = if (isDark) DarkPalette else LightPalette

    val colorScheme = if (isDark) {
        darkColorScheme(
            primary = palette.secondary,
            onPrimary = palette.onGradient,
            secondary = palette.accent,
            onSecondary = palette.onGradient,
            background = palette.background,
            onBackground = palette.foreground,
            surface = palette.card,
            onSurface = palette.foreground,
            error = palette.danger,
        )
    } else {
        lightColorScheme(
            primary = palette.secondary,
            onPrimary = palette.onGradient,
            secondary = palette.accent,
            onSecondary = palette.onGradient,
            background = palette.background,
            onBackground = palette.foreground,
            surface = palette.card,
            onSurface = palette.foreground,
            error = palette.danger,
        )
    }

    val view = androidx.compose.ui.platform.LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            window.statusBarColor = palette.gradientStart.toArgb()
            window.navigationBarColor = palette.background.toArgb()
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = false
            controller.isAppearanceLightNavigationBars = !isDark
        }
    }

    CompositionLocalProvider(
        LocalAppPalette provides palette,
        LocalLayoutDirection provides LayoutDirection.Rtl,
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = AppTypography,
            content = content,
        )
    }
}
