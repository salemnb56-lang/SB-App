package com.qaaed.app.screen

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.qaaed.app.R
import com.qaaed.app.component.AppHeader
import com.qaaed.app.component.PrimaryButton
import com.qaaed.app.component.ThemedCard
import com.qaaed.app.data.HijriCalendar
import com.qaaed.app.theme.LocalAppPalette
import com.qaaed.app.viewmodel.TipViewModel

@Composable
fun NotificationScreen(tipVm: TipViewModel, onMenu: () -> Unit) {
    val palette = LocalAppPalette.current
    val unlocked by tipVm.isUnlocked.collectAsState()
    val secondsLeft by tipVm.secondsRemaining.collectAsState()
    val currentIndex by tipVm.currentTipIndex.collectAsState()
    val tip = tipVm.tips[currentIndex % tipVm.tips.size]
    val hours = secondsLeft / 3600
    val mins = (secondsLeft % 3600) / 60
    val sec = secondsLeft % 60

    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        AppHeader(title = "إشعار اليوم", onMenu = onMenu, subtitle = "نصيحة مرّة كل ٢٤ ساعة")
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(22.dp))
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_tip_full),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(220.dp)
                        .let { if (!unlocked) it.blur(20.dp) else it },
                )
                Box(
                    modifier = Modifier
                        .matchParentSize()
                        .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.5f))))
                )
                Column(
                    modifier = Modifier
                        .padding(18.dp)
                        .align(Alignment.BottomStart)
                ) {
                    Text(tip.title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                    Text(tip.source, color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
                }
            }

            ThemedCard {
                if (unlocked) {
                    Column {
                        Text(tip.body, color = palette.foreground, fontSize = 15.sp, lineHeight = 26.sp, fontWeight = FontWeight.Medium)
                        Spacer(Modifier.height(14.dp))
                        PrimaryButton("اطّلعت — اكشف نصيحة الغد بعد ٢٤ ساعة", { tipVm.reveal() })
                    }
                } else {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                        Text("النصيحة التالية بعد", color = palette.mutedForeground, fontSize = 13.sp)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "${HijriCalendar.toArabicNumerals("%02d".format(hours))} : ${HijriCalendar.toArabicNumerals("%02d".format(mins))} : ${HijriCalendar.toArabicNumerals("%02d".format(sec))}",
                            color = palette.foreground,
                            fontSize = 32.sp,
                            fontWeight = FontWeight.ExtraBold,
                        )
                        Spacer(Modifier.height(10.dp))
                        Text(
                            "اصبر قليلاً — في الانتظار حكمة.",
                            color = palette.mutedForeground,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center,
                        )
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
