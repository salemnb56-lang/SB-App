package com.qaaed.app.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

@Immutable
data class AppPalette(
    val background: Color,
    val card: Color,
    val cardElevated: Color,
    val foreground: Color,
    val mutedForeground: Color,
    val secondary: Color,
    val accent: Color,
    val border: Color,
    val divider: Color,
    val success: Color,
    val warning: Color,
    val danger: Color,
    val gradientStart: Color,
    val gradientEnd: Color,
    val onGradient: Color,
    val isDark: Boolean,
)

val LightPalette = AppPalette(
    background = Color(0xFFF4F7FB),
    card = Color(0xFFFFFFFF),
    cardElevated = Color(0xFFFFFFFF),
    foreground = Color(0xFF0B1B33),
    mutedForeground = Color(0xFF53627A),
    secondary = Color(0xFF1E5BBA),
    accent = Color(0xFF3F8CFF),
    border = Color(0xFFE2E8F2),
    divider = Color(0xFFEDF1F8),
    success = Color(0xFF1E9E6A),
    warning = Color(0xFFE0A100),
    danger = Color(0xFFD8413A),
    gradientStart = Color(0xFF0B1B33),
    gradientEnd = Color(0xFF1E5BBA),
    onGradient = Color(0xFFFFFFFF),
    isDark = false,
)

val DarkPalette = AppPalette(
    background = Color(0xFF070E1C),
    card = Color(0xFF0F1B33),
    cardElevated = Color(0xFF152748),
    foreground = Color(0xFFE6ECF7),
    mutedForeground = Color(0xFF9AA9C2),
    secondary = Color(0xFF3F8CFF),
    accent = Color(0xFF6BA8FF),
    border = Color(0xFF1F2C48),
    divider = Color(0xFF182441),
    success = Color(0xFF3DD08F),
    warning = Color(0xFFF5C453),
    danger = Color(0xFFFF6B6B),
    gradientStart = Color(0xFF070E1C),
    gradientEnd = Color(0xFF13315C),
    onGradient = Color(0xFFFFFFFF),
    isDark = true,
)

val LocalAppPalette = staticCompositionLocalOf { LightPalette }
