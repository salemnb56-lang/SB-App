# القائد الرقمي — Native Android (Kotlin + Jetpack Compose)

تطبيق أندرويد أصلي للطالب العربي مكتوب بالكامل بلغة **Kotlin** و **Jetpack Compose**، يحتوي على نفس مزايا تطبيق React Native الأصلي:

- بطاقة ترحيب مع التاريخ الهجري والميلادي وتحية حسب وقت اليوم
- مواقيت الصلاة لـ ١٠ مدن يمنية (حساب MWL محلياً بدون إنترنت)
- خطّة دراسية بثلاثة أنماط (عادي / اختبارات / عطلات)
- حاسبة معدّل GPA فصلي وتراكمي مع محاكي هدف
- مهام بمصفوفة آيزنهاور
- آلة حاسبة علمية (sin/cos/tan/log/√/^/π)
- مؤقّت مذاكرة بومودورو ٢٥/٥ مع أربع جلسات
- زاوية ثقافية (علم • فكر • أخلاق)
- قوانين فيزياء/رياضيات/كيمياء
- إشعار يومي يُكشف كل ٢٤ ساعة (مع تأثير blur)
- نافذة الجمعة (١٠ صلوات على النبي ﷺ مع نبضات)
- ٤ أنماط للثيم: فاتح / داكن / النظام / تلقائي حسب الوقت
- خط Cairo عربي مدمج عبر Google Fonts (Downloadable)
- اتجاه RTL كامل، تأثيرات حركية، haptics

---

## 📦 بناء ملف APK من الهاتف عبر GitHub Actions

التطبيق مُهيّأ ليعمل مع GitHub Actions تماماً. كل ما تحتاج فعله:

### الخطوة ١: أنشئ مستودعاً جديداً على GitHub
- ادخل على [github.com](https://github.com) من متصفح هاتفك
- اضغط **+** ثم **New repository**
- سمّه مثلاً `qaaed-android`
- اختر **Public** (أسهل) أو **Private**
- لا تضف README ولا .gitignore (الملفات جاهزة بالداخل)
- اضغط **Create repository**

### الخطوة ٢: ارفع المشروع
بعد إنشاء المستودع، ستظهر لك تعليمات. أبسط طريقة من الهاتف:

**أ) عبر تطبيق GitHub Mobile:**
- نزّل تطبيق GitHub من Play Store
- ستحتاج إلى رفع ملفات الـ ZIP عبر متصفح المحمول من صفحة المستودع نفسها (تبويب "Add file" → "Upload files")، يقبل GitHub رفع المجلد كاملاً

**ب) عبر متصفح الهاتف مباشرة:**
1. من صفحة المستودع، اضغط **uploading an existing file**
2. اضغط **choose your files** واختر كل محتوى مجلد `qaaed-android` (يفضّل بعد فك الـ ZIP)
3. اضغط **Commit changes**

### الخطوة ٣: شغّل البناء التلقائي
- بمجرّد رفع الكود، سيبدأ GitHub Actions تلقائياً
- ادخل على تبويب **Actions** في صفحة المستودع
- ستجد عملية بعنوان **Build Android APK**
- انتظر ٥-٨ دقائق حتى تنتهي

### الخطوة ٤: نزّل الـ APK
- بعد انتهاء البناء (علامة ✓ خضراء)
- اضغط على آخر تشغيل (build)
- في الأسفل ستجد قسم **Artifacts**
- اضغط **qaaed-digital-debug-apk** للتنزيل
- ستحصل على ملف ZIP يحتوي ملف `app-debug.apk`
- فك الضغط وثبّت الـ APK على هاتفك

> ⚠️ ربما يطلب منك الهاتف السماح بتثبيت تطبيقات من مصادر خارج Play Store. مرّر إلى **الإعدادات** → **الأمان** → فعّل **مصادر غير معروفة** للتطبيق الذي تستخدمه (المتصفح أو إدارة الملفات).

---

## 🖥️ بناء التطبيق محلياً (اختياري — بحاسوب)

إذا كان لديك حاسوب وتريد التطوير:

```bash
# نزّل Android Studio Hedgehog أو أحدث + Java 17
# افتح مجلد qaaed-android كمشروع
# انتظر تنزيل Gradle والـ dependencies
# اضغط Run ▶ أو نفّذ:

./gradlew assembleDebug
# الناتج في: app/build/outputs/apk/debug/app-debug.apk
```

---

## 🏗️ البنية الفنية

```
qaaed-android/
├── .github/workflows/build-apk.yml   ← GitHub Actions
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── kotlin/com/qaaed/app/
│       │   ├── MainActivity.kt
│       │   ├── QaaedApplication.kt
│       │   ├── theme/      ← Color, Theme, Type
│       │   ├── data/       ← Models, HijriCalendar, PrayerTimes, Preferences
│       │   ├── viewmodel/  ← Theme, User, Tasks, Prayer, Tip
│       │   ├── component/  ← AppHeader, HeroCard, PrayerTimesCard, ToolCard, AppDrawer, OnboardingDialog, FridayDhikrDialog, PrimaryButton, ThemedCard, AnimatedEntrance
│       │   └── screen/     ← Home, Calculator, Tasks, Scientific, Plan, Formulas, Timer, Notification, Cultural, Developer
│       └── res/            ← drawable, font, mipmap, values, xml
├── build.gradle.kts
├── settings.gradle.kts
└── gradle.properties
```

### المكدس التقني
| المجال | التقنية |
|---|---|
| اللغة | Kotlin 2.0.20 |
| الواجهة | Jetpack Compose (BOM 2024.09.02) |
| التنقّل | Navigation Compose 2.8 |
| الحالة | StateFlow + ViewModel |
| التخزين | DataStore Preferences |
| الخطّ | Cairo (Google Fonts Downloadable) |
| الحدّ الأدنى للـ SDK | 24 (Android 7.0) |
| الهدف | SDK 34 (Android 14) |

### الخوارزميات
- **التقويم الهجري:** Tabular Islamic Calendar (Kuwaiti) — منقول من النسخة الأصلية حرفياً
- **مواقيت الصلاة:** Muslim World League (MWL) angles 18°/17°

---

## 👨‍💻 المطوّر

**سالم نبيل سالم عمر بافريج**

«القيادة ليست حُلماً يُحلم .. بل عَملٌ يُعمل.»

📱 واتساب: +967 781 453 408
